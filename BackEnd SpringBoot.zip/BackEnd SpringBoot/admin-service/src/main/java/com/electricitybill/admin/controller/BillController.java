package com.electricitybill.admin.controller;

import com.electricitybill.admin.model.Bill;
import com.electricitybill.admin.service.BillService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Bill Controller for Admin Service
 *
 * Handles bill-related operations for admin:
 * - Bill management
 * - Payment processing
 * - Bill generation
 */
@RestController
@RequestMapping("/api/admin/bills")
@Tag(name = "Admin Bills", description = "Bill management and payment operations for admin")
public class BillController {

    @Autowired
    private BillService billService;

    @GetMapping("/consumer/{consumerId}")
    @Operation(summary = "Get all bills for a consumer")
    public ResponseEntity<Map<String, Object>> getBillsByConsumerId(@PathVariable String consumerId) {
        try {
            List<Bill> bills = billService.getBillsByConsumerId(consumerId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bills retrieved successfully");
            response.put("data", bills);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve bills: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/consumer/{consumerId}/pending")
    @Operation(summary = "Get pending bills for a consumer")
    public ResponseEntity<Map<String, Object>> getPendingBillsByConsumerId(@PathVariable String consumerId) {
        try {
            List<Bill> pendingBills = billService.getPendingBillsByConsumerId(consumerId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Pending bills retrieved successfully");
            response.put("data", pendingBills);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve pending bills: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/consumer/{consumerId}/paid")
    @Operation(summary = "Get paid bills for a consumer")
    public ResponseEntity<Map<String, Object>> getPaidBillsByConsumerId(@PathVariable String consumerId) {
        try {
            List<Bill> paidBills = billService.getPaidBillsByConsumerId(consumerId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Paid bills retrieved successfully");
            response.put("data", paidBills);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve paid bills: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/{billId}")
    @Operation(summary = "Get bill details by bill ID")
    public ResponseEntity<Map<String, Object>> getBillById(@PathVariable String billId) {
        try {
            Bill bill = billService.getBillById(billId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bill details retrieved successfully");
            response.put("data", bill);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Bill not found: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @PostMapping("/{billId}/pay")
    @Operation(summary = "Pay a bill")
    public ResponseEntity<Map<String, Object>> payBill(@PathVariable String billId, @RequestBody Map<String, Object> paymentRequest) {
        try {
            String paymentMethod = (String) paymentRequest.get("paymentMethod");
            String transactionReference = (String) paymentRequest.get("transactionReference");
            Double amount = (Double) paymentRequest.get("amount");

            Bill paidBill = billService.payBill(billId, paymentMethod, transactionReference, BigDecimal.valueOf(amount));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Payment processed successfully");
            response.put("data", paidBill);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Payment failed: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @GetMapping("/consumer/{consumerId}/history")
    @Operation(summary = "Get bill payment history for a consumer")
    public ResponseEntity<Map<String, Object>> getBillHistory(@PathVariable String consumerId) {
        try {
            List<Bill> allBills = billService.getBillsByConsumerId(consumerId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bill history retrieved successfully");
            response.put("data", allBills);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve bill history: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/consumer/{consumerId}/total-pending")
    @Operation(summary = "Get total pending amount for a consumer")
    public ResponseEntity<Map<String, Object>> getTotalPendingAmount(@PathVariable String consumerId) {
        try {
            BigDecimal totalPending = billService.getTotalPendingAmount(consumerId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Total pending amount retrieved successfully");
            response.put("data", Map.of("totalPendingAmount", totalPending, "consumerId", consumerId));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve total pending amount: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/all")
    @Operation(summary = "Get all bills in the system (for admin management)")
    public ResponseEntity<Map<String, Object>> getAllBills() {
        try {
            List<Bill> allBills = billService.getAllBills();

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "All bills retrieved successfully");
            response.put("data", allBills);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve all bills: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @DeleteMapping("/{billId}")
    @Operation(summary = "Delete a bill (admin only)")
    public ResponseEntity<Map<String, Object>> deleteBill(@PathVariable String billId) {
        try {
            billService.deleteBill(billId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bill deleted successfully");
            response.put("data", Map.of("billId", billId));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to delete bill: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @PutMapping("/{billId}")
    @Operation(summary = "Update a bill (admin only)")
    public ResponseEntity<Map<String, Object>> updateBill(@PathVariable String billId, @RequestBody Map<String, Object> updateRequest) {
        try {
            Bill updatedBill = billService.updateBill(billId, updateRequest);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bill updated successfully");
            response.put("data", updatedBill);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to update bill: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
}
