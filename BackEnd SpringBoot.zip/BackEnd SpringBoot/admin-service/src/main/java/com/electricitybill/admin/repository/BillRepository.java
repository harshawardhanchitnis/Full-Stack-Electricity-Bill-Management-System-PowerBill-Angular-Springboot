package com.electricitybill.admin.repository;

import com.electricitybill.admin.model.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Bill entity
 */
@Repository
public interface BillRepository extends JpaRepository<Bill, Long> {
    
    /**
     * Find bill by bill ID
     */
    Optional<Bill> findByBillId(String billId);
    
    /**
     * Find bills by consumer ID
     */
    List<Bill> findByConsumerId(String consumerId);
    
    /**
     * Find bills by consumer ID and payment status
     */
    List<Bill> findByConsumerIdAndPaymentStatus(String consumerId, Bill.PaymentStatus paymentStatus);
    
    /**
     * Find bills by payment status
     */
    List<Bill> findByPaymentStatus(Bill.PaymentStatus paymentStatus);
    
    /**
     * Check if bill exists for consumer, month, and year
     */
    boolean existsByConsumerIdAndBillMonthAndBillYear(String consumerId, Bill.BillMonth billMonth, Integer billYear);
    
    /**
     * Find bills by bill month and year
     */
    List<Bill> findByBillMonthAndBillYear(Bill.BillMonth billMonth, Integer billYear);
    
    /**
     * Find bills by consumer ID, month, and year
     */
    Optional<Bill> findByConsumerIdAndBillMonthAndBillYear(String consumerId, Bill.BillMonth billMonth, Integer billYear);
    
    /**
     * Find overdue bills
     */
    @Query("SELECT b FROM Bill b WHERE b.dueDate < :currentDate AND b.paymentStatus = 'PENDING'")
    List<Bill> findOverdueBills(@Param("currentDate") LocalDate currentDate);
    
    /**
     * Find bills due within specified days
     */
    @Query("SELECT b FROM Bill b WHERE b.dueDate BETWEEN :startDate AND :endDate AND b.paymentStatus = 'PENDING'")
    List<Bill> findBillsDueWithinDays(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    
    /**
     * Find bills by payment method
     */
    List<Bill> findByPaymentMethod(Bill.PaymentMethod paymentMethod);
    
    /**
     * Find bills by payment date range
     */
    @Query("SELECT b FROM Bill b WHERE b.paymentDate BETWEEN :startDate AND :endDate")
    List<Bill> findBillsByPaymentDateRange(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    
    /**
     * Count bills by payment status
     */
    @Query("SELECT COUNT(b) FROM Bill b WHERE b.paymentStatus = :status")
    Long countByPaymentStatus(@Param("status") Bill.PaymentStatus status);
    
    /**
     * Count bills by consumer ID
     */
    Long countByConsumerId(String consumerId);
    
    /**
     * Find recent bills (last N bills)
     */
    @Query("SELECT b FROM Bill b ORDER BY b.createdDate DESC")
    List<Bill> findRecentBills();
    
    /**
     * Find bills by year
     */
    List<Bill> findByBillYear(Integer billYear);
    
    /**
     * Find bills by consumer ID and year
     */
    List<Bill> findByConsumerIdAndBillYear(String consumerId, Integer billYear);
}
