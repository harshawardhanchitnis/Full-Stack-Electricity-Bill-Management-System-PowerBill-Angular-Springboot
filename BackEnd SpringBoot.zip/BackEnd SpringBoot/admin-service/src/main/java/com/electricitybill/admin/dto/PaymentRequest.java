package com.electricitybill.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;

@Schema(description = "Payment processing request")
public class PaymentRequest {
    
    @Schema(description = "Payment method", example = "CREDIT_CARD", required = true,
            allowableValues = {"CREDIT_CARD", "DEBIT_CARD", "NET_BANKING", "UPI", "CASH"})
    private String paymentMethod;
    
    @Schema(description = "Transaction reference number", example = "TXN123456789", required = true)
    private String transactionReference;
    
    @Schema(description = "Payment amount", example = "825.50", required = true)
    private Double amount;
    
    // Default constructor
    public PaymentRequest() {}
    
    // Constructor with parameters
    public PaymentRequest(String paymentMethod, String transactionReference, Double amount) {
        this.paymentMethod = paymentMethod;
        this.transactionReference = transactionReference;
        this.amount = amount;
    }
    
    // Getters and Setters
    public String getPaymentMethod() {
        return paymentMethod;
    }
    
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    
    public String getTransactionReference() {
        return transactionReference;
    }
    
    public void setTransactionReference(String transactionReference) {
        this.transactionReference = transactionReference;
    }
    
    public Double getAmount() {
        return amount;
    }
    
    public void setAmount(Double amount) {
        this.amount = amount;
    }
    
    @Override
    public String toString() {
        return "PaymentRequest{" +
                "paymentMethod='" + paymentMethod + '\'' +
                ", transactionReference='" + transactionReference + '\'' +
                ", amount=" + amount +
                '}';
    }
}
