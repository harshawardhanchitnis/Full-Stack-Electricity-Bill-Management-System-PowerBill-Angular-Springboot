package com.electricitybill.admin.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Feign Client for communicating with Customer Service
 */
@FeignClient(name = "customer-service", url = "http://localhost:8081")
public interface CustomerServiceClient {
    
    /**
     * Get customer profile by consumer ID
     */
    @GetMapping("/api/customers/profile/{consumerId}")
    ResponseEntity<Map<String, Object>> getCustomerProfile(@PathVariable("consumerId") String consumerId);
    
    /**
     * Get all customers (for admin dashboard)
     */
    @GetMapping("/api/customers/all")
    ResponseEntity<Map<String, Object>> getAllCustomers();
    
    /**
     * Get active customers
     */
    @GetMapping("/api/customers/active")
    ResponseEntity<Map<String, Object>> getActiveCustomers();
    
    /**
     * Search customers by name
     */
    @GetMapping("/api/customers/search")
    ResponseEntity<Map<String, Object>> searchCustomers(@RequestParam("name") String name);
    
    /**
     * Get customers by connection type
     */
    @GetMapping("/api/customers/connection-type/{type}")
    ResponseEntity<Map<String, Object>> getCustomersByConnectionType(@PathVariable("type") String type);
    
    /**
     * Get all complaints (for admin support)
     */
    @GetMapping("/api/customers/complaints/all")
    ResponseEntity<Map<String, Object>> getAllComplaints();
    
    /**
     * Get complaints by status
     */
    @GetMapping("/api/customers/complaints/status/{status}")
    ResponseEntity<Map<String, Object>> getComplaintsByStatus(@PathVariable("status") String status);
    
    /**
     * Update complaint status (admin operation)
     */
    @PutMapping("/api/customers/complaints/{complaintId}/status")
    ResponseEntity<Map<String, Object>> updateComplaintStatus(
            @PathVariable("complaintId") String complaintId,
            @RequestBody Map<String, Object> statusUpdate);
    
    /**
     * Check if customer service is available
     */
    @GetMapping("/api/customers/health")
    ResponseEntity<Map<String, Object>> checkCustomerServiceHealth();
}
