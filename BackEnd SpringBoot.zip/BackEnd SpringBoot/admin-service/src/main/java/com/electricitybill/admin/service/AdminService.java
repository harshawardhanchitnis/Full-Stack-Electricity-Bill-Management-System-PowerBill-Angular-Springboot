package com.electricitybill.admin.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Service class for Admin operations
 */
@Service
public class AdminService {
    
    @Value("${admin.credentials.email:admin@electricitybill.com}")
    private String adminEmail;
    
    @Value("${admin.credentials.password:admin123}")
    private String adminPassword;
    
    @Value("${admin.credentials.name:System Administrator}")
    private String adminName;
    
    /**
     * Admin login
     */
    public AdminLoginResponse login(String email, String password) {
        if (!adminEmail.equals(email)) {
            throw new RuntimeException("Invalid admin email: " + email);
        }
        
        if (!adminPassword.equals(password)) {
            throw new RuntimeException("Invalid admin password");
        }
        
        return new AdminLoginResponse(adminEmail, adminName, "Admin login successful");
    }
    
    /**
     * Validate admin credentials
     */
    public boolean validateAdmin(String email, String password) {
        return adminEmail.equals(email) && adminPassword.equals(password);
    }
    
    /**
     * Get admin details
     */
    public AdminLoginResponse getAdminDetails() {
        return new AdminLoginResponse(adminEmail, adminName, "Admin details retrieved");
    }
    
    /**
     * Admin login response class
     */
    public static class AdminLoginResponse {
        private String email;
        private String name;
        private String message;
        
        public AdminLoginResponse(String email, String name, String message) {
            this.email = email;
            this.name = name;
            this.message = message;
        }
        
        // Getters and Setters
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }
}
