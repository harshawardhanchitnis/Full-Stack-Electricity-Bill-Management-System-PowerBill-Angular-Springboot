package com.electricitybill.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;

@Schema(description = "Bill generation request")
public class BillGenerationRequest {
    
    @Schema(description = "Consumer ID", example = "CUST001", required = true)
    private String consumerId;
    
    @Schema(description = "Bill month", example = "JANUARY", required = true, 
            allowableValues = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", 
                              "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"})
    private String month;
    
    @Schema(description = "Bill year", example = "2025", required = true)
    private Integer year;
    
    @Schema(description = "Units consumed", example = "150", required = true)
    private Integer unitsConsumed;
    
    @Schema(description = "Rate per unit", example = "5.50", required = true)
    private Double ratePerUnit;
    
    // Default constructor
    public BillGenerationRequest() {}
    
    // Constructor with parameters
    public BillGenerationRequest(String consumerId, String month, Integer year, Integer unitsConsumed, Double ratePerUnit) {
        this.consumerId = consumerId;
        this.month = month;
        this.year = year;
        this.unitsConsumed = unitsConsumed;
        this.ratePerUnit = ratePerUnit;
    }
    
    // Getters and Setters
    public String getConsumerId() {
        return consumerId;
    }
    
    public void setConsumerId(String consumerId) {
        this.consumerId = consumerId;
    }
    
    public String getMonth() {
        return month;
    }
    
    public void setMonth(String month) {
        this.month = month;
    }
    
    public Integer getYear() {
        return year;
    }
    
    public void setYear(Integer year) {
        this.year = year;
    }
    
    public Integer getUnitsConsumed() {
        return unitsConsumed;
    }
    
    public void setUnitsConsumed(Integer unitsConsumed) {
        this.unitsConsumed = unitsConsumed;
    }
    
    public Double getRatePerUnit() {
        return ratePerUnit;
    }
    
    public void setRatePerUnit(Double ratePerUnit) {
        this.ratePerUnit = ratePerUnit;
    }
    
    @Override
    public String toString() {
        return "BillGenerationRequest{" +
                "consumerId='" + consumerId + '\'' +
                ", month='" + month + '\'' +
                ", year=" + year +
                ", unitsConsumed=" + unitsConsumed +
                ", ratePerUnit=" + ratePerUnit +
                '}';
    }
}
