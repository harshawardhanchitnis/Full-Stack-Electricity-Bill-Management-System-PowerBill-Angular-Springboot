package com.electricitybill.admin.service;

import com.electricitybill.admin.model.Bill;
import com.electricitybill.admin.repository.BillRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Service class for Bill operations in Admin Service
 */
@Service
@Transactional
public class BillService {

    @Autowired
    private BillRepository billRepository;

    /**
     * Generate bill for a consumer
     */
    public Bill generateBill(String consumerId, Bill.BillMonth month, Integer year,
                           Integer unitsConsumed, BigDecimal ratePerUnit) {
        // Check if bill already exists for this month/year
        if (billRepository.existsByConsumerIdAndBillMonthAndBillYear(consumerId, month, year)) {
            throw new RuntimeException("Bill already exists for " + month + " " + year);
        }

        Bill bill = new Bill();
        bill.setBillId(generateBillId());
        bill.setConsumerId(consumerId);
        bill.setBillMonth(month);
        bill.setBillYear(year);
        bill.setUnitsConsumed(unitsConsumed);
        bill.setRatePerUnit(ratePerUnit);

        // Calculate bill amount
        BigDecimal billAmount = ratePerUnit.multiply(BigDecimal.valueOf(unitsConsumed));
        bill.setBillAmount(billAmount);
        bill.setTotalAmount(billAmount);

        // Set due date (30 days from creation)
        bill.setDueDate(LocalDate.now().plusDays(30));
        bill.setPaymentStatus(Bill.PaymentStatus.PENDING);

        return billRepository.save(bill);
    }

    /**
     * Get all bills for a consumer
     */
    public List<Bill> getBillsByConsumerId(String consumerId) {
        return billRepository.findByConsumerId(consumerId);
    }

    /**
     * Get pending bills for a consumer
     */
    public List<Bill> getPendingBillsByConsumerId(String consumerId) {
        return billRepository.findByConsumerIdAndPaymentStatus(consumerId, Bill.PaymentStatus.PENDING);
    }

    /**
     * Get paid bills for a consumer
     */
    public List<Bill> getPaidBillsByConsumerId(String consumerId) {
        return billRepository.findByConsumerIdAndPaymentStatus(consumerId, Bill.PaymentStatus.PAID);
    }

    /**
     * Get bill by bill ID
     */
    public Bill getBillById(String billId) {
        return billRepository.findByBillId(billId)
                .orElseThrow(() -> new RuntimeException("Bill not found with ID: " + billId));
    }

    /**
     * Pay a bill
     */
    public Bill payBill(String billId, String paymentMethod, String transactionReference, BigDecimal amount) {
        Bill bill = getBillById(billId);

        if (bill.getPaymentStatus() == Bill.PaymentStatus.PAID) {
            throw new RuntimeException("Bill is already paid");
        }

        // Calculate late fee if overdue
        BigDecimal lateFee = calculateLateFee(bill);
        BigDecimal totalAmount = bill.getBillAmount().add(lateFee);

        if (amount.compareTo(totalAmount) != 0) {
            throw new RuntimeException("Payment amount does not match total due amount. Expected: " + totalAmount + ", Received: " + amount);
        }

        // Update bill with payment details
        bill.setPaymentStatus(Bill.PaymentStatus.PAID);
        bill.setPaymentId(generatePaymentId());
        bill.setPaymentDate(LocalDate.now());
        bill.setPaymentMethod(Bill.PaymentMethod.valueOf(paymentMethod));
        bill.setTransactionReference(transactionReference);
        bill.setLateFee(lateFee);
        bill.setTotalAmount(totalAmount);

        return billRepository.save(bill);
    }

    /**
     * Get all bills (for admin dashboard)
     */
    public List<Bill> getAllBills() {
        return billRepository.findAll();
    }

    /**
     * Get bills by payment status
     */
    public List<Bill> getBillsByPaymentStatus(Bill.PaymentStatus status) {
        return billRepository.findByPaymentStatus(status);
    }

    /**
     * Get paid bills with customer data
     */
    public List<Bill> getPaidBillsWithCustomerData() {
        return billRepository.findByPaymentStatus(Bill.PaymentStatus.PAID);
    }

    /**
     * Get total pending amount for a consumer
     */
    public BigDecimal getTotalPendingAmount(String consumerId) {
        List<Bill> pendingBills = getPendingBillsByConsumerId(consumerId);
        BigDecimal total = BigDecimal.ZERO;

        for (Bill bill : pendingBills) {
            BigDecimal lateFee = calculateLateFee(bill);
            total = total.add(bill.getBillAmount().add(lateFee));
        }

        return total;
    }

    /**
     * Calculate late fee for overdue bills
     */
    private BigDecimal calculateLateFee(Bill bill) {
        if (bill.getDueDate().isAfter(LocalDate.now())) {
            return BigDecimal.ZERO; // Not overdue
        }

        // Calculate late fee as 2% per month overdue, capped at 10%
        long daysOverdue = LocalDate.now().toEpochDay() - bill.getDueDate().toEpochDay();
        long monthsOverdue = daysOverdue / 30;

        if (monthsOverdue <= 0) {
            return BigDecimal.ZERO;
        }

        BigDecimal lateFeePercentage = BigDecimal.valueOf(Math.min(monthsOverdue * 2, 10)); // Cap at 10%
        return bill.getBillAmount().multiply(lateFeePercentage).divide(BigDecimal.valueOf(100));
    }

    /**
     * Generate unique bill ID
     */
    private String generateBillId() {
        String prefix = "BILL";
        Random random = new Random();
        String suffix = String.format("%08X", random.nextInt());
        String billId = prefix + suffix;

        // Check if already exists, regenerate if needed
        while (billRepository.findByBillId(billId).isPresent()) {
            suffix = String.format("%08X", random.nextInt());
            billId = prefix + suffix;
        }

        return billId;
    }

    /**
     * Generate unique payment ID
     */
    private String generatePaymentId() {
        String prefix = "PAY";
        Random random = new Random();
        String suffix = String.format("%08X", random.nextInt());
        return prefix + suffix;
    }

    /**
     * Delete a bill by bill ID
     */
    public void deleteBill(String billId) {
        Bill bill = billRepository.findByBillId(billId)
                .orElseThrow(() -> new RuntimeException("Bill not found with ID: " + billId));

        // Only allow deletion of unpaid bills
        if (bill.getPaymentStatus() == Bill.PaymentStatus.PAID) {
            throw new RuntimeException("Cannot delete a paid bill");
        }

        billRepository.delete(bill);
    }

    /**
     * Update a bill
     */
    public Bill updateBill(String billId, Map<String, Object> updateRequest) {
        Bill bill = billRepository.findByBillId(billId)
                .orElseThrow(() -> new RuntimeException("Bill not found with ID: " + billId));

        // Only allow updating unpaid bills
        if (bill.getPaymentStatus() == Bill.PaymentStatus.PAID) {
            throw new RuntimeException("Cannot update a paid bill");
        }

        // Update allowed fields
        if (updateRequest.containsKey("unitsConsumed")) {
            bill.setUnitsConsumed(((Number) updateRequest.get("unitsConsumed")).intValue());
        }

        if (updateRequest.containsKey("ratePerUnit")) {
            bill.setRatePerUnit(new BigDecimal(updateRequest.get("ratePerUnit").toString()));
        }

        if (updateRequest.containsKey("dueDate")) {
            bill.setDueDate(LocalDate.parse(updateRequest.get("dueDate").toString()));
        }

        // Recalculate bill amount if units or rate changed
        if (updateRequest.containsKey("unitsConsumed") || updateRequest.containsKey("ratePerUnit")) {
            BigDecimal billAmount = bill.getRatePerUnit().multiply(new BigDecimal(bill.getUnitsConsumed()));
            bill.setBillAmount(billAmount);
        }

        return billRepository.save(bill);
    }
}
