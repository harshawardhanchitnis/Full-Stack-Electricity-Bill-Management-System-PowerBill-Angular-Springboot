package com.electricitybill.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Admin Service Application for Electricity Bill Management System
 * 
 * This microservice handles:
 * - Admin login (fixed admin credentials)
 * - Dashboard showing all customers data
 * - Provide electricity bills to all customers
 * - Check status of user bills (paid or not)
 * - View paid bill data with customer data
 * - Support complaints uploaded by customers
 * 
 * Runs on port 8082 and registers with Eureka Server on port 8761
 */
@SpringBootApplication
@EnableFeignClients
public class AdminServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdminServiceApplication.class, args);
        System.out.println("=================================================");
        System.out.println("🚀 ADMIN SERVICE STARTED SUCCESSFULLY!");
        System.out.println("📍 Service URL: http://localhost:8082");
        System.out.println("🌐 Swagger UI: http://localhost:8082/swagger-ui/index.html");
        System.out.println("🔗 Eureka Server: http://localhost:8761");
        System.out.println("👤 Admin Login: admin@electricitybill.com / admin123");
        System.out.println("=================================================");
    }
}
