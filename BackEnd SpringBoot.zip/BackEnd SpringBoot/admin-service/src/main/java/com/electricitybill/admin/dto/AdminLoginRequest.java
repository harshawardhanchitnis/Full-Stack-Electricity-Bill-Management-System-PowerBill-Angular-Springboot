package com.electricitybill.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Admin login request")
public class AdminLoginRequest {
    
    @Schema(description = "Admin email address", example = "admin@electricitybill.com", required = true)
    private String email;
    
    @Schema(description = "Admin password", example = "admin123", required = true)
    private String password;
    
    // Default constructor
    public AdminLoginRequest() {}
    
    // Constructor with parameters
    public AdminLoginRequest(String email, String password) {
        this.email = email;
        this.password = password;
    }
    
    // Getters and Setters
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    @Override
    public String toString() {
        return "AdminLoginRequest{" +
                "email='" + email + '\'' +
                ", password='[PROTECTED]'" +
                '}';
    }
}
