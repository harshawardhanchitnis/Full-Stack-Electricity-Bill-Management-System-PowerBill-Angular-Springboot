package com.electricitybill.admin.controller;

import com.electricitybill.admin.client.CustomerServiceClient;
import com.electricitybill.admin.dto.AdminLoginRequest;
import com.electricitybill.admin.dto.BillGenerationRequest;
import com.electricitybill.admin.model.Bill;
import com.electricitybill.admin.service.AdminService;
import com.electricitybill.admin.service.BillService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Admin Controller for Admin Service
 *
 * Handles admin-related operations:
 * - Admin login
 * - Customer dashboard
 * - Bill management
 * - Complaint support
 */
@RestController
@RequestMapping("/api/admin")
@Tag(name = "Admin Management", description = "Admin login, customer management, and bill operations")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private BillService billService;

    @Autowired
    private CustomerServiceClient customerServiceClient;

    @GetMapping("/health")
    @Operation(summary = "Health check for Admin Service")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Admin Service is running");
        response.put("data", "OK");
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    @Operation(summary = "Admin login", description = "Authenticate admin user with email and password")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Login successful"),
        @ApiResponse(responseCode = "401", description = "Invalid credentials")
    })
    public ResponseEntity<Map<String, Object>> login(@Valid @RequestBody AdminLoginRequest request) {
        try {
            AdminService.AdminLoginResponse loginResponse = adminService.login(request.getEmail(), request.getPassword());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Admin login successful");
            response.put("data", loginResponse);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Admin login failed: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
    }

    @GetMapping("/dashboard")
    @Operation(summary = "Get admin dashboard with all customers data")
    public ResponseEntity<Map<String, Object>> getDashboard() {
        try {
            // Get customer data from customer service
            Map<String, Object> customersResponse = new HashMap<>();
            try {
                ResponseEntity<Map<String, Object>> customerServiceResponse = customerServiceClient.getAllCustomers();
                customersResponse = customerServiceResponse.getBody();
            } catch (Exception e) {
                customersResponse.put("error", "Customer service unavailable: " + e.getMessage());
            }

            // Get bill statistics
            List<Bill> allBills = billService.getAllBills();
            List<Bill> pendingBills = billService.getBillsByPaymentStatus(Bill.PaymentStatus.PENDING);
            List<Bill> paidBills = billService.getBillsByPaymentStatus(Bill.PaymentStatus.PAID);

            Map<String, Object> billStats = new HashMap<>();
            billStats.put("totalBills", allBills.size());
            billStats.put("pendingBills", pendingBills.size());
            billStats.put("paidBills", paidBills.size());

            Map<String, Object> dashboardData = new HashMap<>();
            dashboardData.put("customers", customersResponse);
            dashboardData.put("billStatistics", billStats);
            dashboardData.put("recentBills", allBills.stream().limit(10).toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Admin dashboard data retrieved successfully");
            response.put("data", dashboardData);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve dashboard data: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/bills/generate")
    @Operation(summary = "Generate electricity bill for a customer", description = "Generate a new electricity bill for a specific customer")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Bill generated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid request data")
    })
    public ResponseEntity<Map<String, Object>> generateBill(@Valid @RequestBody BillGenerationRequest request) {
        try {
            String consumerId = request.getConsumerId();
            String month = request.getMonth();
            Integer year = request.getYear();
            Integer unitsConsumed = request.getUnitsConsumed();
            Double ratePerUnit = request.getRatePerUnit();

            Bill.BillMonth billMonth = Bill.BillMonth.valueOf(month.toUpperCase());
            BigDecimal rate = BigDecimal.valueOf(ratePerUnit);

            Bill generatedBill = billService.generateBill(consumerId, billMonth, year, unitsConsumed, rate);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bill generated successfully");
            response.put("data", generatedBill);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Bill generation failed: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @GetMapping("/bills/status")
    @Operation(summary = "Check status of user bills (paid or not)")
    public ResponseEntity<Map<String, Object>> getBillStatus() {
        try {
            List<Bill> pendingBills = billService.getBillsByPaymentStatus(Bill.PaymentStatus.PENDING);
            List<Bill> paidBills = billService.getBillsByPaymentStatus(Bill.PaymentStatus.PAID);
            List<Bill> overdueBills = billService.getBillsByPaymentStatus(Bill.PaymentStatus.OVERDUE);

            Map<String, Object> billStatus = new HashMap<>();
            billStatus.put("pending", pendingBills);
            billStatus.put("paid", paidBills);
            billStatus.put("overdue", overdueBills);
            billStatus.put("totalPending", pendingBills.size());
            billStatus.put("totalPaid", paidBills.size());
            billStatus.put("totalOverdue", overdueBills.size());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bill status retrieved successfully");
            response.put("data", billStatus);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve bill status: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/bills/paid")
    @Operation(summary = "Get paid bill data with customer data")
    public ResponseEntity<Map<String, Object>> getPaidBills() {
        try {
            List<Bill> paidBills = billService.getPaidBillsWithCustomerData();

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Paid bills retrieved successfully");
            response.put("data", paidBills);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve paid bills: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/complaints")
    @Operation(summary = "Get all customer complaints for support")
    public ResponseEntity<Map<String, Object>> getComplaints() {
        try {
            Map<String, Object> response = new HashMap<>();

            try {
                ResponseEntity<Map<String, Object>> customerServiceResponse = customerServiceClient.getAllComplaints();
                Map<String, Object> customerData = customerServiceResponse.getBody();

                if (customerData != null && Boolean.TRUE.equals(customerData.get("success"))) {
                    // Extract the actual complaints data from customer service response
                    Object complaintsData = customerData.get("data");
                    response.put("success", true);
                    response.put("message", "Complaints retrieved successfully");
                    response.put("data", complaintsData);
                } else {
                    response.put("success", false);
                    response.put("message", "Failed to retrieve complaints from customer service");
                    response.put("data", null);
                }
            } catch (Exception e) {
                response.put("success", false);
                response.put("message", "Customer service unavailable: " + e.getMessage());
                response.put("data", null);
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to retrieve complaints: " + e.getMessage());
            response.put("data", null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
