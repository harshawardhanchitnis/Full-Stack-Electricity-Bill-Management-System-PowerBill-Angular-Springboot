package com.electricitybill.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Eureka Server Application for Electricity Bill Management System
 * 
 * This service acts as a service registry and discovery server for all microservices
 * in the electricity bill management system.
 * 
 * Services that will register with this Eureka Server:
 * - customer-service (Port 8081)
 * - admin-service (Port 8082)
 * 
 * Eureka Server runs on port 8761 by default
 */
@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurekaServerApplication.class, args);
        System.out.println("=================================================");
        System.out.println("🚀 EUREKA SERVER STARTED SUCCESSFULLY!");
        System.out.println("📍 Server URL: http://localhost:8761");
        System.out.println("🌐 Eureka Dashboard: http://localhost:8761");
        System.out.println("=================================================");
    }
}
