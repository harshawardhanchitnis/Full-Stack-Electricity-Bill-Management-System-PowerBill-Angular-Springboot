package com.electricitybill.customer.service;

import com.electricitybill.customer.dto.ComplaintRequest;
import com.electricitybill.customer.model.Complaint;
import com.electricitybill.customer.repository.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

/**
 * Service class for Complaint operations
 */
@Service
@Transactional
public class ComplaintService {
    
    @Autowired
    private ComplaintRepository complaintRepository;
    
    /**
     * Register a new complaint
     */
    public Complaint registerComplaint(ComplaintRequest request) {
        Complaint complaint = new Complaint();
        complaint.setComplaintId(generateComplaintId());
        complaint.setConsumerId(request.getConsumerId());
        complaint.setCustomerName(request.getCustomerName());
        complaint.setContactNumber(request.getContactNumber());
        complaint.setAddress(request.getAddress());
        complaint.setLandmark(request.getLandmark());
        complaint.setComplaintType(request.getComplaintType());
        complaint.setCategory(request.getCategory() != null ? request.getCategory() : Complaint.ComplaintCategory.MEDIUM);
        complaint.setProblem(request.getProblem());
        complaint.setStatus(Complaint.ComplaintStatus.OPEN);
        complaint.setCreatedDate(LocalDateTime.now());
        complaint.setUpdatedDate(LocalDateTime.now());
        
        return complaintRepository.save(complaint);
    }
    
    /**
     * Get complaint by complaint ID
     */
    public Complaint getComplaintById(String complaintId) {
        return complaintRepository.findByComplaintId(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found with ID: " + complaintId));
    }
    
    /**
     * Get all complaints for a consumer
     */
    public List<Complaint> getComplaintsByConsumerId(String consumerId) {
        return complaintRepository.findByConsumerId(consumerId);
    }
    
    /**
     * Get open complaints for a consumer
     */
    public List<Complaint> getOpenComplaintsByConsumerId(String consumerId) {
        return complaintRepository.findOpenComplaintsByConsumerId(consumerId);
    }
    
    /**
     * Get resolved complaints for a consumer
     */
    public List<Complaint> getResolvedComplaintsByConsumerId(String consumerId) {
        return complaintRepository.findResolvedComplaintsByConsumerId(consumerId);
    }
    
    /**
     * Get complaint status
     */
    public Complaint.ComplaintStatus getComplaintStatus(String complaintId) {
        Complaint complaint = getComplaintById(complaintId);
        return complaint.getStatus();
    }
    
    /**
     * Update complaint status (for admin use)
     */
    public Complaint updateComplaintStatus(String complaintId, Complaint.ComplaintStatus status, String resolution) {
        Complaint complaint = getComplaintById(complaintId);
        complaint.setStatus(status);
        complaint.setUpdatedDate(LocalDateTime.now());
        
        if (resolution != null && !resolution.trim().isEmpty()) {
            complaint.setResolution(resolution);
        }
        
        if (status == Complaint.ComplaintStatus.RESOLVED || status == Complaint.ComplaintStatus.CLOSED) {
            complaint.setResolvedDate(LocalDateTime.now());
        }
        
        return complaintRepository.save(complaint);
    }
    
    /**
     * Get all complaints (for admin use)
     */
    public List<Complaint> getAllComplaints() {
        return complaintRepository.findAll();
    }
    
    /**
     * Get complaints by status
     */
    public List<Complaint> getComplaintsByStatus(Complaint.ComplaintStatus status) {
        return complaintRepository.findByStatus(status);
    }
    
    /**
     * Get complaints by type
     */
    public List<Complaint> getComplaintsByType(Complaint.ComplaintType type) {
        return complaintRepository.findByComplaintType(type);
    }
    
    /**
     * Get complaints by category
     */
    public List<Complaint> getComplaintsByCategory(Complaint.ComplaintCategory category) {
        return complaintRepository.findByCategory(category);
    }
    
    /**
     * Search complaints by customer name
     */
    public List<Complaint> searchComplaintsByCustomerName(String customerName) {
        return complaintRepository.findByCustomerNameContainingIgnoreCase(customerName);
    }
    
    /**
     * Count complaints by status
     */
    public Long countComplaintsByStatus(Complaint.ComplaintStatus status) {
        return complaintRepository.countByStatus(status);
    }
    
    /**
     * Count complaints by consumer ID
     */
    public Long countComplaintsByConsumerId(String consumerId) {
        return complaintRepository.countByConsumerId(consumerId);
    }
    
    /**
     * Generate unique complaint ID
     */
    private String generateComplaintId() {
        String prefix = "CMP";
        Random random = new Random();
        String suffix = String.format("%06d", random.nextInt(1000000));
        String complaintId = prefix + suffix;
        
        // Check if already exists, regenerate if needed
        while (complaintRepository.findByComplaintId(complaintId).isPresent()) {
            suffix = String.format("%06d", random.nextInt(1000000));
            complaintId = prefix + suffix;
        }
        
        return complaintId;
    }
}
