package com.electricitybill.customer.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Feign Client for communicating with Admin Service
 */
@FeignClient(name = "admin-service", url = "http://localhost:8082")
public interface AdminServiceClient {
    
    /**
     * Get bills for a specific consumer
     */
    @GetMapping("/api/admin/bills/consumer/{consumerId}")
    ResponseEntity<Map<String, Object>> getBillsByConsumerId(@PathVariable("consumerId") String consumerId);
    
    /**
     * Get pending bills for a specific consumer
     */
    @GetMapping("/api/admin/bills/consumer/{consumerId}/pending")
    ResponseEntity<Map<String, Object>> getPendingBillsByConsumerId(@PathVariable("consumerId") String consumerId);
    
    /**
     * Get paid bills for a specific consumer
     */
    @GetMapping("/api/admin/bills/consumer/{consumerId}/paid")
    ResponseEntity<Map<String, Object>> getPaidBillsByConsumerId(@PathVariable("consumerId") String consumerId);
    
    /**
     * Get bill details by bill ID
     */
    @GetMapping("/api/admin/bills/{billId}")
    ResponseEntity<Map<String, Object>> getBillById(@PathVariable("billId") String billId);
    
    /**
     * Pay a bill
     */
    @PostMapping("/api/admin/bills/{billId}/pay")
    ResponseEntity<Map<String, Object>> payBill(@PathVariable("billId") String billId, @RequestBody Map<String, Object> paymentRequest);
    
    /**
     * Get bill payment history for a consumer
     */
    @GetMapping("/api/admin/bills/consumer/{consumerId}/history")
    ResponseEntity<Map<String, Object>> getBillHistory(@PathVariable("consumerId") String consumerId);
    
    /**
     * Get total pending amount for a consumer
     */
    @GetMapping("/api/admin/bills/consumer/{consumerId}/total-pending")
    ResponseEntity<Map<String, Object>> getTotalPendingAmount(@PathVariable("consumerId") String consumerId);
    
    /**
     * Check if admin service is available
     */
    @GetMapping("/api/admin/health")
    ResponseEntity<Map<String, Object>> checkAdminServiceHealth();
}
