package com.electricitybill.customer.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

/**
 * Complaint Entity for Customer Service
 * 
 * Represents customer complaints in the electricity bill management system
 */
@Entity
@Table(name = "complaint")
public class Complaint {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "complaint_id", unique = true, nullable = false)
    private String complaintId;
    
    @Column(name = "consumer_id", nullable = false)
    private String consumerId;
    
    @NotBlank(message = "Customer name is required")
    @Column(name = "customer_name")
    private String customerName;
    
    @NotBlank(message = "Contact number is required")
    @Column(name = "contact_number")
    private String contactNumber;
    
    @NotBlank(message = "Address is required")
    @Column(length = 500)
    private String address;
    
    private String landmark;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "complaint_type", nullable = false)
    private ComplaintType complaintType;
    
    @Enumerated(EnumType.STRING)
    private ComplaintCategory category;
    
    @NotBlank(message = "Problem description is required")
    @Column(length = 1000)
    private String problem;
    
    @Column(length = 1000)
    private String resolution;
    
    @Enumerated(EnumType.STRING)
    private ComplaintStatus status = ComplaintStatus.OPEN;
    
    @Column(name = "created_date")
    private LocalDateTime createdDate;
    
    @Column(name = "updated_date")
    private LocalDateTime updatedDate;
    
    @Column(name = "resolved_date")
    private LocalDateTime resolvedDate;
    
    // Constructors
    public Complaint() {
        this.createdDate = LocalDateTime.now();
        this.updatedDate = LocalDateTime.now();
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getComplaintId() { return complaintId; }
    public void setComplaintId(String complaintId) { this.complaintId = complaintId; }
    
    public String getConsumerId() { return consumerId; }
    public void setConsumerId(String consumerId) { this.consumerId = consumerId; }
    
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getLandmark() { return landmark; }
    public void setLandmark(String landmark) { this.landmark = landmark; }
    
    public ComplaintType getComplaintType() { return complaintType; }
    public void setComplaintType(ComplaintType complaintType) { this.complaintType = complaintType; }
    
    public ComplaintCategory getCategory() { return category; }
    public void setCategory(ComplaintCategory category) { this.category = category; }
    
    public String getProblem() { return problem; }
    public void setProblem(String problem) { this.problem = problem; }
    
    public String getResolution() { return resolution; }
    public void setResolution(String resolution) { this.resolution = resolution; }
    
    public ComplaintStatus getStatus() { return status; }
    public void setStatus(ComplaintStatus status) { this.status = status; }
    
    public LocalDateTime getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDateTime createdDate) { this.createdDate = createdDate; }
    
    public LocalDateTime getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(LocalDateTime updatedDate) { this.updatedDate = updatedDate; }
    
    public LocalDateTime getResolvedDate() { return resolvedDate; }
    public void setResolvedDate(LocalDateTime resolvedDate) { this.resolvedDate = resolvedDate; }
    
    @PreUpdate
    public void preUpdate() {
        this.updatedDate = LocalDateTime.now();
    }
    
    // Enums
    public enum ComplaintType {
        BILLING, CONNECTION, POWER_OUTAGE, METER_READING, TECHNICAL, OTHER
    }
    
    public enum ComplaintCategory {
        HIGH, MEDIUM, LOW
    }
    
    public enum ComplaintStatus {
        OPEN, IN_PROGRESS, RESOLVED, CLOSED
    }
}
