package com.electricitybill.customer.repository;

import com.electricitybill.customer.model.Complaint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Complaint entity
 */
@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Long> {
    
    /**
     * Find complaint by complaint ID
     */
    Optional<Complaint> findByComplaintId(String complaintId);
    
    /**
     * Find complaints by consumer ID
     */
    List<Complaint> findByConsumerId(String consumerId);
    
    /**
     * Find complaints by status
     */
    List<Complaint> findByStatus(Complaint.ComplaintStatus status);
    
    /**
     * Find complaints by type
     */
    List<Complaint> findByComplaintType(Complaint.ComplaintType complaintType);
    
    /**
     * Find complaints by category
     */
    List<Complaint> findByCategory(Complaint.ComplaintCategory category);
    
    /**
     * Find complaints by consumer ID and status
     */
    List<Complaint> findByConsumerIdAndStatus(String consumerId, Complaint.ComplaintStatus status);
    
    /**
     * Find open complaints for a consumer
     */
    @Query("SELECT c FROM Complaint c WHERE c.consumerId = :consumerId AND c.status IN ('OPEN', 'IN_PROGRESS')")
    List<Complaint> findOpenComplaintsByConsumerId(@Param("consumerId") String consumerId);
    
    /**
     * Find resolved complaints for a consumer
     */
    @Query("SELECT c FROM Complaint c WHERE c.consumerId = :consumerId AND c.status IN ('RESOLVED', 'CLOSED')")
    List<Complaint> findResolvedComplaintsByConsumerId(@Param("consumerId") String consumerId);
    
    /**
     * Count complaints by status
     */
    @Query("SELECT COUNT(c) FROM Complaint c WHERE c.status = :status")
    Long countByStatus(@Param("status") Complaint.ComplaintStatus status);
    
    /**
     * Count complaints by consumer ID
     */
    Long countByConsumerId(String consumerId);
    
    /**
     * Find complaints by customer name (case insensitive)
     */
    @Query("SELECT c FROM Complaint c WHERE LOWER(c.customerName) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Complaint> findByCustomerNameContainingIgnoreCase(@Param("name") String name);
}
