package com.electricitybill.customer.controller;

import com.electricitybill.customer.dto.ApiResponse;
import com.electricitybill.customer.service.BillService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Bill Controller for Customer Service
 *
 * Handles bill-related operations for customers:
 * - View bills
 * - Pay bills
 * - Bill history
 */
@RestController
@RequestMapping("/api/customers/bills")
@Tag(name = "Customer Bills", description = "Bill viewing and payment operations for customers")
public class BillController {

    @Autowired
    private BillService billService;

    @GetMapping("/consumer/{consumerId}")
    @Operation(summary = "Get all bills for a consumer")
    public ResponseEntity<ApiResponse<Object>> getAllBills(@PathVariable String consumerId) {
        try {
            Map<String, Object> adminResponse = billService.getBillsByConsumerId(consumerId);

            // Extract data from admin service response to avoid double wrapping
            if (adminResponse != null && Boolean.TRUE.equals(adminResponse.get("success"))) {
                Object billsData = adminResponse.get("data");
                return ResponseEntity.ok(ApiResponse.success("Bills retrieved successfully", billsData));
            } else {
                String errorMessage = adminResponse != null ? (String) adminResponse.get("message") : "Unknown error";
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(ApiResponse.error("Failed to retrieve bills: " + errorMessage));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve bills: " + e.getMessage()));
        }
    }

    @GetMapping("/consumer/{consumerId}/pending")
    @Operation(summary = "Get pending bills for a consumer")
    public ResponseEntity<ApiResponse<Object>> getPendingBills(@PathVariable String consumerId) {
        try {
            Map<String, Object> adminResponse = billService.getPendingBills(consumerId);

            // Extract data from admin service response to avoid double wrapping
            if (adminResponse != null && Boolean.TRUE.equals(adminResponse.get("success"))) {
                Object billsData = adminResponse.get("data");
                return ResponseEntity.ok(ApiResponse.success("Pending bills retrieved successfully", billsData));
            } else {
                String errorMessage = adminResponse != null ? (String) adminResponse.get("message") : "Unknown error";
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(ApiResponse.error("Failed to retrieve pending bills: " + errorMessage));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve pending bills: " + e.getMessage()));
        }
    }

    @GetMapping("/consumer/{consumerId}/paid")
    @Operation(summary = "Get paid bills for a consumer")
    public ResponseEntity<ApiResponse<Object>> getPaidBills(@PathVariable String consumerId) {
        try {
            Map<String, Object> adminResponse = billService.getPaidBills(consumerId);

            // Extract data from admin service response to avoid double wrapping
            if (adminResponse != null && Boolean.TRUE.equals(adminResponse.get("success"))) {
                Object billsData = adminResponse.get("data");
                return ResponseEntity.ok(ApiResponse.success("Paid bills retrieved successfully", billsData));
            } else {
                String errorMessage = adminResponse != null ? (String) adminResponse.get("message") : "Unknown error";
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(ApiResponse.error("Failed to retrieve paid bills: " + errorMessage));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve paid bills: " + e.getMessage()));
        }
    }

    @GetMapping("/{billId}")
    @Operation(summary = "Get bill details by bill ID")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getBillById(@PathVariable String billId) {
        try {
            Map<String, Object> bill = billService.getBillById(billId);
            return ResponseEntity.ok(ApiResponse.success("Bill details retrieved successfully", bill));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error("Bill not found: " + e.getMessage()));
        }
    }

    @PostMapping("/{billId}/pay")
    @Operation(summary = "Pay a bill")
    public ResponseEntity<ApiResponse<Object>> payBill(
            @PathVariable String billId,
            @RequestParam String paymentMethod,
            @RequestParam String transactionReference,
            @RequestParam Double amount) {
        try {
            Map<String, Object> adminResponse = billService.payBill(billId, paymentMethod, transactionReference, amount);

            // Extract data from admin service response to avoid double wrapping
            if (adminResponse != null && Boolean.TRUE.equals(adminResponse.get("success"))) {
                Object paymentData = adminResponse.get("data");
                return ResponseEntity.ok(ApiResponse.success("Payment processed successfully", paymentData));
            } else {
                String errorMessage = adminResponse != null ? (String) adminResponse.get("message") : "Unknown error";
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(ApiResponse.error("Payment failed: " + errorMessage));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error("Payment failed: " + e.getMessage()));
        }
    }

    @GetMapping("/consumer/{consumerId}/history")
    @Operation(summary = "Get bill payment history for a consumer")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getBillHistory(@PathVariable String consumerId) {
        try {
            Map<String, Object> history = billService.getBillHistory(consumerId);
            return ResponseEntity.ok(ApiResponse.success("Bill history retrieved successfully", history));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve bill history: " + e.getMessage()));
        }
    }

    @GetMapping("/consumer/{consumerId}/total-pending")
    @Operation(summary = "Get total pending amount for a consumer")
    public ResponseEntity<ApiResponse<Object>> getTotalPendingAmount(@PathVariable String consumerId) {
        try {
            Map<String, Object> adminResponse = billService.getTotalPendingAmount(consumerId);

            // Extract data from admin service response to avoid double wrapping
            if (adminResponse != null && Boolean.TRUE.equals(adminResponse.get("success"))) {
                Object totalPendingData = adminResponse.get("data");
                return ResponseEntity.ok(ApiResponse.success("Total pending amount retrieved successfully", totalPendingData));
            } else {
                String errorMessage = adminResponse != null ? (String) adminResponse.get("message") : "Unknown error";
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(ApiResponse.error("Failed to retrieve total pending amount: " + errorMessage));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve total pending amount: " + e.getMessage()));
        }
    }
}
