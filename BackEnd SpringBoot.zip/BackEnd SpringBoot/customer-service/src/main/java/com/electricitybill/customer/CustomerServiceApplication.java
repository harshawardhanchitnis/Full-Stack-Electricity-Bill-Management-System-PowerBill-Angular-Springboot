package com.electricitybill.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Customer Service Application for Electricity Bill Management System
 * 
 * This microservice handles:
 * - Customer login and registration
 * - Customer dashboard
 * - Pay bills (provided by admin service)
 * - View bills history
 * - Customer profile management
 * - Complaint registration
 * - Search complaint by ID
 * - Check complaint status
 * 
 * Runs on port 8081 and registers with Eureka Server on port 8761
 */
@SpringBootApplication
@EnableFeignClients
public class CustomerServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomerServiceApplication.class, args);
        System.out.println("=================================================");
        System.out.println("🚀 CUSTOMER SERVICE STARTED SUCCESSFULLY!");
        System.out.println("📍 Service URL: http://localhost:8081");
        System.out.println("🌐 Swagger UI: http://localhost:8081/swagger-ui/index.html");
        System.out.println("🔗 Eureka Server: http://localhost:8761");
        System.out.println("=================================================");
    }
}
