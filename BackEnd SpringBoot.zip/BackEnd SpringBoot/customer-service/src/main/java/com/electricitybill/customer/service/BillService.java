package com.electricitybill.customer.service;

import com.electricitybill.customer.client.AdminServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service class for Bill operations in Customer Service
 * Communicates with Admin Service for bill-related operations
 */
@Service
public class BillService {
    
    @Autowired
    private AdminServiceClient adminServiceClient;
    
    /**
     * Get all bills for a consumer
     */
    public Map<String, Object> getBillsByConsumerId(String consumerId) {
        try {
            ResponseEntity<Map<String, Object>> response = adminServiceClient.getBillsByConsumerId(consumerId);
            return response.getBody();
        } catch (Exception e) {
            return createErrorResponse("Failed to fetch bills: " + e.getMessage());
        }
    }
    
    /**
     * Get pending bills for a consumer
     */
    public Map<String, Object> getPendingBills(String consumerId) {
        try {
            ResponseEntity<Map<String, Object>> response = adminServiceClient.getPendingBillsByConsumerId(consumerId);
            return response.getBody();
        } catch (Exception e) {
            return createErrorResponse("Failed to fetch pending bills: " + e.getMessage());
        }
    }
    
    /**
     * Get paid bills for a consumer
     */
    public Map<String, Object> getPaidBills(String consumerId) {
        try {
            ResponseEntity<Map<String, Object>> response = adminServiceClient.getPaidBillsByConsumerId(consumerId);
            return response.getBody();
        } catch (Exception e) {
            return createErrorResponse("Failed to fetch paid bills: " + e.getMessage());
        }
    }
    
    /**
     * Get bill details by bill ID
     */
    public Map<String, Object> getBillById(String billId) {
        try {
            ResponseEntity<Map<String, Object>> response = adminServiceClient.getBillById(billId);
            return response.getBody();
        } catch (Exception e) {
            return createErrorResponse("Failed to fetch bill details: " + e.getMessage());
        }
    }
    
    /**
     * Pay a bill
     */
    public Map<String, Object> payBill(String billId, String paymentMethod, String transactionReference, Double amount) {
        try {
            Map<String, Object> paymentRequest = new HashMap<>();
            paymentRequest.put("paymentMethod", paymentMethod);
            paymentRequest.put("transactionReference", transactionReference);
            paymentRequest.put("amount", amount);
            
            ResponseEntity<Map<String, Object>> response = adminServiceClient.payBill(billId, paymentRequest);
            return response.getBody();
        } catch (Exception e) {
            return createErrorResponse("Failed to process payment: " + e.getMessage());
        }
    }
    
    /**
     * Get bill payment history for a consumer
     */
    public Map<String, Object> getBillHistory(String consumerId) {
        try {
            ResponseEntity<Map<String, Object>> response = adminServiceClient.getBillHistory(consumerId);
            return response.getBody();
        } catch (Exception e) {
            return createErrorResponse("Failed to fetch bill history: " + e.getMessage());
        }
    }
    
    /**
     * Get total pending amount for a consumer
     */
    public Map<String, Object> getTotalPendingAmount(String consumerId) {
        try {
            ResponseEntity<Map<String, Object>> response = adminServiceClient.getTotalPendingAmount(consumerId);
            return response.getBody();
        } catch (Exception e) {
            return createErrorResponse("Failed to fetch total pending amount: " + e.getMessage());
        }
    }
    
    /**
     * Check if admin service is available
     */
    public boolean isAdminServiceAvailable() {
        try {
            ResponseEntity<Map<String, Object>> response = adminServiceClient.checkAdminServiceHealth();
            return response.getStatusCode().is2xxSuccessful();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Create error response
     */
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("success", false);
        errorResponse.put("message", message);
        errorResponse.put("data", null);
        return errorResponse;
    }
}
