package com.electricitybill.customer.controller;

import com.electricitybill.customer.dto.ApiResponse;
import com.electricitybill.customer.dto.CustomerRegistrationRequest;
import com.electricitybill.customer.dto.LoginRequest;
import com.electricitybill.customer.model.Customer;
import com.electricitybill.customer.service.CustomerService;
import com.electricitybill.customer.service.BillService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Customer Controller for Customer Service
 *
 * Handles customer-related operations:
 * - Login and Registration
 * - Dashboard
 * - Profile management
 */
@RestController
@RequestMapping("/api/customers")
@Tag(name = "Customer Management", description = "Customer registration, login, and profile management")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private BillService billService;

    @GetMapping("/health")
    @Operation(summary = "Health check for Customer Service")
    public ResponseEntity<ApiResponse<String>> health() {
        return ResponseEntity.ok(ApiResponse.success("Customer Service is running", "OK"));
    }

    @PostMapping("/register")
    @Operation(summary = "Register a new customer")
    public ResponseEntity<ApiResponse<Customer>> registerCustomer(@Valid @RequestBody CustomerRegistrationRequest request) {
        try {
            Customer customer = customerService.registerCustomer(request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Customer registered successfully", customer));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error("Registration failed: " + e.getMessage()));
        }
    }

    @PostMapping("/login")
    @Operation(summary = "Customer login")
    public ResponseEntity<ApiResponse<Customer>> login(@Valid @RequestBody LoginRequest request) {
        try {
            Customer customer = customerService.login(request);
            return ResponseEntity.ok(ApiResponse.success("Login successful", customer));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Login failed: " + e.getMessage()));
        }
    }

    @GetMapping("/dashboard/{consumerId}")
    @Operation(summary = "Get customer dashboard data")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getDashboard(@PathVariable String consumerId) {
        try {
            Customer customer = customerService.getCustomerByConsumerId(consumerId);

            // Get bill information from admin service and extract data properly
            Map<String, Object> pendingBillsResponse = billService.getPendingBills(consumerId);
            Map<String, Object> totalPendingResponse = billService.getTotalPendingAmount(consumerId);

            // Extract actual data from admin service responses
            Object pendingBillsData = null;
            Object totalPendingData = null;

            if (pendingBillsResponse != null && Boolean.TRUE.equals(pendingBillsResponse.get("success"))) {
                pendingBillsData = pendingBillsResponse.get("data");
            }

            if (totalPendingResponse != null && Boolean.TRUE.equals(totalPendingResponse.get("success"))) {
                totalPendingData = totalPendingResponse.get("data");
            }

            // Create dashboard data with extracted data
            Map<String, Object> dashboardData = new HashMap<>();
            dashboardData.put("customer", customer);
            dashboardData.put("pendingBills", pendingBillsData);
            dashboardData.put("totalPending", totalPendingData);
            dashboardData.put("adminServiceAvailable", billService.isAdminServiceAvailable());

            return ResponseEntity.ok(ApiResponse.success("Dashboard data retrieved successfully", dashboardData));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error("Failed to get dashboard data: " + e.getMessage()));
        }
    }

    @GetMapping("/profile/{consumerId}")
    @Operation(summary = "Get customer profile")
    public ResponseEntity<ApiResponse<Customer>> getProfile(@PathVariable String consumerId) {
        try {
            Customer customer = customerService.getCustomerByConsumerId(consumerId);
            return ResponseEntity.ok(ApiResponse.success("Profile retrieved successfully", customer));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error("Profile not found: " + e.getMessage()));
        }
    }

    @PutMapping("/profile/{consumerId}")
    @Operation(summary = "Update customer profile")
    public ResponseEntity<ApiResponse<Customer>> updateProfile(@PathVariable String consumerId,
                                                              @Valid @RequestBody CustomerRegistrationRequest request) {
        try {
            Customer updatedCustomer = customerService.updateProfile(consumerId, request);
            return ResponseEntity.ok(ApiResponse.success("Profile updated successfully", updatedCustomer));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error("Profile update failed: " + e.getMessage()));
        }
    }

    @GetMapping("/all")
    @Operation(summary = "Get all customers (for admin use)")
    public ResponseEntity<ApiResponse<List<Customer>>> getAllCustomers() {
        try {
            List<Customer> customers = customerService.getAllCustomers();
            return ResponseEntity.ok(ApiResponse.success("All customers retrieved successfully", customers));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve customers: " + e.getMessage()));
        }
    }

    @GetMapping("/active")
    @Operation(summary = "Get active customers")
    public ResponseEntity<ApiResponse<List<Customer>>> getActiveCustomers() {
        try {
            List<Customer> activeCustomers = customerService.getActiveCustomers();
            return ResponseEntity.ok(ApiResponse.success("Active customers retrieved successfully", activeCustomers));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve active customers: " + e.getMessage()));
        }
    }

    @GetMapping("/search")
    @Operation(summary = "Search customers by name")
    public ResponseEntity<ApiResponse<List<Customer>>> searchCustomers(@RequestParam String name) {
        try {
            List<Customer> customers = customerService.searchCustomersByName(name);
            return ResponseEntity.ok(ApiResponse.success("Customers found", customers));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Search failed: " + e.getMessage()));
        }
    }

    @GetMapping("/connection-type/{type}")
    @Operation(summary = "Get customers by connection type")
    public ResponseEntity<ApiResponse<List<Customer>>> getCustomersByConnectionType(@PathVariable String type) {
        try {
            Customer.ConnectionType connectionType = Customer.ConnectionType.valueOf(type.toUpperCase());
            List<Customer> customers = customerService.getCustomersByConnectionType(connectionType);
            return ResponseEntity.ok(ApiResponse.success("Customers retrieved by connection type", customers));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error("Failed to retrieve customers by connection type: " + e.getMessage()));
        }
    }
}
