package com.electricitybill.customer.dto;

import com.electricitybill.customer.model.Complaint;
import jakarta.validation.constraints.NotBlank;

/**
 * DTO for complaint registration request
 */
public class ComplaintRequest {
    
    @NotBlank(message = "Consumer ID is required")
    private String consumerId;
    
    @NotBlank(message = "Customer name is required")
    private String customerName;
    
    @NotBlank(message = "Contact number is required")
    private String contactNumber;
    
    @NotBlank(message = "Address is required")
    private String address;
    
    private String landmark;
    
    private Complaint.ComplaintType complaintType;
    
    private Complaint.ComplaintCategory category;
    
    @NotBlank(message = "Problem description is required")
    private String problem;
    
    // Constructors
    public ComplaintRequest() {}
    
    // Getters and Setters
    public String getConsumerId() { return consumerId; }
    public void setConsumerId(String consumerId) { this.consumerId = consumerId; }
    
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getLandmark() { return landmark; }
    public void setLandmark(String landmark) { this.landmark = landmark; }
    
    public Complaint.ComplaintType getComplaintType() { return complaintType; }
    public void setComplaintType(Complaint.ComplaintType complaintType) { this.complaintType = complaintType; }
    
    public Complaint.ComplaintCategory getCategory() { return category; }
    public void setCategory(Complaint.ComplaintCategory category) { this.category = category; }
    
    public String getProblem() { return problem; }
    public void setProblem(String problem) { this.problem = problem; }
}
