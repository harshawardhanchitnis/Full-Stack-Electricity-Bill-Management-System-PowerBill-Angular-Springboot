package com.electricitybill.customer.repository;

import com.electricitybill.customer.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Customer entity
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    
    /**
     * Find customer by email
     */
    Optional<Customer> findByEmail(String email);
    
    /**
     * Find customer by consumer ID
     */
    Optional<Customer> findByConsumerId(String consumerId);
    
    /**
     * Check if email exists
     */
    boolean existsByEmail(String email);
    
    /**
     * Check if consumer ID exists
     */
    boolean existsByConsumerId(String consumerId);
    
    /**
     * Find customers by status
     */
    List<Customer> findByStatus(Customer.CustomerStatus status);
    
    /**
     * Find customers by connection type
     */
    List<Customer> findByConnectionType(Customer.ConnectionType connectionType);
    
    /**
     * Find customers by city
     */
    List<Customer> findByCity(String city);
    
    /**
     * Find customers by state
     */
    List<Customer> findByState(String state);
    
    /**
     * Search customers by name (case insensitive)
     */
    @Query("SELECT c FROM Customer c WHERE LOWER(c.customerName) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Customer> findByCustomerNameContainingIgnoreCase(@Param("name") String name);
    
    /**
     * Find active customers
     */
    @Query("SELECT c FROM Customer c WHERE c.status = 'ACTIVE'")
    List<Customer> findActiveCustomers();
    
    /**
     * Count customers by connection type
     */
    @Query("SELECT COUNT(c) FROM Customer c WHERE c.connectionType = :connectionType")
    Long countByConnectionType(@Param("connectionType") Customer.ConnectionType connectionType);
}
