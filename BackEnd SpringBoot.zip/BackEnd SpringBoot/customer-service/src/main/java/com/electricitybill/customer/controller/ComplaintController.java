package com.electricitybill.customer.controller;

import com.electricitybill.customer.dto.ApiResponse;
import com.electricitybill.customer.dto.ComplaintRequest;
import com.electricitybill.customer.model.Complaint;
import com.electricitybill.customer.service.ComplaintService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Complaint Controller for Customer Service
 *
 * Handles complaint-related operations for customers:
 * - Register complaints
 * - Search complaints by ID
 * - Check complaint status
 * - View complaint history
 */
@RestController
@RequestMapping("/api/customers/complaints")
@Tag(name = "Customer Complaints", description = "Complaint registration and tracking for customers")
public class ComplaintController {

    @Autowired
    private ComplaintService complaintService;

    @PostMapping("/register")
    @Operation(summary = "Register a new complaint")
    public ResponseEntity<ApiResponse<Complaint>> registerComplaint(@Valid @RequestBody ComplaintRequest request) {
        try {
            Complaint complaint = complaintService.registerComplaint(request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Complaint registered successfully", complaint));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error("Failed to register complaint: " + e.getMessage()));
        }
    }

    @GetMapping("/{complaintId}")
    @Operation(summary = "Search complaint by ID")
    public ResponseEntity<ApiResponse<Complaint>> getComplaintById(@PathVariable String complaintId) {
        try {
            Complaint complaint = complaintService.getComplaintById(complaintId);
            return ResponseEntity.ok(ApiResponse.success("Complaint found", complaint));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error("Complaint not found: " + e.getMessage()));
        }
    }

    @GetMapping("/{complaintId}/status")
    @Operation(summary = "Check complaint status")
    public ResponseEntity<ApiResponse<Complaint.ComplaintStatus>> getComplaintStatus(@PathVariable String complaintId) {
        try {
            Complaint.ComplaintStatus status = complaintService.getComplaintStatus(complaintId);
            return ResponseEntity.ok(ApiResponse.success("Complaint status retrieved", status));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error("Complaint not found: " + e.getMessage()));
        }
    }

    @GetMapping("/consumer/{consumerId}")
    @Operation(summary = "Get all complaints for a consumer")
    public ResponseEntity<ApiResponse<List<Complaint>>> getComplaintsByConsumerId(@PathVariable String consumerId) {
        try {
            List<Complaint> complaints = complaintService.getComplaintsByConsumerId(consumerId);
            return ResponseEntity.ok(ApiResponse.success("Complaints retrieved successfully", complaints));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve complaints: " + e.getMessage()));
        }
    }

    @GetMapping("/consumer/{consumerId}/open")
    @Operation(summary = "Get open complaints for a consumer")
    public ResponseEntity<ApiResponse<List<Complaint>>> getOpenComplaintsByConsumerId(@PathVariable String consumerId) {
        try {
            List<Complaint> openComplaints = complaintService.getOpenComplaintsByConsumerId(consumerId);
            return ResponseEntity.ok(ApiResponse.success("Open complaints retrieved successfully", openComplaints));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve open complaints: " + e.getMessage()));
        }
    }

    @GetMapping("/consumer/{consumerId}/resolved")
    @Operation(summary = "Get resolved complaints for a consumer")
    public ResponseEntity<ApiResponse<List<Complaint>>> getResolvedComplaintsByConsumerId(@PathVariable String consumerId) {
        try {
            List<Complaint> resolvedComplaints = complaintService.getResolvedComplaintsByConsumerId(consumerId);
            return ResponseEntity.ok(ApiResponse.success("Resolved complaints retrieved successfully", resolvedComplaints));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve resolved complaints: " + e.getMessage()));
        }
    }

    @GetMapping("/consumer/{consumerId}/count")
    @Operation(summary = "Get complaint count for a consumer")
    public ResponseEntity<ApiResponse<Long>> getComplaintCount(@PathVariable String consumerId) {
        try {
            Long count = complaintService.countComplaintsByConsumerId(consumerId);
            return ResponseEntity.ok(ApiResponse.success("Complaint count retrieved successfully", count));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve complaint count: " + e.getMessage()));
        }
    }

    @GetMapping("/all")
    @Operation(summary = "Get all complaints (for admin use)")
    public ResponseEntity<ApiResponse<List<Complaint>>> getAllComplaints() {
        try {
            List<Complaint> complaints = complaintService.getAllComplaints();
            return ResponseEntity.ok(ApiResponse.success("All complaints retrieved successfully", complaints));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve complaints: " + e.getMessage()));
        }
    }

    @GetMapping("/status/{status}")
    @Operation(summary = "Get complaints by status")
    public ResponseEntity<ApiResponse<List<Complaint>>> getComplaintsByStatus(@PathVariable String status) {
        try {
            Complaint.ComplaintStatus complaintStatus = Complaint.ComplaintStatus.valueOf(status.toUpperCase());
            List<Complaint> complaints = complaintService.getComplaintsByStatus(complaintStatus);
            return ResponseEntity.ok(ApiResponse.success("Complaints retrieved by status", complaints));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error("Failed to retrieve complaints by status: " + e.getMessage()));
        }
    }

    @PutMapping("/{complaintId}/status")
    @Operation(summary = "Update complaint status (admin operation)")
    public ResponseEntity<ApiResponse<Complaint>> updateComplaintStatus(
            @PathVariable String complaintId,
            @RequestBody Map<String, Object> statusUpdate) {
        try {
            String status = (String) statusUpdate.get("status");
            String resolution = (String) statusUpdate.get("resolution");

            Complaint.ComplaintStatus complaintStatus = Complaint.ComplaintStatus.valueOf(status.toUpperCase());
            Complaint updatedComplaint = complaintService.updateComplaintStatus(complaintId, complaintStatus, resolution);

            return ResponseEntity.ok(ApiResponse.success("Complaint status updated successfully", updatedComplaint));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error("Failed to update complaint status: " + e.getMessage()));
        }
    }
}
