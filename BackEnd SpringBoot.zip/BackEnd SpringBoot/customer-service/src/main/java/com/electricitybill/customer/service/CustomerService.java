package com.electricitybill.customer.service;

import com.electricitybill.customer.dto.CustomerRegistrationRequest;
import com.electricitybill.customer.dto.LoginRequest;
import com.electricitybill.customer.model.Customer;
import com.electricitybill.customer.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * Service class for Customer operations
 */
@Service
@Transactional
public class CustomerService {
    
    @Autowired
    private CustomerRepository customerRepository;
    
    /**
     * Register a new customer
     */
    public Customer registerCustomer(CustomerRegistrationRequest request) {
        // Check if email already exists
        if (customerRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists: " + request.getEmail());
        }
        
        // Create new customer
        Customer customer = new Customer();
        customer.setCustomerName(request.getCustomerName());
        customer.setEmail(request.getEmail());
        customer.setPassword(hashPassword(request.getPassword())); // Simple hash for demo
        customer.setMobileNumber(request.getMobileNumber());
        customer.setAddress(request.getAddress());
        customer.setCity(request.getCity());
        customer.setState(request.getState());
        customer.setPincode(request.getPincode());
        customer.setConnectionType(request.getConnectionType());
        customer.setStatus(Customer.CustomerStatus.ACTIVE);
        
        // Generate unique consumer ID
        customer.setConsumerId(generateConsumerId());
        
        // Save customer
        Customer savedCustomer = customerRepository.save(customer);
        
        // TODO: Trigger bill generation for new customer via admin service
        
        return savedCustomer;
    }
    
    /**
     * Customer login
     */
    public Customer login(LoginRequest request) {
        Optional<Customer> customerOpt = customerRepository.findByEmail(request.getEmail());
        
        if (customerOpt.isEmpty()) {
            throw new RuntimeException("Customer not found with email: " + request.getEmail());
        }
        
        Customer customer = customerOpt.get();
        
        // Check password (simple comparison for demo)
        if (!verifyPassword(request.getPassword(), customer.getPassword())) {
            throw new RuntimeException("Invalid password");
        }
        
        // Check if customer is active
        if (customer.getStatus() != Customer.CustomerStatus.ACTIVE) {
            throw new RuntimeException("Customer account is not active");
        }
        
        return customer;
    }
    
    /**
     * Get customer by consumer ID
     */
    public Customer getCustomerByConsumerId(String consumerId) {
        return customerRepository.findByConsumerId(consumerId)
                .orElseThrow(() -> new RuntimeException("Customer not found with consumer ID: " + consumerId));
    }
    
    /**
     * Get customer by email
     */
    public Customer getCustomerByEmail(String email) {
        return customerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Customer not found with email: " + email));
    }
    
    /**
     * Update customer profile
     */
    public Customer updateProfile(String consumerId, CustomerRegistrationRequest request) {
        Customer customer = getCustomerByConsumerId(consumerId);
        
        // Update fields
        customer.setCustomerName(request.getCustomerName());
        customer.setMobileNumber(request.getMobileNumber());
        customer.setAddress(request.getAddress());
        customer.setCity(request.getCity());
        customer.setState(request.getState());
        customer.setPincode(request.getPincode());
        customer.setConnectionType(request.getConnectionType());
        customer.setUpdatedDate(LocalDateTime.now());
        
        return customerRepository.save(customer);
    }
    
    /**
     * Get all customers (for admin use)
     */
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }
    
    /**
     * Get active customers
     */
    public List<Customer> getActiveCustomers() {
        return customerRepository.findActiveCustomers();
    }
    
    /**
     * Search customers by name
     */
    public List<Customer> searchCustomersByName(String name) {
        return customerRepository.findByCustomerNameContainingIgnoreCase(name);
    }
    
    /**
     * Get customers by connection type
     */
    public List<Customer> getCustomersByConnectionType(Customer.ConnectionType connectionType) {
        return customerRepository.findByConnectionType(connectionType);
    }
    
    /**
     * Generate unique consumer ID
     */
    private String generateConsumerId() {
        String prefix = "CON";
        Random random = new Random();
        String suffix = String.format("%04d", random.nextInt(10000));
        String consumerId = prefix + suffix;
        
        // Check if already exists, regenerate if needed
        while (customerRepository.existsByConsumerId(consumerId)) {
            suffix = String.format("%04d", random.nextInt(10000));
            consumerId = prefix + suffix;
        }
        
        return consumerId;
    }
    
    /**
     * Simple password hashing (for demo purposes)
     */
    private String hashPassword(String password) {
        // In production, use BCrypt or similar
        return "HASH_" + password;
    }
    
    /**
     * Simple password verification (for demo purposes)
     */
    private boolean verifyPassword(String plainPassword, String hashedPassword) {
        // In production, use BCrypt or similar
        return hashedPassword.equals("HASH_" + plainPassword);
    }
}
