export const environment = {
  production: false,

  // Microservices Architecture URLs
  microservices: {
    eureka: 'http://localhost:8761',
    customerService: 'http://localhost:8081',
    adminService: 'http://localhost:8082'
  },

  // API URLs for different services
  apiUrls: {
    // Customer Service APIs (Port 8081)
    customer: 'http://localhost:8081/api/customers',
    customerBills: 'http://localhost:8081/api/customers/bills',
    customerComplaints: 'http://localhost:8081/api/customers/complaints',

    // Admin Service APIs (Port 8082)
    admin: 'http://localhost:8082/api/admin',
    adminBills: 'http://localhost:8082/api/admin/bills',

    // Legacy support (for backward compatibility)
    auth: 'http://localhost:8081/api/customers',
    billing: 'http://localhost:8081/api/customers/bills',
    complaint: 'http://localhost:8081/api/customers/complaints'
  },

  // Swagger Documentation URLs
  swaggerUrls: {
    eureka: 'http://localhost:8761',
    customerService: 'http://localhost:8081/swagger-ui/index.html',
    adminService: 'http://localhost:8082/swagger-ui/index.html',
    customer: 'http://localhost:8081/swagger-ui/index.html',
    auth: 'http://localhost:8081/swagger-ui/index.html',
    billing: 'http://localhost:8081/swagger-ui/index.html',
    complaint: 'http://localhost:8081/swagger-ui/index.html'
  },

  // H2 Database Console URLs
  h2ConsoleUrls: {
    customerService: 'http://localhost:8081/h2-console',
    adminService: 'http://localhost:8082/h2-console',
    customer: 'http://localhost:8081/h2-console',
    auth: 'http://localhost:8081/h2-console',
    billing: 'http://localhost:8081/h2-console',
    complaint: 'http://localhost:8081/h2-console'
  },

  // Service Health Check URLs
  healthUrls: {
    eureka: 'http://localhost:8761',
    customerService: 'http://localhost:8081/api/customers/health',
    adminService: 'http://localhost:8082/api/admin/health'
  }
};
