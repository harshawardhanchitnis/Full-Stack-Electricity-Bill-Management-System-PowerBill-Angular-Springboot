import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { isPlatformBrowser } from '@angular/common';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(
    private authService: AuthService,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    console.log('AuthGuard: Checking authentication for route:', state.url);

    // Check if user is logged in
    const currentUser = this.authService.getCurrentUser();
    console.log('AuthGuard: Current user from service:', currentUser);

    if (currentUser && currentUser.email) {
      console.log('AuthGuard: User is authenticated with email:', currentUser.email);
      return true;
    }

    // Double-check localStorage if we're in browser
    if (isPlatformBrowser(this.platformId)) {
      const savedUser = localStorage.getItem('currentUser');
      console.log('AuthGuard: Checking localStorage:', savedUser ? 'User found' : 'No user');

      if (savedUser) {
        try {
          const user = JSON.parse(savedUser);
          console.log('AuthGuard: Parsed user from localStorage:', user);

          // Validate that the user object has required fields
          if (user && user.email && user.userType) {
            // Update the auth service with the saved user
            this.authService['currentUserSubject'].next(user);
            console.log('AuthGuard: User restored from localStorage');
            return true;
          } else {
            console.log('AuthGuard: Invalid user data in localStorage');
            localStorage.removeItem('currentUser');
          }
        } catch (error) {
          console.error('AuthGuard: Error parsing saved user:', error);
          localStorage.removeItem('currentUser');
        }
      }
    }

    console.log('AuthGuard: No valid authentication found, redirecting to login');
    this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }
}
