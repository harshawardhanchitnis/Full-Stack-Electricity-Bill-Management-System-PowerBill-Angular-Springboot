import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Complaint {
  id: number;
  complaintId: string;
  consumerId: string;
  customerName: string;
  complaintType: string;
  category: string;
  problem: string;
  contactNumber: string;
  address: string;
  landmark?: string;
  status: string;
  resolution?: string;
  createdDate: string;
  updatedDate: string;
  resolvedDate?: string;
}

export interface ComplaintRequest {
  consumerId: string;
  customerName: string;
  complaintType: string;
  category: string;
  problem: string;
  contactNumber: string;
  address: string;
  landmark?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp: string;
}

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {
  private apiUrl = environment.apiUrls.customerComplaints;

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }

  registerComplaint(request: ComplaintRequest): Observable<ApiResponse<Complaint>> {
    return this.http.post<ApiResponse<Complaint>>(`${this.apiUrl}/register`, request, this.httpOptions);
  }

  getComplaintsByConsumerId(consumerId: string): Observable<ApiResponse<Complaint[]>> {
    return this.http.get<ApiResponse<Complaint[]>>(`${this.apiUrl}/consumer/${consumerId}`, this.httpOptions);
  }

  getComplaintById(complaintId: string): Observable<ApiResponse<Complaint>> {
    return this.http.get<ApiResponse<Complaint>>(`${this.apiUrl}/${complaintId}`, this.httpOptions);
  }

  getComplaintStatus(complaintId: string): Observable<ApiResponse<string>> {
    return this.http.get<ApiResponse<string>>(`${this.apiUrl}/${complaintId}/status`, this.httpOptions);
  }

  getOpenComplaintsByConsumerId(consumerId: string): Observable<ApiResponse<Complaint[]>> {
    return this.http.get<ApiResponse<Complaint[]>>(`${this.apiUrl}/consumer/${consumerId}/open`, this.httpOptions);
  }

  getResolvedComplaintsByConsumerId(consumerId: string): Observable<ApiResponse<Complaint[]>> {
    return this.http.get<ApiResponse<Complaint[]>>(`${this.apiUrl}/consumer/${consumerId}/resolved`, this.httpOptions);
  }

  getComplaintCount(consumerId: string): Observable<ApiResponse<number>> {
    return this.http.get<ApiResponse<number>>(`${this.apiUrl}/consumer/${consumerId}/count`, this.httpOptions);
  }

  getAllComplaints(): Observable<ApiResponse<Complaint[]>> {
    return this.http.get<ApiResponse<Complaint[]>>(`${this.apiUrl}/all`, this.httpOptions);
  }

  getComplaintsByStatus(status: string): Observable<ApiResponse<Complaint[]>> {
    return this.http.get<ApiResponse<Complaint[]>>(`${this.apiUrl}/status/${status}`, this.httpOptions);
  }

  updateComplaintStatus(complaintId: string, status: string, resolution?: string): Observable<ApiResponse<Complaint>> {
    const body = {
      status: status,
      resolution: resolution || ''
    };
    return this.http.put<ApiResponse<Complaint>>(`${this.apiUrl}/${complaintId}/status`, body, this.httpOptions);
  }
}
