import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface ApiTestResult {
  service: string;
  endpoint: string;
  status: 'success' | 'error' | 'testing';
  message: string;
  responseTime?: number;
}

@Injectable({
  providedIn: 'root'
})
export class ApiTestService {
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }

  /**
   * Test Spring Boot API connectivity
   */
  testApiConnectivity(): Observable<ApiTestResult[]> {
    const tests: Observable<ApiTestResult>[] = [
      this.testEndpoint('Spring Boot Root', 'http://localhost:8080'),
      this.testEndpoint('Swagger UI', 'http://localhost:8080/swagger-ui/index.html'),
      this.testEndpoint('Customer API', 'http://localhost:8080/api/customers/register', 'POST'),
      this.testEndpoint('Auth API', 'http://localhost:8080/api/auth/login', 'POST'),
      this.testEndpoint('Billing API', 'http://localhost:8080/api/bills', 'GET'),
      this.testEndpoint('Complaint API', 'http://localhost:8080/api/complaints', 'GET')
    ];

    return new Observable(observer => {
      const results: ApiTestResult[] = [];
      let completed = 0;

      tests.forEach(test => {
        test.subscribe(result => {
          results.push(result);
          completed++;
          if (completed === tests.length) {
            observer.next(results);
            observer.complete();
          }
        });
      });
    });
  }

  private testEndpoint(serviceName: string, url: string, method: 'GET' | 'POST' = 'GET'): Observable<ApiTestResult> {
    const startTime = Date.now();

    let request: Observable<any>;

    if (method === 'POST') {
      // For POST endpoints, we expect 400/405 errors which means the endpoint exists
      request = this.http.post(url, {}, this.httpOptions);
    } else {
      request = this.http.get(url, this.httpOptions);
    }

    return request.pipe(
      map(response => ({
        service: serviceName,
        endpoint: url,
        status: 'success' as const,
        message: 'API endpoint is accessible',
        responseTime: Date.now() - startTime
      })),
      catchError(error => {
        const responseTime = Date.now() - startTime;

        // For POST endpoints, 400/405 errors indicate the endpoint exists
        if (method === 'POST' && (error.status === 400 || error.status === 405)) {
          return of({
            service: serviceName,
            endpoint: url,
            status: 'success' as const,
            message: `Endpoint exists (${error.status} - ${error.statusText})`,
            responseTime
          });
        }

        // For GET endpoints, 404 means not found, other errors might be CORS or server issues
        if (error.status === 404) {
          return of({
            service: serviceName,
            endpoint: url,
            status: 'error' as const,
            message: 'Endpoint not found (404)',
            responseTime
          });
        } else if (error.status === 0) {
          return of({
            service: serviceName,
            endpoint: url,
            status: 'error' as const,
            message: 'CORS error or server not reachable',
            responseTime
          });
        } else {
          return of({
            service: serviceName,
            endpoint: url,
            status: 'success' as const,
            message: `Server responding (${error.status} - ${error.statusText})`,
            responseTime
          });
        }
      })
    );
  }

  /**
   * Test a simple customer registration to verify full API functionality
   */
  testCustomerRegistration(): Observable<ApiTestResult> {
    const testCustomer = {
      customerName: 'Test User',
      email: 'test@example.com',
      mobileNumber: '1234567890',
      password: 'testpass123',
      address: 'Test Address',
      city: 'Test City',
      state: 'Test State',
      pincode: '123456',
      connectionType: 'DOMESTIC'
    };

    const startTime = Date.now();

    return this.http.post(`${environment.apiUrls.customer}/register`, testCustomer, this.httpOptions).pipe(
      map(response => ({
        service: 'Customer Registration',
        endpoint: `${environment.apiUrls.customer}/register`,
        status: 'success' as const,
        message: 'Customer registration API is working',
        responseTime: Date.now() - startTime
      })),
      catchError(error => {
        const responseTime = Date.now() - startTime;

        if (error.status === 400) {
          return of({
            service: 'Customer Registration',
            endpoint: `${environment.apiUrls.customer}/register`,
            status: 'success' as const,
            message: 'API is working (validation error expected for test data)',
            responseTime
          });
        } else if (error.status === 409) {
          return of({
            service: 'Customer Registration',
            endpoint: `${environment.apiUrls.customer}/register`,
            status: 'success' as const,
            message: 'API is working (user already exists)',
            responseTime
          });
        } else {
          return of({
            service: 'Customer Registration',
            endpoint: `${environment.apiUrls.customer}/register`,
            status: 'error' as const,
            message: `Error: ${error.status} - ${error.message}`,
            responseTime
          });
        }
      })
    );
  }
}
