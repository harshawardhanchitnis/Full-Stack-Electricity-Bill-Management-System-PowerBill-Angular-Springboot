import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Bill {
  id: number;
  billId: string;
  consumerId: string;
  billMonth: string;
  billYear: number;
  unitsConsumed: number;
  ratePerUnit: number;
  billAmount: number;
  dueDate: string;
  paymentStatus: string;
  paymentId?: string;
  paymentDate?: string;
  createdDate: string;
  updatedDate: string;
  lateFee?: number;
}

export interface PaymentRequest {
  billId: string;
  amount: number;
  paymentMethod: string;
  transactionReference?: string;
}

export interface MultiplePaymentRequest {
  billIds: string[];
  paymentRequest: {
    amount: number;
    paymentMethod: string;
    transactionReference: string;
  };
}

export interface TotalPendingWithFees {
  totalAmount: number;
  totalLateFees: number;
  totalPendingAmount: number;
  billCount: number;
  bills?: Bill[];
}

export interface PaymentResponse {
  paymentId: string;
  billId: string;
  amount: number;
  paymentMethod: string;
  transactionReference: string;
  paymentDate: string;
  status: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp: string;
}

@Injectable({
  providedIn: 'root'
})
export class BillingService {
  private apiUrl = environment.apiUrls.customerBills;

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }

  getBillsByConsumerId(consumerId: string): Observable<ApiResponse<Bill[]>> {
    return this.http.get<ApiResponse<Bill[]>>(`${this.apiUrl}/consumer/${consumerId}`, this.httpOptions);
  }

  getPendingBillsByConsumerId(consumerId: string): Observable<ApiResponse<Bill[]>> {
    const url = `${this.apiUrl}/consumer/${consumerId}/pending`;
    console.log('🔍 Calling pending bills API:', url);
    return this.http.get<ApiResponse<Bill[]>>(url, this.httpOptions);
  }

  getPaidBillsByConsumerId(consumerId: string): Observable<ApiResponse<Bill[]>> {
    const url = `${this.apiUrl}/consumer/${consumerId}/paid`;
    console.log('🔍 Calling paid bills API:', url);
    return this.http.get<ApiResponse<Bill[]>>(url, this.httpOptions);
  }

  getBillById(billId: string): Observable<ApiResponse<Bill>> {
    return this.http.get<ApiResponse<Bill>>(`${this.apiUrl}/${billId}`, this.httpOptions);
  }

  payBill(billId: string, paymentMethod: string, transactionReference: string, amount: number): Observable<ApiResponse<any>> {
    const params = new URLSearchParams();
    params.set('paymentMethod', paymentMethod);
    params.set('transactionReference', transactionReference);
    params.set('amount', amount.toString());

    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/${billId}/pay?${params.toString()}`, {}, this.httpOptions);
  }

  getTotalPendingAmount(consumerId: string): Observable<ApiResponse<any>> {
    return this.http.get<ApiResponse<any>>(`${this.apiUrl}/consumer/${consumerId}/total-pending`, this.httpOptions);
  }

  getBillHistory(consumerId: string): Observable<ApiResponse<Bill[]>> {
    return this.http.get<ApiResponse<Bill[]>>(`${this.apiUrl}/consumer/${consumerId}/history`, this.httpOptions);
  }

  getTotalPendingWithFees(consumerId: string): Observable<ApiResponse<any>> {
    const url = `${this.apiUrl}/consumer/${consumerId}/total-pending`;
    console.log('🔍 Calling total pending API:', url);
    return this.http.get<ApiResponse<any>>(url, this.httpOptions);
  }

  payMultipleBills(multiplePaymentRequest: any): Observable<ApiResponse<any[]>> {
    return this.http.post<ApiResponse<any[]>>(`${this.apiUrl}/pay-multiple`, multiplePaymentRequest, this.httpOptions);
  }

  getAllBills(): Observable<ApiResponse<Bill[]>> {
    return this.http.get<ApiResponse<Bill[]>>(`${this.apiUrl}`, this.httpOptions);
  }

  createBill(bill: Bill): Observable<ApiResponse<Bill>> {
    return this.http.post<ApiResponse<Bill>>(`${this.apiUrl}`, bill, this.httpOptions);
  }
}
