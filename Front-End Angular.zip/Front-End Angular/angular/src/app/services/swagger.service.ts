import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SwaggerService {

  constructor(private http: HttpClient) { }

  /**
   * Get OpenAPI documentation for a specific service
   */
  getApiDocs(service: 'customer' | 'auth' | 'billing' | 'complaint'): Observable<any> {
    const baseUrl = this.getServiceBaseUrl(service);
    return this.http.get(`${baseUrl}/api-docs`);
  }

  /**
   * Get Swagger UI URL for a specific service
   */
  getSwaggerUrl(service: 'customer' | 'auth' | 'billing' | 'complaint'): string {
    return environment.swaggerUrls[service];
  }

  /**
   * Get all available Swagger URLs
   */
  getAllSwaggerUrls(): { [key: string]: string } {
    return environment.swaggerUrls;
  }

  /**
   * Open Swagger UI in new tab
   */
  openSwaggerUI(service: 'customer' | 'auth' | 'billing' | 'complaint'): void {
    const url = this.getSwaggerUrl(service);
    window.open(url, '_blank');
  }

  /**
   * Get service base URL
   */
  private getServiceBaseUrl(service: 'customer' | 'auth' | 'billing' | 'complaint'): string {
    const serviceMap = {
      customer: 'http://localhost:8080',
      auth: 'http://localhost:8080',
      billing: 'http://localhost:8080',
      complaint: 'http://localhost:8080'
    };
    return serviceMap[service];
  }

  /**
   * Check if all services are running
   */
  checkServicesHealth(): Observable<any>[] {
    const services = ['customer', 'auth', 'billing', 'complaint'] as const;
    return services.map(service => {
      const baseUrl = this.getServiceBaseUrl(service);
      return this.http.get(`${baseUrl}/actuator/health`).pipe(
        // Handle errors gracefully
      );
    });
  }

  /**
   * Get API endpoints summary for documentation
   */
  getApiEndpointsSummary() {
    return {
      customer: {
        baseUrl: 'http://localhost:8080/api/customers',
        swagger: 'http://localhost:8080/swagger-ui/index.html',
        endpoints: [
          'POST /register - Register new customer',
          'GET /email/{email} - Get customer by email',
          'GET /consumer-id/{id} - Get customer by consumer ID',
          'PUT /{consumerId} - Update customer',
          'PUT /deactivate/{email} - Deactivate account',
          'PUT /reactivate/{email} - Reactivate account'
        ]
      },
      auth: {
        baseUrl: 'http://localhost:8080/api/auth',
        swagger: 'http://localhost:8080/swagger-ui/index.html',
        endpoints: [
          'POST /login - User login',
          'POST /validate - Validate user'
        ]
      },
      billing: {
        baseUrl: 'http://localhost:8080/api/bills',
        swagger: 'http://localhost:8080/swagger-ui/index.html',
        endpoints: [
          'GET /consumer/{consumerId} - Get all bills',
          'GET /consumer/{consumerId}/pending - Get pending bills',
          'GET /consumer/{consumerId}/paid - Get paid bills',
          'GET /{billId} - Get specific bill',
          'POST /{billId}/pay - Pay bill',
          'POST / - Create new bill'
        ]
      },
      complaint: {
        baseUrl: 'http://localhost:8080/api/complaints',
        swagger: 'http://localhost:8080/swagger-ui/index.html',
        endpoints: [
          'POST / - Register complaint',
          'GET /consumer/{consumerId} - Get customer complaints',
          'GET /{complaintId} - Get specific complaint',
          'PUT /{complaintId}/status - Update complaint status',
          'GET /status/{status} - Get complaints by status'
        ]
      }
    };
  }
}
