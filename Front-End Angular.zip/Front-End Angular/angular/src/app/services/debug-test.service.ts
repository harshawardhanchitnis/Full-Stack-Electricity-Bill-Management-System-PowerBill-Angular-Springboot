import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DebugTestService {
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }

  /**
   * Test customer registration and login flow
   */
  testRegistrationAndLogin(email: string, password: string): Observable<any> {
    console.log('Testing registration and login for:', email);
    
    // First, try to register a test user
    const testCustomer = {
      customerName: 'Debug Test User',
      email: email,
      mobileNumber: '9876543210',
      password: password,
      address: 'Test Address',
      city: 'Test City',
      state: 'Test State',
      pincode: '123456',
      connectionType: 'DOMESTIC'
    };

    return this.http.post(`${environment.apiUrls.customer}/register`, testCustomer, this.httpOptions).pipe(
      map(registerResponse => {
        console.log('Registration response:', registerResponse);
        
        // Now try to login
        const loginData = { email: email, password: password };
        return this.http.post(`${environment.apiUrls.auth}/login`, loginData, this.httpOptions).pipe(
          map(loginResponse => {
            console.log('Login response:', loginResponse);
            return {
              registration: registerResponse,
              login: loginResponse,
              status: 'success'
            };
          }),
          catchError(loginError => {
            console.error('Login error:', loginError);
            return of({
              registration: registerResponse,
              login: null,
              loginError: loginError,
              status: 'login_failed'
            });
          })
        );
      }),
      catchError(registerError => {
        console.error('Registration error:', registerError);
        
        // If registration fails (user might already exist), try login anyway
        if (registerError.status === 409) {
          const loginData = { email: email, password: password };
          return this.http.post(`${environment.apiUrls.auth}/login`, loginData, this.httpOptions).pipe(
            map(loginResponse => {
              console.log('Login response (after registration conflict):', loginResponse);
              return {
                registration: null,
                registrationError: registerError,
                login: loginResponse,
                status: 'login_after_conflict'
              };
            }),
            catchError(loginError => {
              console.error('Login error (after registration conflict):', loginError);
              return of({
                registration: null,
                registrationError: registerError,
                login: null,
                loginError: loginError,
                status: 'both_failed'
              });
            })
          );
        }
        
        return of({
          registration: null,
          registrationError: registerError,
          login: null,
          status: 'registration_failed'
        });
      })
    );
  }

  /**
   * Test customer lookup by email
   */
  testCustomerLookup(email: string): Observable<any> {
    return this.http.get(`${environment.apiUrls.customer}/email/${email}`, this.httpOptions).pipe(
      map(response => {
        console.log('Customer lookup response:', response);
        return response;
      }),
      catchError(error => {
        console.error('Customer lookup error:', error);
        return of({
          error: error,
          status: 'lookup_failed'
        });
      })
    );
  }

  /**
   * Test direct login without registration
   */
  testDirectLogin(email: string, password: string): Observable<any> {
    const loginData = { email: email, password: password };
    
    return this.http.post(`${environment.apiUrls.auth}/login`, loginData, this.httpOptions).pipe(
      map(response => {
        console.log('Direct login response:', response);
        return response;
      }),
      catchError(error => {
        console.error('Direct login error:', error);
        return of({
          error: error,
          errorMessage: error.error?.message || error.message,
          status: error.status,
          statusText: error.statusText
        });
      })
    );
  }
}
