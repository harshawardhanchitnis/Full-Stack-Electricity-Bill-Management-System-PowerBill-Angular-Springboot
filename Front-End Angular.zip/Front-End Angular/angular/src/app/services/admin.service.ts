import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface AdminLoginRequest {
  email: string;
  password: string;
}

export interface AdminLoginResponse {
  email: string;
  name: string;
  message: string;
}

export interface AdminDashboardData {
  customers: any;
  billStatistics: {
    totalBills: number;
    pendingBills: number;
    paidBills: number;
  };
  recentBills: any[];
}

export interface BillGenerationRequest {
  consumerId: string;
  month: string;
  year: number;
  unitsConsumed: number;
  ratePerUnit: number;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = environment.apiUrls.admin;
  private billsApiUrl = environment.apiUrls.adminBills;
  private customerApiUrl = environment.apiUrls.customer; // Customer service API

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }

  // Admin Authentication
  login(credentials: AdminLoginRequest): Observable<ApiResponse<AdminLoginResponse>> {
    const url = `${this.apiUrl}/login`;
    console.log('🔐 AdminService: Making login request to:', url);
    console.log('🔐 AdminService: Request payload:', credentials);
    return this.http.post<ApiResponse<AdminLoginResponse>>(url, credentials, this.httpOptions);
  }

  // Admin Dashboard
  getDashboard(): Observable<ApiResponse<AdminDashboardData>> {
    return this.http.get<ApiResponse<AdminDashboardData>>(`${this.apiUrl}/dashboard`, this.httpOptions);
  }

  // Bill Management
  generateBill(request: BillGenerationRequest): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/bills/generate`, request, this.httpOptions);
  }

  getBillStatus(): Observable<ApiResponse<any>> {
    return this.http.get<ApiResponse<any>>(`${this.apiUrl}/bills/status`, this.httpOptions);
  }

  getPaidBills(): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/bills/paid`, this.httpOptions);
  }

  // Bill Operations via Admin Bills API
  getBillsByConsumerId(consumerId: string): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.billsApiUrl}/consumer/${consumerId}`, this.httpOptions);
  }

  getPendingBillsByConsumerId(consumerId: string): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.billsApiUrl}/consumer/${consumerId}/pending`, this.httpOptions);
  }

  getPaidBillsByConsumerId(consumerId: string): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.billsApiUrl}/consumer/${consumerId}/paid`, this.httpOptions);
  }

  getBillById(billId: string): Observable<ApiResponse<any>> {
    return this.http.get<ApiResponse<any>>(`${this.billsApiUrl}/${billId}`, this.httpOptions);
  }

  processBillPayment(billId: string, paymentRequest: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.billsApiUrl}/${billId}/pay`, paymentRequest, this.httpOptions);
  }

  getBillHistory(consumerId: string): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.billsApiUrl}/consumer/${consumerId}/history`, this.httpOptions);
  }

  getTotalPendingAmount(consumerId: string): Observable<ApiResponse<any>> {
    return this.http.get<ApiResponse<any>>(`${this.billsApiUrl}/consumer/${consumerId}/total-pending`, this.httpOptions);
  }

  // Customer Management - Call customer service directly
  getAllCustomers(): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.customerApiUrl}/all`, this.httpOptions);
  }

  getCustomerById(customerId: string): Observable<ApiResponse<any>> {
    return this.http.get<ApiResponse<any>>(`${this.apiUrl}/customers/${customerId}`, this.httpOptions);
  }

  // Complaint Support
  getAllComplaints(): Observable<ApiResponse<any[]>> {
    const url = `${this.apiUrl}/complaints`;
    console.log('🔍 AdminService: Calling complaints API:', url);
    return this.http.get<ApiResponse<any[]>>(url, this.httpOptions);
  }

  updateComplaintStatus(complaintId: string, statusUpdate: any): Observable<ApiResponse<any>> {
    const url = `${this.customerApiUrl}/complaints/${complaintId}/status`;
    console.log('🔄 AdminService: Updating complaint status:', url, statusUpdate);
    return this.http.put<ApiResponse<any>>(url, statusUpdate, this.httpOptions);
  }

  // Bill Management
  getAllBills(): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.billsApiUrl}/all`, this.httpOptions);
  }

  deleteBill(billId: string): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.billsApiUrl}/${billId}`, this.httpOptions);
  }

  updateBill(billId: string, billData: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.billsApiUrl}/${billId}`, billData, this.httpOptions);
  }

  // Health Check
  checkHealth(): Observable<ApiResponse<string>> {
    return this.http.get<ApiResponse<string>>(`${this.apiUrl}/health`, this.httpOptions);
  }
}
