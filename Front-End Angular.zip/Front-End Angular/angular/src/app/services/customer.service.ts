import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface CustomerRegistrationRequest {
  consumerId?: string;
  customerName: string;
  email: string;
  mobileNumber: string;
  password: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  connectionType?: string;
}

export interface Customer {
  id: number;
  consumerId: string;
  customerName: string;
  email: string;
  mobileNumber: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  connectionType: string;
  status?: string;
  createdDate: string;
  updatedDate: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp: string;
}

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private apiUrl = environment.apiUrls.customer;

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }

  registerCustomer(request: CustomerRegistrationRequest): Observable<ApiResponse<Customer>> {
    return this.http.post<ApiResponse<Customer>>(`${this.apiUrl}/register`, request, this.httpOptions);
  }

  getCustomerByConsumerId(consumerId: string): Observable<ApiResponse<Customer>> {
    return this.http.get<ApiResponse<Customer>>(`${this.apiUrl}/profile/${consumerId}`, this.httpOptions);
  }

  updateCustomer(consumerId: string, request: CustomerRegistrationRequest): Observable<ApiResponse<Customer>> {
    return this.http.put<ApiResponse<Customer>>(`${this.apiUrl}/profile/${consumerId}`, request, this.httpOptions);
  }

  getAllCustomers(): Observable<ApiResponse<Customer[]>> {
    return this.http.get<ApiResponse<Customer[]>>(`${this.apiUrl}/all`, this.httpOptions);
  }

  getActiveCustomers(): Observable<ApiResponse<Customer[]>> {
    return this.http.get<ApiResponse<Customer[]>>(`${this.apiUrl}/active`, this.httpOptions);
  }

  searchCustomers(name: string): Observable<ApiResponse<Customer[]>> {
    return this.http.get<ApiResponse<Customer[]>>(`${this.apiUrl}/search?name=${encodeURIComponent(name)}`, this.httpOptions);
  }

  getCustomersByConnectionType(type: string): Observable<ApiResponse<Customer[]>> {
    return this.http.get<ApiResponse<Customer[]>>(`${this.apiUrl}/connection-type/${type}`, this.httpOptions);
  }

  // Dashboard data
  getDashboard(consumerId: string): Observable<ApiResponse<any>> {
    return this.http.get<ApiResponse<any>>(`${this.apiUrl}/dashboard/${consumerId}`, this.httpOptions);
  }
}
