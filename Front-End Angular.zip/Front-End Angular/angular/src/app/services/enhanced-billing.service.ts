import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface EnhancedBill {
  id: number;
  billId: string;
  consumerId: string;
  billMonth: string;
  billYear: number;
  unitsConsumed: number;
  ratePerUnit: number;
  billAmount: number;
  dueDate: string;
  paymentStatus: string;
  paymentId?: string;
  paymentDate?: string;
  paymentMethod?: string;
  transactionReference?: string;
  lateFee: number;
  totalAmount: number;
  overdue: boolean;
}

export interface EnhancedPaymentRequest {
  billId: string;
  amount: number;
  paymentMethod: string;
  transactionReference: string;
}

export interface EnhancedPaymentResponse {
  success: boolean;
  message: string;
  data: {
    paymentId: string;
    billId: string;
    amount: number;
    paymentMethod: string;
    transactionReference: string;
    paymentDate: string;
    status: string;
  };
  timestamp: string;
}

export interface EnhancedMultiplePaymentRequest {
  billIds: string[];
  paymentRequest: {
    amount: number;
    paymentMethod: string;
    transactionReference: string;
  };
}

export interface TotalPendingResponse {
  success: boolean;
  message: string;
  data: {
    totalAmount: number;
    totalLateFees: number;
    totalAmountWithFees: number;
    billCount: number;
    bills: EnhancedBill[];
  };
  timestamp: string;
}

@Injectable({
  providedIn: 'root'
})
export class EnhancedBillingService {
  private apiUrl = 'http://localhost:8080/api/bills';

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  constructor(private http: HttpClient) {}

  // Get pending bills
  getPendingBills(consumerId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/consumer/${consumerId}/pending`, this.httpOptions);
  }

  // Get paid bills
  getPaidBills(consumerId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/consumer/${consumerId}/paid`, this.httpOptions);
  }

  // Get total pending amount with late fees
  getTotalPendingWithFees(consumerId: string): Observable<TotalPendingResponse> {
    return this.http.get<TotalPendingResponse>(`${this.apiUrl}/consumer/${consumerId}/total-pending-with-fees`, this.httpOptions);
  }

  // Pay single bill
  payBill(billId: string, paymentRequest: EnhancedPaymentRequest): Observable<EnhancedPaymentResponse> {
    return this.http.post<EnhancedPaymentResponse>(`${this.apiUrl}/${billId}/pay`, paymentRequest, this.httpOptions);
  }

  // Pay multiple bills
  payMultipleBills(billIds: string[], paymentRequest: EnhancedPaymentRequest): Observable<any> {
    const request: EnhancedMultiplePaymentRequest = {
      billIds: billIds,
      paymentRequest: {
        amount: paymentRequest.amount,
        paymentMethod: paymentRequest.paymentMethod,
        transactionReference: paymentRequest.transactionReference
      }
    };
    return this.http.post(`${this.apiUrl}/pay-multiple`, request, this.httpOptions);
  }

  // Get specific bill
  getBill(billId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${billId}`, this.httpOptions);
  }

  // Generate unique transaction reference
  generateTransactionReference(): string {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `TXN${timestamp}${random}`;
  }

  // Generate unique payment ID
  generatePaymentId(): string {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `PAY${timestamp}${random}`;
  }

  // Format currency for display
  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  // Check if bill is overdue
  isOverdue(dueDate: string): boolean {
    return new Date(dueDate) < new Date();
  }

  // Calculate late fee (example logic)
  calculateLateFee(billAmount: number, dueDate: string): number {
    if (this.isOverdue(dueDate)) {
      const daysOverdue = Math.floor((Date.now() - new Date(dueDate).getTime()) / (1000 * 60 * 60 * 24));
      return Math.min(billAmount * 0.02 * Math.ceil(daysOverdue / 30), billAmount * 0.1); // 2% per month, max 10%
    }
    return 0;
  }
}
