import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { isPlatformBrowser } from '@angular/common';
import { AdminService, AdminLoginRequest, AdminLoginResponse } from './admin.service';

export interface AdminUser {
  email: string;
  name: string;
  userType: 'ADMIN';
  isLoggedIn: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AdminAuthService {
  private currentAdminSubject = new BehaviorSubject<AdminUser | null>(null);
  public currentAdmin$ = this.currentAdminSubject.asObservable();

  constructor(
    private adminService: AdminService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    // Check if admin is already logged in (only in browser)
    if (isPlatformBrowser(this.platformId)) {
      const savedAdmin = localStorage.getItem('currentAdmin');
      if (savedAdmin) {
        try {
          const admin = JSON.parse(savedAdmin);
          console.log('Restored admin from localStorage:', admin);
          this.currentAdminSubject.next(admin);
        } catch (error) {
          console.error('Error parsing saved admin:', error);
          localStorage.removeItem('currentAdmin');
        }
      }
    }
  }

  login(credentials: AdminLoginRequest): Observable<any> {
    console.log('🔐 AdminAuthService: Attempting login with credentials:', credentials);
    return this.adminService.login(credentials)
      .pipe(
        map(response => {
          console.log('🔐 AdminAuthService: Received response from admin service:', response);
          if (response.success && response.data) {
            const adminUser: AdminUser = {
              email: response.data.email,
              name: response.data.name,
              userType: 'ADMIN',
              isLoggedIn: true
            };

            console.log('✅ Admin login successful, saving admin:', adminUser);
            if (isPlatformBrowser(this.platformId)) {
              localStorage.setItem('currentAdmin', JSON.stringify(adminUser));
            }
            this.currentAdminSubject.next(adminUser);
          } else {
            console.error('❌ Admin login failed:', response);
          }
          return response;
        })
      );
  }

  logout(): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('currentAdmin');
    }
    this.currentAdminSubject.next(null);
  }

  getCurrentAdmin(): AdminUser | null {
    return this.currentAdminSubject.value;
  }

  isLoggedIn(): boolean {
    return this.currentAdminSubject.value !== null;
  }

  isAdmin(): boolean {
    const admin = this.getCurrentAdmin();
    return admin?.userType === 'ADMIN' && admin?.isLoggedIn === true;
  }
}
