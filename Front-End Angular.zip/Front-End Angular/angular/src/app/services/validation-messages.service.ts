import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ValidationMessagesService {

  private validationMessages: { [key: string]: { [key: string]: string } } = {
    // Common validation messages
    required: {
      default: 'This field is required'
    },

    // Name validation messages
    name: {
      required: 'Name is required',
      minlength: 'Name must be at least 2 characters long',
      maxlength: 'Name cannot exceed 50 characters',
      invalidName: 'Name can only contain letters, spaces, dots, and hyphens',
      invalidNameFormat: 'Invalid name format (avoid consecutive spaces or special characters)'
    },

    // Email validation messages
    email: {
      required: 'Email is required',
      email: 'Please enter a valid email address',
      invalidEmailFormat: 'Invalid email format',
      invalidDomain: 'Please enter a valid email domain'
    },

    // Mobile number validation messages
    mobile: {
      required: 'Mobile number is required',
      invalidMobileFormat: 'Mobile number must be exactly 10 digits',
      invalidMobilePattern: 'Invalid mobile number pattern (avoid repeated or sequential digits)',
      invalidMobileStart: 'Mobile number must start with 6, 7, 8, or 9'
    },

    // Password validation messages
    password: {
      required: 'Password is required',
      minlength: 'Password must be at least 8 characters',
      maxlength: 'Password cannot exceed 20 characters',
      noUppercase: 'Password must contain at least one uppercase letter',
      noLowercase: 'Password must contain at least one lowercase letter',
      noNumber: 'Password must contain at least one number',
      noSpecialChar: 'Password must contain at least one special character',
      weakPassword: 'Password is too weak, avoid common patterns',
      passwordMismatch: 'Passwords do not match'
    },

    // Address validation messages
    address: {
      required: 'Address is required',
      minlength: 'Address must be at least 10 characters long',
      maxlength: 'Address cannot exceed 200 characters'
    },

    // City validation messages
    city: {
      required: 'City is required',
      minlength: 'City name too short',
      maxlength: 'City name too long',
      invalidCityState: 'City name can only contain letters, spaces, and hyphens'
    },

    // State validation messages
    state: {
      required: 'State is required',
      minlength: 'State name too short',
      maxlength: 'State name too long',
      invalidCityState: 'State name can only contain letters, spaces, and hyphens'
    },

    // Pincode validation messages
    pincode: {
      required: 'Pincode is required',
      invalidPincodeFormat: 'Pincode must be exactly 6 digits',
      invalidPincodePattern: 'Invalid pincode pattern (avoid repeated digits)',
      invalidPincodeRange: 'Pincode must be between 100001 and 999999'
    },

    // Connection type validation messages
    connectionType: {
      required: 'Please select a connection type'
    },

    // Complaint validation messages
    complaint: {
      required: 'This field is required',
      minlength: 'Description must be at least 20 characters',
      maxlength: 'Description cannot exceed 500 characters',
      repeatedCharacters: 'Please provide a meaningful description (avoid repeated characters)',
      insufficientWords: 'Please provide more details (at least 5 words)',
      spamContent: 'Please provide a genuine description'
    },

    // Contact number validation messages
    contact: {
      required: 'Contact number is required',
      invalidContactFormat: 'Contact number must be exactly 10 digits',
      invalidContactPattern: 'Invalid contact number pattern (avoid repeated or sequential digits)',
      invalidContactStart: 'Contact number must start with 6, 7, 8, or 9'
    },

    // General validation messages
    general: {
      whitespace: 'This field cannot be empty or contain only spaces',
      notAlphanumeric: 'This field can only contain letters and numbers',
      invalidUrl: 'Please enter a valid URL',
      invalidAge: 'Please enter a valid age'
    }
  };

  constructor() { }

  /**
   * Get validation message for a specific field and error type
   * @param fieldType - Type of field (e.g., 'name', 'email', 'mobile')
   * @param errorType - Type of error (e.g., 'required', 'minlength')
   * @param errorValue - Optional error value for dynamic messages
   * @returns Validation message string
   */
  getValidationMessage(fieldType: string, errorType: string, errorValue?: any): string {
    const fieldMessages = this.validationMessages[fieldType];

    if (fieldMessages && fieldMessages[errorType]) {
      let message = fieldMessages[errorType];

      // Handle dynamic messages
      if (errorType === 'minlength' && errorValue?.requiredLength) {
        message = message.replace(/\d+/, errorValue.requiredLength.toString());
      }

      if (errorType === 'maxlength' && errorValue?.requiredLength) {
        message = message.replace(/\d+/, errorValue.requiredLength.toString());
      }

      if (errorType === 'invalidAge' && errorValue) {
        message = `Age must be between ${errorValue.min} and ${errorValue.max}`;
      }

      return message;
    }

    // Fallback to default message
    return this.validationMessages['required']['default'];
  }

  /**
   * Get all validation messages for a form control
   * @param fieldType - Type of field
   * @param errors - Errors object from form control
   * @returns Array of validation messages
   */
  getValidationMessages(fieldType: string, errors: any): string[] {
    const messages: string[] = [];

    if (errors) {
      Object.keys(errors).forEach(errorType => {
        const message = this.getValidationMessage(fieldType, errorType, errors[errorType]);
        messages.push(message);
      });
    }

    return messages;
  }

  /**
   * Check if a form control has validation errors
   * @param control - Form control
   * @returns Boolean indicating if control has errors
   */
  hasValidationErrors(control: any): boolean {
    return control && control.invalid && (control.dirty || control.touched);
  }

  /**
   * Get CSS classes for form control based on validation state
   * @param control - Form control
   * @returns CSS class string
   */
  getValidationClasses(control: any): string {
    if (!control) return '';

    if (control.valid && (control.dirty || control.touched)) {
      return 'is-valid';
    }

    if (control.invalid && (control.dirty || control.touched)) {
      return 'is-invalid';
    }

    return '';
  }

  /**
   * Add custom validation message
   * @param fieldType - Type of field
   * @param errorType - Type of error
   * @param message - Validation message
   */
  addValidationMessage(fieldType: string, errorType: string, message: string): void {
    if (!this.validationMessages[fieldType]) {
      this.validationMessages[fieldType] = {};
    }

    this.validationMessages[fieldType][errorType] = message;
  }

  /**
   * Get all available field types
   * @returns Array of field type strings
   */
  getAvailableFieldTypes(): string[] {
    return Object.keys(this.validationMessages);
  }

  /**
   * Get all error types for a specific field type
   * @param fieldType - Type of field
   * @returns Array of error type strings
   */
  getErrorTypesForField(fieldType: string): string[] {
    const fieldMessages = this.validationMessages[fieldType];
    return fieldMessages ? Object.keys(fieldMessages) : [];
  }
}
