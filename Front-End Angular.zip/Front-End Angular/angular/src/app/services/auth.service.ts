import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { isPlatformBrowser } from '@angular/common';
import { environment } from '../../environments/environment';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  email: string;
  userType: string;
  status: string;
  consumerId?: string;
  customerName?: string;
  // Additional fields from new Customer model
  id?: number;
  mobileNumber?: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  connectionType?: string;
  createdDate?: string;
  updatedDate?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = environment.apiUrls.auth;
  private currentUserSubject = new BehaviorSubject<LoginResponse | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  constructor(
    private http: HttpClient,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    // Check if user is already logged in (only in browser)
    if (isPlatformBrowser(this.platformId)) {
      const savedUser = localStorage.getItem('currentUser');
      if (savedUser) {
        try {
          const user = JSON.parse(savedUser);
          console.log('Restored user from localStorage:', user);
          this.currentUserSubject.next(user);
        } catch (error) {
          console.error('Error parsing saved user:', error);
          localStorage.removeItem('currentUser');
        }
      }
    }
  }

  login(credentials: LoginRequest): Observable<ApiResponse<LoginResponse>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/login`, credentials, this.httpOptions)
      .pipe(
        map(response => {
          if (response.success && response.data) {
            // Transform Customer data to LoginResponse format
            const loginResponse: LoginResponse = {
              email: response.data.email,
              userType: 'CUSTOMER',
              status: response.data.status || 'ACTIVE',
              consumerId: response.data.consumerId,
              customerName: response.data.customerName,
              id: response.data.id,
              mobileNumber: response.data.mobileNumber,
              address: response.data.address,
              city: response.data.city,
              state: response.data.state,
              pincode: response.data.pincode,
              connectionType: response.data.connectionType,
              createdDate: response.data.createdDate,
              updatedDate: response.data.updatedDate
            };

            console.log('Login successful, saving user:', loginResponse);
            if (isPlatformBrowser(this.platformId)) {
              localStorage.setItem('currentUser', JSON.stringify(loginResponse));
            }
            this.currentUserSubject.next(loginResponse);

            // Return the transformed response
            return {
              ...response,
              data: loginResponse
            } as ApiResponse<LoginResponse>;
          }
          return response as ApiResponse<LoginResponse>;
        })
      );
  }

  logout(): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('currentUser');
    }
    this.currentUserSubject.next(null);
  }

  getCurrentUser(): LoginResponse | null {
    return this.currentUserSubject.value;
  }

  isLoggedIn(): boolean {
    return this.currentUserSubject.value !== null;
  }

  isAdmin(): boolean {
    const user = this.getCurrentUser();
    return user?.userType === 'ADMIN';
  }

  isCustomer(): boolean {
    const user = this.getCurrentUser();
    return user?.userType === 'CUSTOMER';
  }

  validateUser(email: string): Observable<ApiResponse<boolean>> {
    return this.http.post<ApiResponse<boolean>>(`${this.apiUrl}/validate`, { email }, this.httpOptions);
  }
}
