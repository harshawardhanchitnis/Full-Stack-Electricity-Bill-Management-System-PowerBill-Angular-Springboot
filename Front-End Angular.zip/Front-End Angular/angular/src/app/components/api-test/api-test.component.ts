import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiTestService, ApiTestResult } from '../../services/api-test.service';

@Component({
  selector: 'app-api-test',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container mt-4">
      <div class="row">
        <div class="col-12">
          <h2 class="mb-4">
            <i class="fas fa-network-wired"></i> API Connectivity Test
          </h2>
          
          <div class="alert alert-info">
            <i class="fas fa-info-circle"></i>
            <strong>Testing Connection:</strong> Verifying Angular to Spring Boot API connectivity on port 8080.
          </div>

          <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
              <h5 class="mb-0">API Endpoint Tests</h5>
              <button class="btn btn-primary btn-sm" (click)="runTests()" [disabled]="testing">
                <i class="fas fa-sync" [class.fa-spin]="testing"></i>
                {{ testing ? 'Testing...' : 'Run Tests' }}
              </button>
            </div>
            <div class="card-body">
              <div *ngIf="testResults.length === 0 && !testing" class="text-center text-muted">
                <i class="fas fa-play-circle fa-3x mb-3"></i>
                <p>Click "Run Tests" to check API connectivity</p>
              </div>

              <div *ngIf="testing" class="text-center">
                <div class="spinner-border text-primary" role="status">
                  <span class="visually-hidden">Testing...</span>
                </div>
                <p class="mt-2">Testing API endpoints...</p>
              </div>

              <div *ngIf="testResults.length > 0" class="table-responsive">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Service</th>
                      <th>Endpoint</th>
                      <th>Status</th>
                      <th>Message</th>
                      <th>Response Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let result of testResults">
                      <td><strong>{{ result.service }}</strong></td>
                      <td><code>{{ result.endpoint }}</code></td>
                      <td>
                        <span class="badge" 
                              [class.bg-success]="result.status === 'success'"
                              [class.bg-danger]="result.status === 'error'"
                              [class.bg-warning]="result.status === 'testing'">
                          <i class="fas" 
                             [class.fa-check]="result.status === 'success'"
                             [class.fa-times]="result.status === 'error'"
                             [class.fa-clock]="result.status === 'testing'"></i>
                          {{ result.status | titlecase }}
                        </span>
                      </td>
                      <td>{{ result.message }}</td>
                      <td>
                        <span *ngIf="result.responseTime" class="text-muted">
                          {{ result.responseTime }}ms
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div *ngIf="testResults.length > 0" class="mt-3">
                <div class="row">
                  <div class="col-md-4">
                    <div class="card text-center">
                      <div class="card-body">
                        <h5 class="text-success">{{ getSuccessCount() }}</h5>
                        <p class="card-text">Successful</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="card text-center">
                      <div class="card-body">
                        <h5 class="text-danger">{{ getErrorCount() }}</h5>
                        <p class="card-text">Failed</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="card text-center">
                      <div class="card-body">
                        <h5 class="text-info">{{ getAverageResponseTime() }}ms</h5>
                        <p class="card-text">Avg Response</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="card mt-4">
            <div class="card-header">
              <h5 class="mb-0">Full API Test</h5>
            </div>
            <div class="card-body">
              <p>Test actual customer registration API functionality:</p>
              <button class="btn btn-warning" (click)="testCustomerAPI()" [disabled]="testingCustomer">
                <i class="fas fa-user-plus" [class.fa-spin]="testingCustomer"></i>
                {{ testingCustomer ? 'Testing...' : 'Test Customer Registration' }}
              </button>
              
              <div *ngIf="customerTestResult" class="mt-3">
                <div class="alert" 
                     [class.alert-success]="customerTestResult.status === 'success'"
                     [class.alert-danger]="customerTestResult.status === 'error'">
                  <strong>{{ customerTestResult.service }}:</strong> {{ customerTestResult.message }}
                  <span *ngIf="customerTestResult.responseTime" class="float-end">
                    {{ customerTestResult.responseTime }}ms
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      transition: transform 0.2s;
    }
    .card:hover {
      transform: translateY(-2px);
    }
    .badge {
      font-size: 0.8em;
    }
    code {
      font-size: 0.85em;
    }
  `]
})
export class ApiTestComponent implements OnInit {
  testResults: ApiTestResult[] = [];
  customerTestResult: ApiTestResult | null = null;
  testing = false;
  testingCustomer = false;

  constructor(private apiTestService: ApiTestService) {}

  ngOnInit(): void {
    // Automatically run tests when component loads
    this.runTests();
  }

  runTests(): void {
    this.testing = true;
    this.testResults = [];

    this.apiTestService.testApiConnectivity().subscribe({
      next: (results) => {
        this.testResults = results;
        this.testing = false;
      },
      error: (error) => {
        console.error('Error running tests:', error);
        this.testing = false;
      }
    });
  }

  testCustomerAPI(): void {
    this.testingCustomer = true;
    this.customerTestResult = null;

    this.apiTestService.testCustomerRegistration().subscribe({
      next: (result) => {
        this.customerTestResult = result;
        this.testingCustomer = false;
      },
      error: (error) => {
        console.error('Error testing customer API:', error);
        this.testingCustomer = false;
      }
    });
  }

  getSuccessCount(): number {
    return this.testResults.filter(r => r.status === 'success').length;
  }

  getErrorCount(): number {
    return this.testResults.filter(r => r.status === 'error').length;
  }

  getAverageResponseTime(): number {
    const times = this.testResults
      .filter(r => r.responseTime)
      .map(r => r.responseTime!);
    
    if (times.length === 0) return 0;
    
    return Math.round(times.reduce((a, b) => a + b, 0) / times.length);
  }
}
