import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AuthService, LoginResponse } from '../../services/auth.service';
import { environment } from '../../../environments/environment';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  currentUser: LoginResponse | null = null;

  // Dashboard statistics
  totalBills: number = 0;
  pendingBills: number = 0;
  paidBills: number = 0;
  totalComplaints: number = 0;

  // Loading state
  isLoadingStats: boolean = false;

  constructor(
    private authService: AuthService,
    private http: HttpClient,
    private router: Router
  ) { }

  ngOnInit(): void {
    // Check if user is already logged in
    const currentUser = this.authService.getCurrentUser();
    if (currentUser) {
      this.currentUser = currentUser;
    } else {
      // If no user, redirect to login
      this.router.navigate(['/login']);
      return;
    }

    // Subscribe to user changes (but don't redirect on null - let AuthGuard handle that)
    this.authService.currentUser$.subscribe(user => {
      if (user) {
        this.currentUser = user;
        this.loadDashboardStats();
      }
      // Don't redirect to login here - AuthGuard will handle route protection
    });

    // Load initial dashboard statistics
    this.loadDashboardStats();
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  navigateTo(route: string): void {
    this.router.navigate([route]);
  }

  getCurrentUserName(): string {
    if (this.currentUser?.customerName) {
      return this.currentUser.customerName;
    } else if (this.currentUser?.email) {
      return this.currentUser.email;
    } else {
      return 'Guest User';
    }
  }

  isDevelopmentMode(): boolean {
    return !environment.production;
  }

  loadDashboardStats(): void {
    if (!this.currentUser?.consumerId) {
      console.log('No user or consumer ID available');
      this.totalBills = 0;
      this.pendingBills = 0;
      this.paidBills = 0;
      this.totalComplaints = 0;
      return;
    }

    this.isLoadingStats = true;
    console.log('Loading REAL dashboard stats for consumer:', this.currentUser.consumerId);

    // Make parallel API calls to get real data from backend
    const consumerId = this.currentUser.consumerId;

    // Use customer dashboard endpoint which internally fetches bills from admin service
    this.http.get<any>(`${environment.apiUrls.customer}/dashboard/${consumerId}`).subscribe({
      next: (response: any) => {
        console.log('✅ Customer dashboard response:', response);

        if (response.success && response.data) {
          const dashboardData = response.data;

          // Extract bill statistics from dashboard data (now properly extracted from admin service)
          const pendingBillsData = dashboardData.pendingBills || [];
          const totalPendingData = dashboardData.totalPending || {};

          this.pendingBills = Array.isArray(pendingBillsData) ? pendingBillsData.length : 0;

          console.log('📊 Dashboard data extracted:', {
            pendingBillsData,
            totalPendingData,
            pendingBillsCount: this.pendingBills
          });

          // Now fetch all bills and paid bills to get accurate counts
          this.fetchAllBillCounts(consumerId);
        } else {
          console.error('❌ Invalid dashboard response:', response);
          this.isLoadingStats = false;
          this.totalBills = 0;
          this.pendingBills = 0;
          this.paidBills = 0;
          this.totalComplaints = 0;
        }
      },
      error: (error: any) => {
        console.error('❌ Error loading customer dashboard:', error);
        this.isLoadingStats = false;

        // Set to zero on error - no fake data
        this.totalBills = 0;
        this.pendingBills = 0;
        this.paidBills = 0;
        this.totalComplaints = 0;

        console.log('Dashboard stats set to zero due to API error');
      }
    });
  }



  refreshDashboard(): void {
    console.log('Refreshing dashboard stats...');
    this.loadDashboardStats();
  }

  formatDate(dateString: string | undefined): string {
    if (!dateString) return 'N/A';

    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch (error) {
      return 'N/A';
    }
  }

  fetchAllBillCounts(consumerId: string): void {
    console.log('🔍 Fetching all bill counts for consumer:', consumerId);

    // Fetch all bills to get total count
    this.http.get<any>(`${environment.apiUrls.customerBills}/consumer/${consumerId}`).subscribe({
      next: (allBillsResponse: any) => {
        console.log('📊 All bills response:', allBillsResponse);
        if (allBillsResponse.success && allBillsResponse.data) {
          const allBillsData = allBillsResponse.data;
          this.totalBills = Array.isArray(allBillsData) ? allBillsData.length : 0;
          console.log('✅ Total bills count:', this.totalBills);
        }

        // Fetch paid bills to get paid count
        this.http.get<any>(`${environment.apiUrls.customerBills}/consumer/${consumerId}/paid`).subscribe({
          next: (paidBillsResponse: any) => {
            console.log('📊 Paid bills response:', paidBillsResponse);
            if (paidBillsResponse.success && paidBillsResponse.data) {
              const paidBillsData = paidBillsResponse.data;
              this.paidBills = Array.isArray(paidBillsData) ? paidBillsData.length : 0;
              console.log('✅ Paid bills count:', this.paidBills);
            }

            // Fetch complaints
            this.fetchComplaints(consumerId);
          },
          error: (error: any) => {
            console.error('❌ Error fetching paid bills:', error);
            this.paidBills = 0;
            this.fetchComplaints(consumerId);
          }
        });
      },
      error: (error: any) => {
        console.error('❌ Error fetching all bills:', error);
        this.totalBills = this.pendingBills; // Fallback to pending bills count
        this.fetchComplaints(consumerId);
      }
    });
  }

  fetchComplaints(consumerId: string): void {
    console.log('🔍 Fetching complaints for consumer:', consumerId);
    this.http.get<any>(`${environment.apiUrls.complaint}/consumer/${consumerId}`).subscribe({
      next: (complaintsResponse: any) => {
        console.log('📊 Complaints response:', complaintsResponse);
        if (complaintsResponse.success && complaintsResponse.data) {
          this.totalComplaints = Array.isArray(complaintsResponse.data) ? complaintsResponse.data.length : 0;
        } else {
          this.totalComplaints = 0;
        }
        this.isLoadingStats = false;

        console.log('✅ FINAL Dashboard stats:', {
          totalBills: this.totalBills,
          pendingBills: this.pendingBills,
          paidBills: this.paidBills,
          totalComplaints: this.totalComplaints,
          consumerId: consumerId
        });
      },
      error: (error: any) => {
        console.error('❌ Error fetching complaints:', error);
        this.totalComplaints = 0;
        this.isLoadingStats = false;
      }
    });
  }
}
