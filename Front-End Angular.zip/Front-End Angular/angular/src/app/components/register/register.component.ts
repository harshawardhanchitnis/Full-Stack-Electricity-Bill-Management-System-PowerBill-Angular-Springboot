import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm: FormGroup;
  loading = false;
  error = '';
  success = '';

  constructor(
    private formBuilder: FormBuilder,
    private customerService: CustomerService,
    private router: Router
  ) {
    this.registerForm = this.formBuilder.group({
      customerName: ['', [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(50),
        this.nameValidator
      ]],
      email: ['', [
        Validators.required,
        Validators.email,
        this.emailDomainValidator
      ]],
      mobileNumber: ['', [
        Validators.required,
        this.mobileNumberValidator
      ]],
      password: ['', [
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(20),
        this.passwordStrengthValidator
      ]],
      confirmPassword: ['', Validators.required],
      address: ['', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(200)
      ]],
      city: ['', [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(50),
        this.cityValidator
      ]],
      state: ['', [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(50),
        this.stateValidator
      ]],
      pincode: ['', [
        Validators.required,
        this.pincodeValidator
      ]],
      connectionType: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password');
    const confirmPassword = form.get('confirmPassword');

    if (password && confirmPassword && password.value !== confirmPassword.value) {
      confirmPassword.setErrors({ passwordMismatch: true });
    } else {
      if (confirmPassword?.errors?.['passwordMismatch']) {
        delete confirmPassword.errors['passwordMismatch'];
        if (Object.keys(confirmPassword.errors).length === 0) {
          confirmPassword.setErrors(null);
        }
      }
    }
    return null;
  }

  // Custom Validators
  nameValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;

    // Check for valid name pattern (letters, spaces, dots, hyphens)
    const namePattern = /^[a-zA-Z\s.-]+$/;
    if (!namePattern.test(value)) {
      return { invalidName: true };
    }

    // Check for consecutive spaces or special characters
    if (/\s{2,}|\.{2,}|-{2,}/.test(value)) {
      return { invalidNameFormat: true };
    }

    return null;
  }

  emailDomainValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;

    // Check for suspicious domains
    const emailParts = value.split('@');
    if (emailParts.length === 2) {
      const domain = emailParts[1].toLowerCase();
      if (domain.length < 4 || !domain.includes('.')) {
        return { invalidDomain: true };
      }
    }

    return null;
  }

  mobileNumberValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;

    // Check if it's exactly 10 digits
    if (!/^\d{10}$/.test(value)) {
      return { invalidMobileFormat: true };
    }

    // Check for invalid patterns (all same digits)
    if (/^(\d)\1{9}$/.test(value)) {
      return { invalidMobilePattern: true };
    }

    // Check for sequential numbers
    if (/^(0123456789|1234567890|9876543210)$/.test(value)) {
      return { invalidMobilePattern: true };
    }

    // Check if first digit is valid (Indian mobile numbers start with 6-9)
    if (!/^[6-9]/.test(value)) {
      return { invalidMobileStart: true };
    }

    return null;
  }

  passwordStrengthValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;

    const errors: any = {};

    // Check for at least one uppercase letter
    if (!/[A-Z]/.test(value)) {
      errors.noUppercase = true;
    }

    // Check for at least one lowercase letter
    if (!/[a-z]/.test(value)) {
      errors.noLowercase = true;
    }

    // Check for at least one number
    if (!/\d/.test(value)) {
      errors.noNumber = true;
    }

    // Check for at least one special character
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
      errors.noSpecialChar = true;
    }

    return Object.keys(errors).length > 0 ? errors : null;
  }

  cityValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;

    // Check for valid city name pattern (letters, spaces, hyphens)
    const cityPattern = /^[a-zA-Z\s-]+$/;
    if (!cityPattern.test(value)) {
      return { invalidCity: true };
    }

    return null;
  }

  stateValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;

    // Check for valid state name pattern (letters, spaces, hyphens)
    const statePattern = /^[a-zA-Z\s-]+$/;
    if (!statePattern.test(value)) {
      return { invalidState: true };
    }

    return null;
  }

  pincodeValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;

    // Check if it's exactly 6 digits
    if (!/^\d{6}$/.test(value)) {
      return { invalidPincodeFormat: true };
    }

    // Check for invalid patterns (all same digits)
    if (/^(\d)\1{5}$/.test(value)) {
      return { invalidPincodePattern: true };
    }

    // Check for valid Indian pincode range (100001 to 999999)
    const pincodeNum = parseInt(value);
    if (pincodeNum < 100001 || pincodeNum > 999999) {
      return { invalidPincodeRange: true };
    }

    return null;
  }

  get f() { return this.registerForm.controls; }

  onSubmit() {
    if (this.registerForm.invalid) {
      return;
    }

    this.loading = true;
    this.error = '';
    this.success = '';

    const formData = { ...this.registerForm.value };
    delete formData.confirmPassword; // Remove confirm password before sending

    this.customerService.registerCustomer(formData).subscribe({
      next: (response) => {
        if (response.success) {
          this.success = 'Registration successful! You can now login.';
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000);
        } else {
          this.error = response.message;
        }
        this.loading = false;
      },
      error: (error) => {
        this.error = error.error?.message || 'Registration failed. Please try again.';
        this.loading = false;
      }
    });
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }
}
