import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService, LoginResponse } from '../../services/auth.service';
import { BillingService, Bill, PaymentRequest, MultiplePaymentRequest, TotalPendingWithFees } from '../../services/billing.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-bills',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bills.component.html',
  styleUrls: ['./bills.component.css']
})
export class BillsComponent implements OnInit {
  currentUser: LoginResponse | null = null;
  bills: Bill[] = [];
  pendingBills: Bill[] = [];
  paidBills: Bill[] = [];
  loading = false;
  error = '';
  success = '';
  activeTab = 'pending';

  // Multiple payment selection
  selectedBills: Set<string> = new Set();
  selectAllChecked: boolean = false;

  // Payment method selection
  paymentMethod: string = 'CREDIT_CARD';
  transactionReference: string = '';
  paymentMethods = [
    { value: 'CREDIT_CARD', label: 'Credit Card' },
    { value: 'DEBIT_CARD', label: 'Debit Card' },
    { value: 'UPI', label: 'UPI' },
    { value: 'NET_BANKING', label: 'Net Banking' },
    { value: 'WALLET', label: 'Digital Wallet' }
  ];

  // Payment confirmation dialog
  showPaymentConfirmation: boolean = false;
  selectedBillForPayment: Bill | null = null;
  confirmationPaymentMethod: string = 'CREDIT_CARD';
  confirmationTransactionReference: string = '';

  // Multiple payment confirmation dialog
  showMultiplePaymentConfirmation: boolean = false;
  selectedBillsForPayment: Bill[] = [];
  multipleConfirmationPaymentMethod: string = 'CREDIT_CARD';
  multipleConfirmationTransactionReference: string = '';

  // Total pending with fees
  totalPendingWithFees: TotalPendingWithFees = {
    billCount: 0,
    totalAmount: 0,
    totalLateFees: 0,
    totalPendingAmount: 0,
    bills: []
  };

  constructor(
    private authService: AuthService,
    private billingService: BillingService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    // Initialize the totalPendingWithFees object to prevent undefined errors
    this.initializeTotalPendingWithFees();

    // For testing purposes, always load mock data first
    console.log('🚀 Loading mock data for testing total bill summary');

    // Use setTimeout to ensure the component is fully initialized before loading data
    setTimeout(() => {
      this.loadMockData();
    }, 0);

    // Check if user is already logged in
    const currentUser = this.authService.getCurrentUser();
    if (currentUser) {
      this.currentUser = currentUser;
      if (currentUser.consumerId) {
        this.loadBills();
      }
    } else {
      // If no user, ensure mock data is loaded
      console.log('No user found, mock data should be loaded');
    }

    // Check for query parameters to set initial tab
    this.route.queryParams.subscribe(params => {
      if (params['tab']) {
        this.setActiveTab(params['tab']);
      } else if (params['view'] === 'history') {
        this.setActiveTab('paid');
      }
    });

    // Subscribe to user changes (but don't redirect on null - let AuthGuard handle that)
    this.authService.currentUser$.subscribe(user => {
      if (user) {
        this.currentUser = user;
        if (user.consumerId && user !== currentUser) {
          this.loadBills();
        }
      }
      // Don't redirect to login here - AuthGuard will handle route protection
    });
  }

  // Initialize total pending with fees object
  initializeTotalPendingWithFees(): void {
    this.totalPendingWithFees = {
      billCount: 0,
      totalAmount: 0,
      totalLateFees: 0,
      totalPendingAmount: 0,
      bills: []
    };
    console.log('✅ Initialized totalPendingWithFees:', this.totalPendingWithFees);
    // Trigger change detection to update the UI immediately
    this.cdr.detectChanges();
  }

  loadBills(): void {
    if (!this.currentUser?.consumerId) {
      console.error('No consumer ID found for current user');
      return;
    }

    console.log('Loading bills for consumer ID:', this.currentUser.consumerId);
    this.loading = true;
    this.error = '';

    // Load pending bills
    this.billingService.getPendingBillsByConsumerId(this.currentUser.consumerId).subscribe({
      next: (response) => {
        console.log('Pending bills response:', response);
        if (response.success) {
          this.pendingBills = response.data || [];
          console.log('Loaded pending bills:', this.pendingBills);
          // Apply late fees based on due dates
          this.applyLateFees();
          // Calculate totals after loading bills and applying late fees
          this.calculateTotalPendingFromBills();
        } else {
          console.error('Failed to load pending bills:', response.message);
          this.error = response.message || 'Failed to load pending bills';
        }
      },
      error: (error) => {
        this.error = 'Failed to load pending bills';
        console.error('Error loading pending bills:', error);
        // Load mock data for testing if API fails
        if (this.isDevelopmentMode()) {
          console.log('Loading mock data due to API failure');
          this.loadMockData();
        }
      }
    });

    // Load paid bills
    this.billingService.getPaidBillsByConsumerId(this.currentUser.consumerId).subscribe({
      next: (response) => {
        console.log('Paid bills response:', response);
        if (response.success) {
          this.paidBills = response.data || [];
          console.log('Loaded paid bills:', this.paidBills);
        } else {
          console.error('Failed to load paid bills:', response.message);
          this.error = response.message || 'Failed to load paid bills';
        }
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to load paid bills';
        this.loading = false;
        console.error('Error loading paid bills:', error);
      }
    });

    // Load total pending with fees
    this.billingService.getTotalPendingWithFees(this.currentUser.consumerId).subscribe({
      next: (response: any) => {
        console.log('Total pending with fees response:', response);
        if (response.success && response.data) {
          this.totalPendingWithFees = response.data;
          console.log('Loaded total pending with fees:', this.totalPendingWithFees);
        } else {
          // Calculate totals from pending bills if API doesn't provide them
          this.calculateTotalPendingFromBills();
          console.error('Failed to load total pending with fees:', response.message);
        }
      },
      error: (error: any) => {
        // Calculate totals from pending bills if API fails
        this.calculateTotalPendingFromBills();
        console.error('Error loading total pending with fees:', error);
      }
    });
  }

  payBill(billId: string): void {
    // Find the bill in pending bills (since only pending bills can be paid)
    const bill = this.pendingBills.find(b => b.billId === billId);
    if (!bill) {
      this.error = 'Bill not found in pending bills';
      return;
    }

    // Show payment confirmation dialog
    this.selectedBillForPayment = bill;
    this.confirmationPaymentMethod = this.paymentMethod;
    this.confirmationTransactionReference = this.transactionReference || this.generateTransactionReference();
    this.showPaymentConfirmation = true;
    this.error = '';
    this.success = '';
  }

  // New method to actually process the payment after confirmation
  confirmPayment(): void {
    if (!this.selectedBillForPayment) {
      return;
    }

    this.loading = true;
    this.error = '';
    this.success = '';

    // Create payment request with confirmed details
    const paymentRequest: PaymentRequest = {
      billId: this.selectedBillForPayment.billId,
      amount: this.selectedBillForPayment.billAmount,
      paymentMethod: this.confirmationPaymentMethod,
      transactionReference: this.confirmationTransactionReference
    };

    console.log('Confirming payment for bill:', this.selectedBillForPayment.billId, 'with request:', paymentRequest);

    this.billingService.payBill(
      this.selectedBillForPayment.billId,
      paymentRequest.paymentMethod,
      paymentRequest.transactionReference || '',
      this.selectedBillForPayment.billAmount
    ).subscribe({
      next: (response) => {
        console.log('Payment response:', response);
        if (response.success) {
          const paymentId = response.data?.paymentId || this.generatePaymentId();
          const transactionRef = response.data?.transactionReference || paymentRequest.transactionReference;
          const amount = response.data?.amount || this.selectedBillForPayment!.billAmount || 0;
          const method = response.data?.paymentMethod || this.confirmationPaymentMethod;

          this.success = `✅ Bill payment successful!
            Payment ID: ${paymentId}
            Transaction Reference: ${transactionRef}
            Amount: ${this.formatCurrency(amount)}
            Payment Method: ${method}`;
          this.loadBills(); // Reload bills to update status
          this.clearSelection(); // Clear any selections
          this.closePaymentConfirmation(); // Close the dialog
        } else {
          this.error = response.message || 'Payment failed';
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Payment error:', error);
        this.error = error.error?.message || error.message || 'Payment failed. Please try again.';
        this.loading = false;
      }
    });
  }

  // Close payment confirmation dialog
  closePaymentConfirmation(): void {
    this.showPaymentConfirmation = false;
    this.selectedBillForPayment = null;
    this.confirmationPaymentMethod = 'CREDIT_CARD';
    this.confirmationTransactionReference = '';
  }

  payMultipleBills(): void {
    if (this.selectedBills.size === 0) {
      this.error = 'Please select at least one bill to pay';
      return;
    }

    // Prepare selected bills data for confirmation
    const selectedBillIds = Array.from(this.selectedBills);
    this.selectedBillsForPayment = this.pendingBills.filter(bill => selectedBillIds.includes(bill.billId));
    this.multipleConfirmationPaymentMethod = this.paymentMethod;
    this.multipleConfirmationTransactionReference = this.transactionReference || this.generateTransactionReference();

    // Show multiple payment confirmation dialog
    this.showMultiplePaymentConfirmation = true;
    this.error = '';
    this.success = '';
  }

  // New method to actually process multiple payments after confirmation
  confirmMultiplePayment(): void {
    if (this.selectedBillsForPayment.length === 0) {
      return;
    }

    this.loading = true;
    this.error = '';
    this.success = '';

    const selectedBillIds = this.selectedBillsForPayment.map(bill => bill.billId);
    const totalAmount = this.selectedBillsForPayment.reduce((sum, bill) => sum + bill.billAmount, 0);

    const multiplePaymentRequest: MultiplePaymentRequest = {
      billIds: selectedBillIds,
      paymentRequest: {
        amount: totalAmount,
        paymentMethod: this.multipleConfirmationPaymentMethod,
        transactionReference: this.multipleConfirmationTransactionReference
      }
    };

    console.log('Confirming multiple bills payment:', multiplePaymentRequest);

    this.billingService.payMultipleBills(multiplePaymentRequest).subscribe({
      next: (response: any) => {
        console.log('Multiple payment response:', response);
        if (response.success) {
          const payments = response.data || [];
          const paymentIds = payments.length > 0 ?
            payments.map((p: any) => p.paymentId || this.generatePaymentId()).join(', ') :
            this.generatePaymentId();
          const transactionRef = multiplePaymentRequest.paymentRequest.transactionReference;

          this.success = `✅ Multiple bills payment successful!
            ${selectedBillIds.length} bills paid
            Total Amount: ${this.formatCurrency(totalAmount)}
            Payment Method: ${this.multipleConfirmationPaymentMethod}
            Transaction Reference: ${transactionRef}
            Payment IDs: ${paymentIds}`;
          this.loadBills(); // Reload bills to update status
          this.clearSelection(); // Clear selections
          this.closeMultiplePaymentConfirmation(); // Close the dialog
        } else {
          this.error = response.message || 'Multiple payment failed';
        }
        this.loading = false;
      },
      error: (error: any) => {
        console.error('Multiple payment error:', error);
        this.error = error.error?.message || error.message || 'Multiple payment failed. Please try again.';
        this.loading = false;
      }
    });
  }

  // Close multiple payment confirmation dialog
  closeMultiplePaymentConfirmation(): void {
    this.showMultiplePaymentConfirmation = false;
    this.selectedBillsForPayment = [];
    this.multipleConfirmationPaymentMethod = 'CREDIT_CARD';
    this.multipleConfirmationTransactionReference = '';
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }

  formatCurrency(amount: number): string {
    // Handle NaN and undefined values
    const validAmount = isNaN(amount) || amount === null || amount === undefined ? 0 : amount;
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(validAmount);
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString('en-IN');
  }

  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'PAID': return 'badge bg-success';
      case 'PENDING': return 'badge bg-warning';
      case 'OVERDUE': return 'badge bg-danger';
      default: return 'badge bg-secondary';
    }
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  navigateTo(route: string): void {
    this.router.navigate([route]);
  }

  // Bill selection methods
  toggleBillSelection(billId: string): void {
    if (this.selectedBills.has(billId)) {
      this.selectedBills.delete(billId);
    } else {
      this.selectedBills.add(billId);
    }
    this.updateSelectAllState();
  }

  toggleSelectAll(): void {
    if (this.selectAllChecked) {
      this.selectedBills.clear();
    } else {
      this.pendingBills.forEach(bill => this.selectedBills.add(bill.billId));
    }
    this.selectAllChecked = !this.selectAllChecked;
  }

  updateSelectAllState(): void {
    this.selectAllChecked = this.pendingBills.length > 0 &&
                           this.selectedBills.size === this.pendingBills.length;
  }

  clearSelection(): void {
    this.selectedBills.clear();
    this.selectAllChecked = false;
    this.transactionReference = '';
  }

  getSelectedBillsTotal(): number {
    const selectedBillsData = this.pendingBills.filter(bill =>
      this.selectedBills.has(bill.billId)
    );
    return selectedBillsData.reduce((sum, bill) => sum + (bill.billAmount || 0), 0);
  }

  getSelectedBillsTotalWithFees(): number {
    const selectedBillsData = this.pendingBills.filter(bill =>
      this.selectedBills.has(bill.billId)
    );
    return selectedBillsData.reduce((sum, bill) => sum + (bill.billAmount || 0) + (bill.lateFee || 0), 0);
  }

  getMultiplePaymentTotalWithFees(): number {
    return this.selectedBillsForPayment.reduce((sum, bill) => sum + (bill.billAmount || 0) + (bill.lateFee || 0), 0);
  }

  getMultiplePaymentBillAmount(): number {
    return this.selectedBillsForPayment.reduce((sum, bill) => sum + (bill.billAmount || 0), 0);
  }

  getMultiplePaymentLateFees(): number {
    return this.selectedBillsForPayment.reduce((sum, bill) => sum + (bill.lateFee || 0), 0);
  }

  // Calculate late fee based on due date
  calculateLateFee(bill: Bill): number {
    const currentDate = new Date();
    const dueDate = new Date(bill.dueDate);

    // If bill is not overdue, no late fee
    if (currentDate <= dueDate) {
      return 0;
    }

    // Calculate days overdue
    const timeDiff = currentDate.getTime() - dueDate.getTime();
    const daysOverdue = Math.ceil(timeDiff / (1000 * 3600 * 24));

    // Late fee calculation logic:
    // - First 30 days: 2% of bill amount
    // - 31-60 days: 5% of bill amount
    // - 61+ days: 10% of bill amount
    let lateFeePercentage = 0;

    if (daysOverdue <= 30) {
      lateFeePercentage = 0.02; // 2%
    } else if (daysOverdue <= 60) {
      lateFeePercentage = 0.05; // 5%
    } else {
      lateFeePercentage = 0.10; // 10%
    }

    const lateFee = bill.billAmount * lateFeePercentage;

    // Round to 2 decimal places
    return Math.round(lateFee * 100) / 100;
  }

  // Apply late fees to all pending bills
  applyLateFees(): void {
    this.pendingBills.forEach(bill => {
      if (bill.paymentStatus === 'PENDING') {
        bill.lateFee = this.calculateLateFee(bill);
      }
    });
  }

  // Get bill status based on due date
  getBillStatus(bill: Bill): string {
    if (bill.paymentStatus === 'PAID') {
      return 'PAID';
    }

    const currentDate = new Date();
    const dueDate = new Date(bill.dueDate);

    if (currentDate > dueDate) {
      return 'OVERDUE';
    }

    return 'PENDING';
  }

  calculateTotalPendingFromBills(): void {
    console.log('Calculating totals from bills:', this.pendingBills);

    if (this.pendingBills && this.pendingBills.length > 0) {
      const totalAmount = this.pendingBills.reduce((sum, bill) => {
        console.log(`Adding bill amount: ${bill.billAmount} for bill ${bill.billId}`);
        return sum + (bill.billAmount || 0);
      }, 0);

      const totalLateFees = this.pendingBills.reduce((sum, bill) => {
        console.log(`Adding late fee: ${bill.lateFee} for bill ${bill.billId}`);
        return sum + (bill.lateFee || 0);
      }, 0);

      this.totalPendingWithFees = {
        billCount: this.pendingBills.length,
        totalAmount: totalAmount,
        totalLateFees: totalLateFees,
        totalPendingAmount: totalAmount + totalLateFees,
        bills: this.pendingBills
      };

      console.log('✅ Calculated totals from bills:', this.totalPendingWithFees);
    } else {
      console.log('No pending bills found, setting totals to zero');
      this.totalPendingWithFees = {
        billCount: 0,
        totalAmount: 0,
        totalLateFees: 0,
        totalPendingAmount: 0,
        bills: []
      };
    }

    // Trigger change detection to update the UI immediately
    this.cdr.detectChanges();
    console.log('🔄 Change detection triggered for totalPendingWithFees update');
  }

  // Utility methods
  generateTransactionReference(): string {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `TXN${timestamp}${random}`;
  }

  generatePaymentId(): string {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `PAY${timestamp}${random}`;
  }

  generateUniquePaymentId(): string {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `PAY${timestamp}${random}`;
  }

  isDevelopmentMode(): boolean {
    return !environment.production;
  }

  loadMockData(): void {
    // Get current date for realistic due date scenarios
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth();

    // Create dates for different scenarios
    const overdueDate1 = new Date(currentYear, currentMonth - 2, 15); // 2 months overdue
    const overdueDate2 = new Date(currentYear, currentMonth - 1, 15); // 1 month overdue
    const overdueDate3 = new Date(currentYear, currentMonth, currentDate.getDate() - 10); // 10 days overdue
    const futureDate1 = new Date(currentYear, currentMonth, currentDate.getDate() + 15); // 15 days future
    const futureDate2 = new Date(currentYear, currentMonth + 1, 15); // Next month

    // Mock data for testing when backend is not available
    this.pendingBills = [
      {
        id: 1,
        billId: 'BILL001',
        consumerId: 'CONS001',
        billMonth: 'October',
        billYear: currentYear,
        unitsConsumed: 150,
        ratePerUnit: 5.5,
        billAmount: 825.0,
        dueDate: overdueDate1.toISOString().split('T')[0], // 2 months overdue
        paymentStatus: 'PENDING',
        createdDate: '2024-10-01',
        updatedDate: '2024-10-01',
        lateFee: 0.0 // Will be calculated
      },
      {
        id: 2,
        billId: 'BILL002',
        consumerId: 'CONS001',
        billMonth: 'November',
        billYear: currentYear,
        unitsConsumed: 180,
        ratePerUnit: 5.5,
        billAmount: 990.0,
        dueDate: overdueDate2.toISOString().split('T')[0], // 1 month overdue
        paymentStatus: 'PENDING',
        createdDate: '2024-11-01',
        updatedDate: '2024-11-01',
        lateFee: 0.0 // Will be calculated
      },
      {
        id: 3,
        billId: 'BILL003',
        consumerId: 'CONS001',
        billMonth: 'December',
        billYear: currentYear,
        unitsConsumed: 200,
        ratePerUnit: 6.0,
        billAmount: 1200.0,
        dueDate: overdueDate3.toISOString().split('T')[0], // 10 days overdue
        paymentStatus: 'PENDING',
        createdDate: '2024-12-01',
        updatedDate: '2024-12-01',
        lateFee: 0.0 // Will be calculated
      },
      {
        id: 4,
        billId: 'BILL004',
        consumerId: 'CONS001',
        billMonth: 'January',
        billYear: currentYear + 1,
        unitsConsumed: 175,
        ratePerUnit: 6.0,
        billAmount: 1050.0,
        dueDate: futureDate1.toISOString().split('T')[0], // Not yet due
        paymentStatus: 'PENDING',
        createdDate: '2025-01-01',
        updatedDate: '2025-01-01',
        lateFee: 0.0 // Will be calculated (should remain 0)
      },
      {
        id: 5,
        billId: 'BILL005',
        consumerId: 'CONS001',
        billMonth: 'February',
        billYear: currentYear + 1,
        unitsConsumed: 160,
        ratePerUnit: 6.5,
        billAmount: 1040.0,
        dueDate: futureDate2.toISOString().split('T')[0], // Future due date
        paymentStatus: 'PENDING',
        createdDate: '2025-02-01',
        updatedDate: '2025-02-01',
        lateFee: 0.0 // Will be calculated (should remain 0)
      }
    ];

    this.paidBills = [
      {
        id: 3,
        billId: 'BILL003',
        consumerId: 'CONS001',
        billMonth: 'December',
        billYear: 2023,
        unitsConsumed: 120,
        ratePerUnit: 5.0,
        billAmount: 600.0,
        dueDate: '2024-01-15',
        paymentStatus: 'PAID',
        paymentId: 'PAY123456',
        paymentDate: '2024-01-10',
        createdDate: '2023-12-01',
        updatedDate: '2024-01-10',
        lateFee: 0.0
      }
    ];

    console.log('Mock data loaded (before late fees):', this.pendingBills);

    // Apply late fees based on due dates
    this.applyLateFees();

    console.log('Mock data after late fees applied:', this.pendingBills);
    this.calculateTotalPendingFromBills();
    this.loading = false;

    // Force change detection to ensure UI updates immediately
    this.cdr.detectChanges();
    console.log('✅ Mock data loaded and UI updated:', this.totalPendingWithFees);
  }
}
