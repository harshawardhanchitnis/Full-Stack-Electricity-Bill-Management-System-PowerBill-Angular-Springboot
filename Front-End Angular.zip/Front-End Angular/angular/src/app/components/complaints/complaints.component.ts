import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, LoginResponse } from '../../services/auth.service';
import { ComplaintService, Complaint, ComplaintRequest } from '../../services/complaint.service';

@Component({
  selector: 'app-complaints',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './complaints.component.html',
  styleUrls: ['./complaints.component.css']
})
export class ComplaintsComponent implements OnInit {
  currentUser: LoginResponse | null = null;
  complaints: Complaint[] = [];
  complaintForm: FormGroup;
  loading = false;
  error = '';
  success = '';
  activeTab = 'register';
  searchComplaintId = '';

  complaintTypes = [
    'BILLING',
    'CONNECTION',
    'POWER_OUTAGE',
    'METER_READING',
    'OTHER'
  ];

  categories = [
    'HIGH',
    'MEDIUM',
    'LOW'
  ];

  constructor(
    private authService: AuthService,
    private complaintService: ComplaintService,
    private formBuilder: FormBuilder,
    private router: Router
  ) {
    this.complaintForm = this.formBuilder.group({
      complaintType: ['', Validators.required],
      category: ['', Validators.required],
      problem: ['', [
        Validators.required,
        Validators.minLength(20),
        Validators.maxLength(500),
        this.problemDescriptionValidator
      ]],
      contactNumber: ['', [
        Validators.required,
        this.contactNumberValidator
      ]],
      address: ['', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(200)
      ]],
      landmark: ['']
    });
  }

  ngOnInit(): void {
    console.log('Complaints component initializing...');

    // Check if user is already logged in
    const currentUser = this.authService.getCurrentUser();
    console.log('Current user from auth service:', currentUser);

    if (currentUser) {
      console.log('User found, setting current user');
      this.currentUser = currentUser;
      if (currentUser.consumerId) {
        console.log('User has consumerId, loading complaints');
        this.loadComplaints();
      }
    } else {
      console.log('No user found, checking localStorage directly...');

      // Double-check localStorage directly
      if (typeof window !== 'undefined' && localStorage.getItem('currentUser')) {
        try {
          const savedUser = JSON.parse(localStorage.getItem('currentUser')!);
          console.log('Found user in localStorage:', savedUser);
          this.currentUser = savedUser;
          if (savedUser.consumerId) {
            this.loadComplaints();
          }
          return;
        } catch (error) {
          console.error('Error parsing saved user:', error);
        }
      }

      console.log('No valid user found, redirecting to login');
      this.router.navigate(['/login']);
      return;
    }

    // Subscribe to user changes (but don't redirect on null - let AuthGuard handle that)
    this.authService.currentUser$.subscribe(user => {
      console.log('User changed in subscription:', user);
      if (user) {
        this.currentUser = user;
        if (user.consumerId && user !== currentUser) {
          console.log('User changed with consumerId, reloading complaints');
          this.loadComplaints();
        }
      }
      // Don't redirect to login here - AuthGuard will handle route protection
    });
  }

  loadComplaints(): void {
    if (!this.currentUser?.consumerId) return;

    this.loading = true;
    this.error = '';

    this.complaintService.getComplaintsByConsumerId(this.currentUser.consumerId).subscribe({
      next: (response) => {
        if (response.success) {
          this.complaints = response.data;
        } else {
          this.error = response.message;
        }
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to load complaints';
        this.loading = false;
        console.error('Error loading complaints:', error);
      }
    });
  }

  onSubmit(): void {
    if (this.complaintForm.invalid || !this.currentUser?.consumerId) {
      return;
    }

    this.loading = true;
    this.error = '';
    this.success = '';

    const request: ComplaintRequest = {
      consumerId: this.currentUser.consumerId,
      customerName: this.currentUser.customerName || '',
      complaintType: this.complaintForm.value.complaintType,
      category: this.complaintForm.value.category,
      problem: this.complaintForm.value.problem,
      contactNumber: this.complaintForm.value.contactNumber,
      address: this.complaintForm.value.address,
      landmark: this.complaintForm.value.landmark
    };

    this.complaintService.registerComplaint(request).subscribe({
      next: (response) => {
        if (response.success) {
          this.success = 'Complaint registered successfully!';
          this.complaintForm.reset();
          this.loadComplaints();
          this.setActiveTab('history');
        } else {
          this.error = response.message;
        }
        this.loading = false;
      },
      error: (error) => {
        this.error = error.error?.message || 'Failed to register complaint. Please try again.';
        this.loading = false;
      }
    });
  }

  searchComplaint(): void {
    if (!this.searchComplaintId.trim()) {
      this.error = 'Please enter a complaint ID';
      return;
    }

    this.loading = true;
    this.error = '';

    this.complaintService.getComplaintById(this.searchComplaintId).subscribe({
      next: (response) => {
        if (response.success) {
          this.complaints = [response.data];
          this.setActiveTab('history');
        } else {
          this.error = response.message;
        }
        this.loading = false;
      },
      error: (error) => {
        this.error = error.error?.message || 'Complaint not found';
        this.loading = false;
      }
    });
  }

  setActiveTab(tab: string, event?: Event): void {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    console.log('Setting active tab to:', tab);
    this.activeTab = tab;
    this.error = '';
    this.success = '';
    if (tab === 'history') {
      this.loadComplaints();
    }
  }

  // Custom Validators
  problemDescriptionValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;

    // Check for meaningful content (not just repeated characters)
    if (/^(.)\1{10,}$/.test(value)) {
      return { repeatedCharacters: true };
    }

    // Check for minimum word count (at least 5 words)
    const wordCount = value.trim().split(/\s+/).length;
    if (wordCount < 5) {
      return { insufficientWords: true };
    }

    // Check for common spam patterns
    const spamPatterns = ['test', 'testing', 'asdf', 'qwerty'];
    if (spamPatterns.some(pattern => value.toLowerCase().includes(pattern))) {
      return { spamContent: true };
    }

    return null;
  }

  contactNumberValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;

    // Check if it's exactly 10 digits
    if (!/^\d{10}$/.test(value)) {
      return { invalidContactFormat: true };
    }

    // Check for invalid patterns (all same digits)
    if (/^(\d)\1{9}$/.test(value)) {
      return { invalidContactPattern: true };
    }

    // Check for sequential numbers
    if (/^(0123456789|1234567890|9876543210)$/.test(value)) {
      return { invalidContactPattern: true };
    }

    // Check if first digit is valid (Indian mobile numbers start with 6-9)
    if (!/^[6-9]/.test(value)) {
      return { invalidContactStart: true };
    }

    return null;
  }

  get f() { return this.complaintForm.controls; }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString('en-IN');
  }

  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'OPEN': return 'badge bg-warning';
      case 'IN_PROGRESS': return 'badge bg-info';
      case 'RESOLVED': return 'badge bg-success';
      case 'CLOSED': return 'badge bg-secondary';
      default: return 'badge bg-secondary';
    }
  }

  getComplaintTypeDisplay(type: string): string {
    return type.replace('_', ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
  }

  // Track by function for better performance in ngFor
  trackByComplaintId(_index: number, complaint: any): any {
    return complaint.complaintId;
  }

  // Get count of pending complaints
  getPendingCount(): number {
    return this.complaints.filter(c => c.status === 'OPEN' || c.status === 'IN_PROGRESS').length;
  }

  // Get count of resolved complaints
  getResolvedCount(): number {
    return this.complaints.filter(c => c.status === 'RESOLVED' || c.status === 'CLOSED').length;
  }

  // Calculate resolution rate percentage
  getResolutionRate(): number {
    if (this.complaints.length === 0) return 0;
    const resolvedCount = this.getResolvedCount();
    return Math.round((resolvedCount / this.complaints.length) * 100);
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  navigateTo(route: string): void {
    this.router.navigate([route]);
  }
}
