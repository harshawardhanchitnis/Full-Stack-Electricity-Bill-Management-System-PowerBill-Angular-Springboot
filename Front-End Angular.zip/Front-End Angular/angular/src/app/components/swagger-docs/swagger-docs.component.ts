import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SwaggerService } from '../../services/swagger.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-swagger-docs',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container mt-4">
      <div class="row">
        <div class="col-12">
          <h2 class="mb-4">
            <i class="fas fa-book"></i> API Documentation
          </h2>

          <div class="alert alert-info">
            <i class="fas fa-info-circle"></i>
            <strong>Swagger Integration:</strong> Access interactive API documentation for all microservices.
            Make sure all Spring Boot services are running in Eclipse.
          </div>

          <div class="row">
            <!-- Customer Service -->
            <div class="col-md-6 col-lg-3 mb-4">
              <div class="card h-100">
                <div class="card-header bg-primary text-white">
                  <h5 class="card-title mb-0">
                    <i class="fas fa-users"></i> Customer Service
                  </h5>
                </div>
                <div class="card-body">
                  <p class="card-text">Customer registration, profile management, and account operations.</p>
                  <p><strong>Port:</strong> 8080</p>
                  <div class="d-grid gap-2">
                    <button class="btn btn-primary" (click)="openSwagger('customer')">
                      <i class="fas fa-external-link-alt"></i> Open Swagger UI
                    </button>
                    <button class="btn btn-outline-secondary btn-sm" (click)="openH2Console('customer')">
                      <i class="fas fa-database"></i> H2 Database
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Auth Service -->
            <div class="col-md-6 col-lg-3 mb-4">
              <div class="card h-100">
                <div class="card-header bg-success text-white">
                  <h5 class="card-title mb-0">
                    <i class="fas fa-lock"></i> Auth Service
                  </h5>
                </div>
                <div class="card-body">
                  <p class="card-text">User authentication, login validation, and security operations.</p>
                  <p><strong>Port:</strong> 8080</p>
                  <div class="d-grid gap-2">
                    <button class="btn btn-success" (click)="openSwagger('auth')">
                      <i class="fas fa-external-link-alt"></i> Open Swagger UI
                    </button>
                    <button class="btn btn-outline-secondary btn-sm" (click)="openH2Console('auth')">
                      <i class="fas fa-database"></i> H2 Database
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Billing Service -->
            <div class="col-md-6 col-lg-3 mb-4">
              <div class="card h-100">
                <div class="card-header bg-warning text-dark">
                  <h5 class="card-title mb-0">
                    <i class="fas fa-file-invoice-dollar"></i> Billing Service
                  </h5>
                </div>
                <div class="card-body">
                  <p class="card-text">Bill generation, payment processing, and billing history.</p>
                  <p><strong>Port:</strong> 8080</p>
                  <div class="d-grid gap-2">
                    <button class="btn btn-warning" (click)="openSwagger('billing')">
                      <i class="fas fa-external-link-alt"></i> Open Swagger UI
                    </button>
                    <button class="btn btn-outline-secondary btn-sm" (click)="openH2Console('billing')">
                      <i class="fas fa-database"></i> H2 Database
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Complaint Service -->
            <div class="col-md-6 col-lg-3 mb-4">
              <div class="card h-100">
                <div class="card-header bg-danger text-white">
                  <h5 class="card-title mb-0">
                    <i class="fas fa-exclamation-triangle"></i> Complaint Service
                  </h5>
                </div>
                <div class="card-body">
                  <p class="card-text">Complaint registration, tracking, and resolution management.</p>
                  <p><strong>Port:</strong> 8080</p>
                  <div class="d-grid gap-2">
                    <button class="btn btn-danger" (click)="openSwagger('complaint')">
                      <i class="fas fa-external-link-alt"></i> Open Swagger UI
                    </button>
                    <button class="btn btn-outline-secondary btn-sm" (click)="openH2Console('complaint')">
                      <i class="fas fa-database"></i> H2 Database
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- API Endpoints Summary -->
          <div class="mt-5">
            <h3>API Endpoints Summary</h3>
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>Service</th>
                    <th>Base URL</th>
                    <th>Key Endpoints</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><strong>Customer</strong></td>
                    <td>http://localhost:8080/api/customers</td>
                    <td>/register, /email/{{ '{' }}email{{ '}' }}, /{{ '{' }}consumerId{{ '}' }}</td>
                    <td><span class="badge bg-success">Active</span></td>
                  </tr>
                  <tr>
                    <td><strong>Auth</strong></td>
                    <td>http://localhost:8080/api/auth</td>
                    <td>/login, /validate</td>
                    <td><span class="badge bg-success">Active</span></td>
                  </tr>
                  <tr>
                    <td><strong>Billing</strong></td>
                    <td>http://localhost:8080/api/bills</td>
                    <td>/consumer/{{ '{' }}id{{ '}' }}, /{{ '{' }}billId{{ '}' }}/pay</td>
                    <td><span class="badge bg-success">Active</span></td>
                  </tr>
                  <tr>
                    <td><strong>Complaint</strong></td>
                    <td>http://localhost:8080/api/complaints</td>
                    <td>/, /consumer/{{ '{' }}id{{ '}' }}, /{{ '{' }}id{{ '}' }}/status</td>
                    <td><span class="badge bg-success">Active</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      transition: transform 0.2s;
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .badge {
      font-size: 0.8em;
    }
  `]
})
export class SwaggerDocsComponent {

  constructor(private swaggerService: SwaggerService) {}

  openSwagger(service: 'customer' | 'auth' | 'billing' | 'complaint'): void {
    this.swaggerService.openSwaggerUI(service);
  }

  openH2Console(service: 'customer' | 'auth' | 'billing' | 'complaint'): void {
    const h2Urls = environment.h2ConsoleUrls;
    window.open(h2Urls[service], '_blank');
  }
}
