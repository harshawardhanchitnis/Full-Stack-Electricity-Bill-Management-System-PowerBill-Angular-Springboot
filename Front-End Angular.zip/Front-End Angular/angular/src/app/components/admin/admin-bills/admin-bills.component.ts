import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../../../services/admin.service';
import { AdminAuthService } from '../../../services/admin-auth.service';

@Component({
  selector: 'app-admin-bills',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, ReactiveFormsModule],
  templateUrl: './admin-bills.component.html',
  styleUrls: ['./admin-bills.component.css']
})
export class AdminBillsComponent implements OnInit {
  activeTab = 'status';
  isLoading = false;
  errorMessage = '';
  successMessage = '';

  // Bill Status Data
  billStatus: any = null;

  // Bill Generation
  generateBillForm: FormGroup;
  customers: any[] = [];
  selectedCustomer: any = null;

  // Paid Bills
  paidBills: any[] = [];

  // Manage Bills
  allBills: any[] = [];
  filteredBills: any[] = [];
  searchConsumerId = '';
  statusFilter = '';

  // Edit Bill
  selectedBillForEdit: any = null;
  editBillForm: FormGroup;

  constructor(
    private adminService: AdminService,
    private adminAuthService: AdminAuthService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.generateBillForm = this.formBuilder.group({
      consumerId: ['', [Validators.required]],
      month: ['', [Validators.required]],
      year: [new Date().getFullYear(), [Validators.required, Validators.min(2020), Validators.max(2030)]],
      unitsConsumed: ['', [Validators.required, Validators.min(1), Validators.max(10000)]],
      ratePerUnit: ['', [Validators.required, Validators.min(0.01), Validators.max(100)]]
    });

    this.editBillForm = this.formBuilder.group({
      unitsConsumed: ['', [Validators.required, Validators.min(1), Validators.max(10000)]],
      ratePerUnit: ['', [Validators.required, Validators.min(0.01), Validators.max(100)]],
      dueDate: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
    if (!this.adminAuthService.isLoggedIn()) {
      this.router.navigate(['/admin/login']);
      return;
    }

    this.loadBillStatus();
    this.loadCustomers();
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
    this.errorMessage = '';
    this.successMessage = '';

    switch (tab) {
      case 'status':
        this.loadBillStatus();
        break;
      case 'paid':
        this.loadPaidBills();
        break;
      case 'generate':
        this.loadCustomers();
        break;
      case 'manage':
        this.loadAllBills();
        break;
    }
  }

  loadBillStatus(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.adminService.getBillStatus().subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success) {
          this.billStatus = response.data;
        } else {
          this.errorMessage = response.message || 'Failed to load bill status';
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Bill status error:', error);
        this.errorMessage = error.error?.message || 'Failed to load bill status';
      }
    });
  }

  loadPaidBills(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.adminService.getPaidBills().subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success) {
          this.paidBills = response.data || [];
        } else {
          this.errorMessage = response.message || 'Failed to load paid bills';
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Paid bills error:', error);
        this.errorMessage = error.error?.message || 'Failed to load paid bills';
      }
    });
  }

  generateBill(): void {
    if (this.customers.length === 0) {
      this.errorMessage = 'No customers available. Bills can only be generated for registered customers.';
      return;
    }

    if (this.generateBillForm.valid) {
      this.isLoading = true;
      this.errorMessage = '';
      this.successMessage = '';

      const billData = this.generateBillForm.value;

      this.adminService.generateBill(billData).subscribe({
        next: (response) => {
          this.isLoading = false;
          if (response.success) {
            this.successMessage = 'Bill generated successfully!';
            this.generateBillForm.reset();
            this.generateBillForm.patchValue({
              year: new Date().getFullYear()
            });
          } else {
            this.errorMessage = response.message || 'Failed to generate bill';
          }
        },
        error: (error) => {
          this.isLoading = false;
          console.error('Bill generation error:', error);
          this.errorMessage = error.error?.message || 'Failed to generate bill';
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  private markFormGroupTouched(): void {
    Object.keys(this.generateBillForm.controls).forEach(key => {
      const control = this.generateBillForm.get(key);
      control?.markAsTouched();
    });
  }

  getFieldError(fieldName: string): string {
    const field = this.generateBillForm.get(fieldName);
    if (field?.errors && field.touched) {
      if (field.errors['required']) {
        switch (fieldName) {
          case 'consumerId':
            return 'Please select a customer from the list';
          case 'month':
            return 'Please select a bill month';
          case 'year':
            return 'Please enter a valid year';
          case 'unitsConsumed':
            return 'Please enter units consumed';
          case 'ratePerUnit':
            return 'Please enter rate per unit';
          default:
            return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`;
        }
      }
      if (field.errors['min']) {
        switch (fieldName) {
          case 'unitsConsumed':
            return 'Units consumed must be at least 1';
          case 'ratePerUnit':
            return 'Rate per unit must be at least ₹0.01';
          case 'year':
            return 'Year must be 2020 or later';
          default:
            return `Value must be greater than ${field.errors['min'].min}`;
        }
      }
      if (field.errors['max']) {
        switch (fieldName) {
          case 'unitsConsumed':
            return 'Units consumed cannot exceed 10,000';
          case 'ratePerUnit':
            return 'Rate per unit cannot exceed ₹100.00';
          case 'year':
            return 'Year cannot be later than 2030';
          default:
            return `Value must be less than ${field.errors['max'].max}`;
        }
      }
    }
    return '';
  }

  getStatusBadgeClass(status: string): string {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'badge-success';
      case 'pending':
        return 'badge-warning';
      case 'overdue':
        return 'badge-danger';
      default:
        return 'badge-secondary';
    }
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount || 0);
  }

  formatDate(dateString: string): string {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN');
  }

  loadCustomers(): void {
    console.log('Loading customers from customer service...');
    this.adminService.getAllCustomers().subscribe({
      next: (response: any) => {
        console.log('Customer service response:', response);
        if (response.success) {
          this.customers = response.data || [];
          console.log('Loaded customers:', this.customers);
          if (this.customers.length === 0) {
            this.errorMessage = 'No customers found. Bills can only be generated for registered customers.';
          } else {
            this.errorMessage = ''; // Clear any previous error
          }
        } else {
          this.errorMessage = 'Failed to load customers: ' + (response.message || 'Unknown error');
          console.error('Customer service error:', response);
        }
      },
      error: (error: any) => {
        console.error('Error loading customers:', error);
        this.errorMessage = 'Failed to load customers. Please try again.';
      }
    });
  }

  onCustomerSelect(): void {
    const selectedConsumerId = this.generateBillForm.get('consumerId')?.value;
    this.selectedCustomer = this.customers.find(c => c.consumerId === selectedConsumerId);

    if (this.selectedCustomer) {
      this.errorMessage = '';
      this.successMessage = `Selected: ${this.selectedCustomer.customerName} (${this.selectedCustomer.email})`;
    }
  }

  goBack(): void {
    this.router.navigate(['/admin/dashboard']);
  }

  // Manage Bills Methods
  loadAllBills(): void {
    this.isLoading = true;
    this.adminService.getAllBills().subscribe({
      next: (response: any) => {
        console.log('All bills response:', response);
        if (response.success) {
          this.allBills = response.data || [];
          this.filteredBills = [...this.allBills];
          console.log('Loaded all bills:', this.allBills);
        } else {
          this.errorMessage = 'Failed to load bills: ' + (response.message || 'Unknown error');
        }
        this.isLoading = false;
      },
      error: (error: any) => {
        console.error('Error loading all bills:', error);
        this.errorMessage = 'Failed to load bills. Please try again.';
        this.isLoading = false;
      }
    });
  }

  searchBills(): void {
    this.filterBills();
  }

  filterBills(): void {
    this.filteredBills = this.allBills.filter(bill => {
      const matchesConsumer = !this.searchConsumerId ||
        bill.consumerId.toLowerCase().includes(this.searchConsumerId.toLowerCase());
      const matchesStatus = !this.statusFilter || bill.paymentStatus === this.statusFilter;
      return matchesConsumer && matchesStatus;
    });
  }

  editBill(bill: any): void {
    console.log('Opening edit modal for bill:', bill);
    this.selectedBillForEdit = { ...bill }; // Create a copy

    // Populate the edit form with current values
    this.editBillForm.patchValue({
      unitsConsumed: bill.unitsConsumed,
      ratePerUnit: bill.ratePerUnit,
      dueDate: bill.dueDate
    });

    // Show the modal (using Bootstrap modal)
    const modalElement = document.getElementById('editBillModal');
    if (modalElement) {
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }

  deleteBill(bill: any): void {
    if (confirm(`Are you sure you want to delete bill ${bill.billId}?`)) {
      this.adminService.deleteBill(bill.billId).subscribe({
        next: (response: any) => {
          if (response.success) {
            this.successMessage = 'Bill deleted successfully';
            this.loadAllBills(); // Refresh the list
          } else {
            this.errorMessage = 'Failed to delete bill: ' + (response.message || 'Unknown error');
          }
        },
        error: (error: any) => {
          console.error('Error deleting bill:', error);
          this.errorMessage = 'Failed to delete bill. Please try again.';
        }
      });
    }
  }

  closeEditModal(): void {
    this.selectedBillForEdit = null;
    this.editBillForm.reset();

    // Hide the modal
    const modalElement = document.getElementById('editBillModal');
    if (modalElement) {
      const modal = (window as any).bootstrap.Modal.getInstance(modalElement);
      if (modal) {
        modal.hide();
      }
    }
  }

  updateBill(): void {
    if (this.editBillForm.valid && this.selectedBillForEdit) {
      this.isLoading = true;
      const updateData = this.editBillForm.value;

      console.log('Updating bill:', this.selectedBillForEdit.billId, 'with data:', updateData);

      this.adminService.updateBill(this.selectedBillForEdit.billId, updateData).subscribe({
        next: (response: any) => {
          console.log('Bill update response:', response);
          if (response.success) {
            this.successMessage = 'Bill updated successfully';
            this.closeEditModal();
            this.loadAllBills(); // Refresh the list
          } else {
            this.errorMessage = 'Failed to update bill: ' + (response.message || 'Unknown error');
          }
          this.isLoading = false;
        },
        error: (error: any) => {
          console.error('Error updating bill:', error);
          this.errorMessage = 'Failed to update bill. Please try again.';
          this.isLoading = false;
        }
      });
    }
  }

  calculateBillAmount(): number {
    const units = this.editBillForm.get('unitsConsumed')?.value || 0;
    const rate = this.editBillForm.get('ratePerUnit')?.value || 0;
    return units * rate;
  }

  getEditFieldError(fieldName: string): string {
    const field = this.editBillForm.get(fieldName);
    if (field?.errors && field.touched) {
      if (field.errors['required']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`;
      }
      if (field.errors['min']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must be at least ${field.errors['min'].min}`;
      }
      if (field.errors['max']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must be at most ${field.errors['max'].max}`;
      }
    }
    return '';
  }
}
