import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AdminService, AdminDashboardData } from '../../../services/admin.service';
import { AdminAuthService } from '../../../services/admin-auth.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  dashboardData: AdminDashboardData | null = null;
  isLoading = true;
  errorMessage = '';
  currentAdmin: any = null;
  activeTab = 'dashboard';

  // Statistics
  totalCustomers = 0;
  totalBills = 0;
  pendingBills = 0;
  paidBills = 0;
  recentBills: any[] = [];
  customers: any[] = [];

  constructor(
    private adminService: AdminService,
    private adminAuthService: AdminAuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Check if admin is logged in
    if (!this.adminAuthService.isLoggedIn()) {
      this.router.navigate(['/admin/login']);
      return;
    }

    this.currentAdmin = this.adminAuthService.getCurrentAdmin();
    this.loadDashboardData();
  }

  loadDashboardData(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.adminService.getDashboard().subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success && response.data) {
          this.dashboardData = response.data;
          this.processDashboardData();
        } else {
          this.errorMessage = response.message || 'Failed to load dashboard data';
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Dashboard error:', error);
        this.errorMessage = error.error?.message || 'Failed to load dashboard data';
      }
    });
  }

  private processDashboardData(): void {
    if (this.dashboardData) {
      // Process customer data
      if (this.dashboardData.customers && this.dashboardData.customers.data) {
        this.customers = this.dashboardData.customers.data;
        this.totalCustomers = this.customers.length;
      }

      // Process bill statistics
      if (this.dashboardData.billStatistics) {
        this.totalBills = this.dashboardData.billStatistics.totalBills || 0;
        this.pendingBills = this.dashboardData.billStatistics.pendingBills || 0;
        this.paidBills = this.dashboardData.billStatistics.paidBills || 0;
      }

      // Process recent bills
      if (this.dashboardData.recentBills) {
        this.recentBills = this.dashboardData.recentBills.slice(0, 5); // Show only 5 recent bills
      }
    }
  }

  logout(): void {
    this.adminAuthService.logout();
    this.router.navigate(['/admin/login']);
  }

  navigateTo(route: string): void {
    this.router.navigate([route]);
  }

  refreshDashboard(): void {
    this.loadDashboardData();
  }

  getStatusBadgeClass(status: string): string {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'badge-success';
      case 'pending':
        return 'badge-warning';
      case 'overdue':
        return 'badge-danger';
      default:
        return 'badge-secondary';
    }
  }

  getConnectionTypeClass(type: string): string {
    switch (type?.toLowerCase()) {
      case 'domestic':
        return 'text-primary';
      case 'commercial':
        return 'text-success';
      case 'industrial':
        return 'text-warning';
      default:
        return 'text-secondary';
    }
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount || 0);
  }

  formatDate(dateString: string): string {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN');
  }

  // Quick Actions
  generateBill(): void {
    this.router.navigate(['/admin/bills']);
  }

  viewAllCustomers(): void {
    this.router.navigate(['/admin/customers']);
  }

  viewAllBills(): void {
    this.router.navigate(['/admin/bills']);
  }

  viewComplaints(): void {
    this.router.navigate(['/admin/complaints']);
  }

  // Tab Management
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
}
