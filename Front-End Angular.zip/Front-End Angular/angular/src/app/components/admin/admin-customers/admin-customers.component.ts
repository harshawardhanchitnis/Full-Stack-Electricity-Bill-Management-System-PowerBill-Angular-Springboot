import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../../services/admin.service';
import { AdminAuthService } from '../../../services/admin-auth.service';

@Component({
  selector: 'app-admin-customers',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-customers.component.html',
  styleUrls: ['./admin-customers.component.css']
})
export class AdminCustomersComponent implements OnInit {
  customers: any[] = [];
  filteredCustomers: any[] = [];
  isLoading = true;
  errorMessage = '';
  successMessage = '';
  searchTerm = '';
  selectedCustomer: any = null;
  showCustomerDetails = false;

  // Pagination
  currentPage = 1;
  itemsPerPage = 10;
  totalPages = 0;

  constructor(
    private adminService: AdminService,
    private adminAuthService: AdminAuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (!this.adminAuthService.isLoggedIn()) {
      this.router.navigate(['/admin/login']);
      return;
    }
    this.loadCustomers();
  }

  loadCustomers(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.adminService.getAllCustomers().subscribe({
      next: (response: any) => {
        this.isLoading = false;
        if (response.success) {
          this.customers = response.data || [];
          this.filteredCustomers = [...this.customers];
          this.calculatePagination();
          
          if (this.customers.length === 0) {
            this.errorMessage = 'No customers found in the system.';
          }
        } else {
          this.errorMessage = response.message || 'Failed to load customers';
        }
      },
      error: (error: any) => {
        this.isLoading = false;
        console.error('Error loading customers:', error);
        this.errorMessage = 'Failed to load customers. Please try again.';
      }
    });
  }

  searchCustomers(): void {
    if (!this.searchTerm.trim()) {
      this.filteredCustomers = [...this.customers];
    } else {
      const term = this.searchTerm.toLowerCase();
      this.filteredCustomers = this.customers.filter(customer =>
        customer.customerName?.toLowerCase().includes(term) ||
        customer.email?.toLowerCase().includes(term) ||
        customer.consumerId?.toLowerCase().includes(term) ||
        customer.mobileNumber?.includes(term)
      );
    }
    this.currentPage = 1;
    this.calculatePagination();
  }

  calculatePagination(): void {
    this.totalPages = Math.ceil(this.filteredCustomers.length / this.itemsPerPage);
  }

  getPaginatedCustomers(): any[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredCustomers.slice(startIndex, endIndex);
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

  viewCustomerDetails(customer: any): void {
    this.selectedCustomer = customer;
    this.showCustomerDetails = true;
  }

  closeCustomerDetails(): void {
    this.showCustomerDetails = false;
    this.selectedCustomer = null;
  }

  generateBillForCustomer(customer: any): void {
    // Navigate to bill generation with pre-selected customer
    this.router.navigate(['/admin/bills'], { 
      queryParams: { customerId: customer.consumerId } 
    });
  }

  viewCustomerBills(customer: any): void {
    // Navigate to bills with customer filter
    this.router.navigate(['/admin/bills'], { 
      queryParams: { viewCustomer: customer.consumerId } 
    });
  }

  refreshCustomers(): void {
    this.loadCustomers();
  }

  goBack(): void {
    this.router.navigate(['/admin/dashboard']);
  }

  getConnectionTypeLabel(type: string): string {
    switch (type) {
      case 'DOMESTIC': return 'Domestic';
      case 'COMMERCIAL': return 'Commercial';
      case 'INDUSTRIAL': return 'Industrial';
      default: return type || 'Unknown';
    }
  }

  formatDate(dateString: string): string {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString('en-IN');
    } catch {
      return dateString;
    }
  }
}
