import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../../services/admin.service';
import { AdminAuthService } from '../../../services/admin-auth.service';

@Component({
  selector: 'app-admin-complaints',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-complaints.component.html',
  styleUrls: ['./admin-complaints.component.css']
})
export class AdminComplaintsComponent implements OnInit {
  complaints: any[] = [];
  filteredComplaints: any[] = [];
  isLoading = true;
  errorMessage = '';
  successMessage = '';
  searchTerm = '';
  selectedComplaint: any = null;
  showComplaintDetails = false;
  statusFilter = 'ALL';

  // Pagination
  currentPage = 1;
  itemsPerPage = 10;
  totalPages = 0;

  constructor(
    private adminService: AdminService,
    private adminAuthService: AdminAuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (!this.adminAuthService.isLoggedIn()) {
      this.router.navigate(['/admin/login']);
      return;
    }
    this.loadComplaints();
  }

  loadComplaints(): void {
    this.isLoading = true;
    this.errorMessage = '';
    console.log('🔍 Loading complaints for admin support...');

    this.adminService.getAllComplaints().subscribe({
      next: (response: any) => {
        console.log('📋 Admin complaints response:', response);
        this.isLoading = false;
        if (response.success) {
          this.complaints = response.data || [];
          console.log('✅ Loaded complaints:', this.complaints);
          this.applyFilters();

          if (this.complaints.length === 0) {
            this.errorMessage = 'No complaints found in the system.';
            console.log('⚠️ No complaints found');
          } else {
            console.log(`✅ Found ${this.complaints.length} complaints`);
          }
        } else {
          this.errorMessage = response.message || 'Failed to load complaints';
          console.error('❌ Failed to load complaints:', response.message);
        }
      },
      error: (error: any) => {
        this.isLoading = false;
        console.error('❌ Error loading complaints:', error);
        this.errorMessage = 'Failed to load complaints. Please try again.';
      }
    });
  }

  applyFilters(): void {
    let filtered = [...this.complaints];

    // Apply status filter
    if (this.statusFilter !== 'ALL') {
      filtered = filtered.filter(complaint => complaint.status === this.statusFilter);
    }

    // Apply search filter
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase();
      filtered = filtered.filter(complaint =>
        complaint.complaintType?.toLowerCase().includes(term) ||
        complaint.subject?.toLowerCase().includes(term) ||
        complaint.problem?.toLowerCase().includes(term) ||
        complaint.description?.toLowerCase().includes(term) ||
        complaint.customerName?.toLowerCase().includes(term) ||
        complaint.complaintId?.toLowerCase().includes(term) ||
        complaint.consumerId?.toLowerCase().includes(term)
      );
    }

    this.filteredComplaints = filtered;
    this.currentPage = 1;
    this.calculatePagination();
  }

  onStatusFilterChange(): void {
    this.applyFilters();
  }

  searchComplaints(): void {
    this.applyFilters();
  }

  calculatePagination(): void {
    this.totalPages = Math.ceil(this.filteredComplaints.length / this.itemsPerPage);
  }

  getPaginatedComplaints(): any[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredComplaints.slice(startIndex, endIndex);
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

  viewComplaintDetails(complaint: any): void {
    console.log('👁️ Viewing complaint details:', complaint);
    this.selectedComplaint = { ...complaint }; // Create a copy to avoid reference issues
    this.showComplaintDetails = true;

    // Log the complaint structure for debugging
    console.log('📋 Selected complaint structure:', {
      complaintId: complaint.complaintId,
      complaintType: complaint.complaintType,
      problem: complaint.problem,
      customerName: complaint.customerName,
      consumerId: complaint.consumerId,
      status: complaint.status,
      category: complaint.category,
      createdDate: complaint.createdDate,
      allFields: Object.keys(complaint)
    });
  }

  closeComplaintDetails(): void {
    this.showComplaintDetails = false;
    this.selectedComplaint = null;
  }

  updateComplaintStatus(complaint: any, newStatus: string): void {
    console.log('🔄 Updating complaint status:', complaint.complaintId, 'to', newStatus);

    const statusUpdate = {
      status: newStatus,
      resolution: newStatus === 'RESOLVED' ? 'Resolved by admin' : null
    };

    // Call the admin service to update complaint status
    this.adminService.updateComplaintStatus(complaint.complaintId, statusUpdate).subscribe({
      next: (response: any) => {
        console.log('✅ Complaint status updated:', response);
        if (response.success) {
          complaint.status = newStatus;
          complaint.resolvedDate = newStatus === 'RESOLVED' ? new Date().toISOString() : null;
          this.successMessage = `Complaint ${complaint.complaintId} status updated to ${newStatus}`;
          this.closeComplaintDetails();
          this.loadComplaints(); // Refresh the list
        } else {
          this.errorMessage = 'Failed to update complaint status: ' + (response.message || 'Unknown error');
        }
      },
      error: (error: any) => {
        console.error('❌ Error updating complaint status:', error);
        this.errorMessage = 'Failed to update complaint status. Please try again.';
      }
    });

    // Clear messages after 3 seconds
    setTimeout(() => {
      this.successMessage = '';
      this.errorMessage = '';
    }, 3000);
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'OPEN':
      case 'PENDING': return 'status-pending';
      case 'IN_PROGRESS': return 'status-in-progress';
      case 'RESOLVED': return 'status-resolved';
      case 'CLOSED': return 'status-closed';
      default: return 'status-unknown';
    }
  }

  getStatusLabel(status: string): string {
    switch (status) {
      case 'OPEN': return 'Open';
      case 'PENDING': return 'Pending';
      case 'IN_PROGRESS': return 'In Progress';
      case 'RESOLVED': return 'Resolved';
      case 'CLOSED': return 'Closed';
      default: return status || 'Unknown';
    }
  }

  getPriorityClass(priority: string): string {
    switch (priority) {
      case 'HIGH': return 'priority-high';
      case 'MEDIUM': return 'priority-medium';
      case 'LOW': return 'priority-low';
      default: return 'priority-unknown';
    }
  }

  refreshComplaints(): void {
    this.loadComplaints();
  }

  goBack(): void {
    this.router.navigate(['/admin/dashboard']);
  }

  formatDate(dateString: string): string {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString('en-IN');
    } catch {
      return dateString;
    }
  }

  formatDateTime(dateString: string): string {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleString('en-IN');
    } catch {
      return dateString;
    }
  }
}
