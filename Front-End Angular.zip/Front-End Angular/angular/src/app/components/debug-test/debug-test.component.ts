import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DebugTestService } from '../../services/debug-test.service';

@Component({
  selector: 'app-debug-test',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-4">
      <div class="row">
        <div class="col-12">
          <h2 class="mb-4">
            <i class="fas fa-bug"></i> Debug: User Registration & Login Issue
          </h2>
          
          <div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>Issue:</strong> "User is not active" error after registration and login attempt.
          </div>

          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">Test Registration & Login Flow</h5>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="mb-3">
                    <label for="testEmail" class="form-label">Test Email</label>
                    <input 
                      type="email" 
                      class="form-control" 
                      id="testEmail"
                      [(ngModel)]="testEmail"
                      placeholder="test@example.com">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="mb-3">
                    <label for="testPassword" class="form-label">Test Password</label>
                    <input 
                      type="password" 
                      class="form-control" 
                      id="testPassword"
                      [(ngModel)]="testPassword"
                      placeholder="password123">
                  </div>
                </div>
              </div>

              <div class="mb-3">
                <button class="btn btn-primary me-2" (click)="testRegistrationAndLogin()" [disabled]="testing">
                  <i class="fas fa-user-plus" [class.fa-spin]="testing"></i>
                  {{ testing ? 'Testing...' : 'Test Registration + Login' }}
                </button>
                
                <button class="btn btn-secondary me-2" (click)="testDirectLogin()" [disabled]="testing">
                  <i class="fas fa-sign-in-alt"></i>
                  Test Direct Login
                </button>
                
                <button class="btn btn-info" (click)="testCustomerLookup()" [disabled]="testing">
                  <i class="fas fa-search"></i>
                  Lookup Customer
                </button>
              </div>

              <div *ngIf="testResults" class="mt-4">
                <h6>Test Results:</h6>
                <div class="card">
                  <div class="card-body">
                    <pre class="bg-light p-3 rounded">{{ testResults | json }}</pre>
                  </div>
                </div>
              </div>

              <div *ngIf="analysisResults" class="mt-4">
                <div class="alert" [class.alert-success]="analysisResults.isActive" [class.alert-danger]="!analysisResults.isActive">
                  <h6><i class="fas fa-chart-line"></i> Analysis:</h6>
                  <ul class="mb-0">
                    <li *ngFor="let finding of analysisResults.findings">{{ finding }}</li>
                  </ul>
                  
                  <div *ngIf="analysisResults.recommendations.length > 0" class="mt-3">
                    <strong>Recommendations:</strong>
                    <ul class="mb-0">
                      <li *ngFor="let rec of analysisResults.recommendations">{{ rec }}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="card mt-4">
            <div class="card-header">
              <h5 class="mb-0">Common Solutions</h5>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <h6><i class="fas fa-database"></i> Database Issues:</h6>
                  <ul>
                    <li>User created but status field is null/false</li>
                    <li>Default user status is INACTIVE</li>
                    <li>Missing user activation step</li>
                  </ul>
                </div>
                <div class="col-md-6">
                  <h6><i class="fas fa-cogs"></i> Backend Issues:</h6>
                  <ul>
                    <li>Registration doesn't set active=true</li>
                    <li>Login validation checks active status</li>
                    <li>Missing auto-activation logic</li>
                  </ul>
                </div>
              </div>
              
              <div class="mt-3">
                <h6><i class="fas fa-tools"></i> Quick Fixes:</h6>
                <ol>
                  <li><strong>Check Spring Boot logs</strong> for the exact error</li>
                  <li><strong>Verify H2 database</strong> - Check user table and status column</li>
                  <li><strong>Update registration logic</strong> to set user as active by default</li>
                  <li><strong>Add user activation endpoint</strong> if manual activation is required</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    pre {
      max-height: 300px;
      overflow-y: auto;
      font-size: 0.85em;
    }
    .card {
      transition: transform 0.2s;
    }
    .card:hover {
      transform: translateY(-2px);
    }
  `]
})
export class DebugTestComponent {
  testEmail = 'debug@example.com';
  testPassword = 'password123';
  testing = false;
  testResults: any = null;
  analysisResults: any = null;

  constructor(private debugService: DebugTestService) {}

  testRegistrationAndLogin(): void {
    this.testing = true;
    this.testResults = null;
    this.analysisResults = null;

    this.debugService.testRegistrationAndLogin(this.testEmail, this.testPassword).subscribe({
      next: (result) => {
        console.log('Full test result:', result);
        
        // Handle nested observable
        if (result.subscribe) {
          result.subscribe({
            next: (nestedResult: any) => {
              this.testResults = nestedResult;
              this.analyzeResults(nestedResult);
              this.testing = false;
            },
            error: (error: any) => {
              this.testResults = { error: error };
              this.testing = false;
            }
          });
        } else {
          this.testResults = result;
          this.analyzeResults(result);
          this.testing = false;
        }
      },
      error: (error) => {
        console.error('Test error:', error);
        this.testResults = { error: error };
        this.testing = false;
      }
    });
  }

  testDirectLogin(): void {
    this.testing = true;
    this.testResults = null;
    this.analysisResults = null;

    this.debugService.testDirectLogin(this.testEmail, this.testPassword).subscribe({
      next: (result) => {
        this.testResults = result;
        this.analyzeResults(result);
        this.testing = false;
      },
      error: (error) => {
        this.testResults = { error: error };
        this.testing = false;
      }
    });
  }

  testCustomerLookup(): void {
    this.testing = true;
    this.testResults = null;
    this.analysisResults = null;

    this.debugService.testCustomerLookup(this.testEmail).subscribe({
      next: (result) => {
        this.testResults = result;
        this.analyzeResults(result);
        this.testing = false;
      },
      error: (error) => {
        this.testResults = { error: error };
        this.testing = false;
      }
    });
  }

  private analyzeResults(results: any): void {
    const analysis = {
      isActive: false,
      findings: [] as string[],
      recommendations: [] as string[]
    };

    if (results.error) {
      const errorMsg = results.errorMessage || results.error.message || 'Unknown error';
      
      if (errorMsg.toLowerCase().includes('not active') || errorMsg.toLowerCase().includes('inactive')) {
        analysis.findings.push('✗ User exists but is marked as INACTIVE');
        analysis.findings.push('✗ Login validation is checking user status');
        analysis.recommendations.push('Update Spring Boot to set users as ACTIVE during registration');
        analysis.recommendations.push('Add user activation endpoint or auto-activate new users');
      } else if (errorMsg.toLowerCase().includes('not found')) {
        analysis.findings.push('✗ User not found in database');
        analysis.recommendations.push('Check if registration actually created the user');
        analysis.recommendations.push('Verify database connection and table creation');
      } else {
        analysis.findings.push(`✗ Error: ${errorMsg}`);
      }
    } else if (results.login && results.login.success) {
      analysis.isActive = true;
      analysis.findings.push('✓ Login successful');
      analysis.findings.push('✓ User is active and properly configured');
    } else if (results.data && results.data.status) {
      const status = results.data.status.toLowerCase();
      if (status === 'active') {
        analysis.isActive = true;
        analysis.findings.push('✓ User status is ACTIVE');
      } else {
        analysis.findings.push(`✗ User status is: ${status.toUpperCase()}`);
        analysis.recommendations.push('Update user status to ACTIVE in database');
      }
    }

    this.analysisResults = analysis;
  }
}
