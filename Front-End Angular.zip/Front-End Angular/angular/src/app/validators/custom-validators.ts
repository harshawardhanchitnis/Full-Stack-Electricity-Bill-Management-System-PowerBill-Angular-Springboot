import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class CustomValidators {

  // Name Validator
  static nameValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    // Check for valid name pattern (letters, spaces, dots, hyphens)
    const namePattern = /^[a-zA-Z\s.-]+$/;
    if (!namePattern.test(value)) {
      return { invalidName: true };
    }
    
    // Check for consecutive spaces or special characters
    if (/\s{2,}|\.{2,}|-{2,}/.test(value)) {
      return { invalidNameFormat: true };
    }
    
    return null;
  }

  // Email Domain Validator
  static emailDomainValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    // Check for suspicious email patterns
    if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
      return { invalidEmailFormat: true };
    }
    
    // Check for valid domain structure
    const emailParts = value.split('@');
    if (emailParts.length === 2) {
      const domain = emailParts[1].toLowerCase();
      if (domain.length < 4 || !domain.includes('.')) {
        return { invalidDomain: true };
      }
    }
    
    return null;
  }

  // Mobile Number Validator (Indian)
  static mobileNumberValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    // Check if it's exactly 10 digits
    if (!/^\d{10}$/.test(value)) {
      return { invalidMobileFormat: true };
    }
    
    // Check for invalid patterns (all same digits)
    if (/^(\d)\1{9}$/.test(value)) {
      return { invalidMobilePattern: true };
    }
    
    // Check for sequential numbers
    const sequentialPatterns = [
      '0123456789', '1234567890', '9876543210',
      '1111111111', '2222222222', '3333333333',
      '4444444444', '5555555555', '6666666666',
      '7777777777', '8888888888', '9999999999',
      '0000000000'
    ];
    
    if (sequentialPatterns.includes(value)) {
      return { invalidMobilePattern: true };
    }
    
    // Check if first digit is valid (Indian mobile numbers start with 6-9)
    if (!/^[6-9]/.test(value)) {
      return { invalidMobileStart: true };
    }
    
    return null;
  }

  // Password Strength Validator
  static passwordStrengthValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    const errors: any = {};
    
    // Check for at least one uppercase letter
    if (!/[A-Z]/.test(value)) {
      errors.noUppercase = true;
    }
    
    // Check for at least one lowercase letter
    if (!/[a-z]/.test(value)) {
      errors.noLowercase = true;
    }
    
    // Check for at least one number
    if (!/\d/.test(value)) {
      errors.noNumber = true;
    }
    
    // Check for at least one special character
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
      errors.noSpecialChar = true;
    }
    
    // Check for common weak passwords
    const weakPasswords = ['password', '12345678', 'qwerty123', 'admin123', 'password123'];
    if (weakPasswords.some(weak => value.toLowerCase().includes(weak))) {
      errors.weakPassword = true;
    }
    
    return Object.keys(errors).length > 0 ? errors : null;
  }

  // City/State Validator
  static cityStateValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    // Check for valid city/state name pattern (letters, spaces, hyphens)
    const pattern = /^[a-zA-Z\s-]+$/;
    if (!pattern.test(value)) {
      return { invalidCityState: true };
    }
    
    return null;
  }

  // Pincode Validator (Indian)
  static pincodeValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    // Check if it's exactly 6 digits
    if (!/^\d{6}$/.test(value)) {
      return { invalidPincodeFormat: true };
    }
    
    // Check for invalid patterns (all same digits)
    if (/^(\d)\1{5}$/.test(value)) {
      return { invalidPincodePattern: true };
    }
    
    // Check for valid Indian pincode range (100001 to 999999)
    const pincodeNum = parseInt(value);
    if (pincodeNum < 100001 || pincodeNum > 999999) {
      return { invalidPincodeRange: true };
    }
    
    return null;
  }

  // Problem Description Validator
  static problemDescriptionValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    // Check for meaningful content (not just repeated characters)
    if (/^(.)\1{10,}$/.test(value)) {
      return { repeatedCharacters: true };
    }
    
    // Check for minimum word count (at least 5 words)
    const wordCount = value.trim().split(/\s+/).length;
    if (wordCount < 5) {
      return { insufficientWords: true };
    }
    
    // Check for common spam patterns
    const spamPatterns = ['test', 'testing', 'asdf', 'qwerty', 'lorem ipsum'];
    if (spamPatterns.some(pattern => value.toLowerCase().includes(pattern))) {
      return { spamContent: true };
    }
    
    return null;
  }

  // Password Match Validator (for forms)
  static passwordMatchValidator(passwordField: string, confirmPasswordField: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const password = control.get(passwordField);
      const confirmPassword = control.get(confirmPasswordField);
      
      if (password && confirmPassword && password.value !== confirmPassword.value) {
        confirmPassword.setErrors({ passwordMismatch: true });
        return { passwordMismatch: true };
      } else {
        if (confirmPassword?.errors?.['passwordMismatch']) {
          delete confirmPassword.errors['passwordMismatch'];
          if (Object.keys(confirmPassword.errors).length === 0) {
            confirmPassword.setErrors(null);
          }
        }
      }
      
      return null;
    };
  }

  // No Whitespace Validator
  static noWhitespaceValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    if (value.trim().length === 0) {
      return { whitespace: true };
    }
    
    return null;
  }

  // Alphanumeric Validator
  static alphanumericValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    if (!/^[a-zA-Z0-9]+$/.test(value)) {
      return { notAlphanumeric: true };
    }
    
    return null;
  }

  // URL Validator
  static urlValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) return null;
    
    const urlPattern = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
    if (!urlPattern.test(value)) {
      return { invalidUrl: true };
    }
    
    return null;
  }

  // Age Validator
  static ageValidator(minAge: number = 18, maxAge: number = 100): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if (!value) return null;
      
      const age = parseInt(value);
      if (isNaN(age) || age < minAge || age > maxAge) {
        return { invalidAge: { min: minAge, max: maxAge, actual: age } };
      }
      
      return null;
    };
  }
}
