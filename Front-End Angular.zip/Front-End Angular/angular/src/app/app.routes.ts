import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { BillsComponent } from './components/bills/bills.component';
import { ComplaintsComponent } from './components/complaints/complaints.component';
import { ApiTestComponent } from './components/api-test/api-test.component';
import { DebugTestComponent } from './components/debug-test/debug-test.component';
import { AuthGuard } from './guards/auth.guard';

// Admin Components
import { AdminLoginComponent } from './components/admin/admin-login/admin-login.component';
import { AdminDashboardComponent } from './components/admin/admin-dashboard/admin-dashboard.component';
import { AdminBillsComponent } from './components/admin/admin-bills/admin-bills.component';
import { AdminCustomersComponent } from './components/admin/admin-customers/admin-customers.component';
import { AdminComplaintsComponent } from './components/admin/admin-complaints/admin-complaints.component';
import { AdminAuthGuard } from './guards/admin-auth.guard';

export const routes: Routes = [
  // Default route - redirect to customer login
  { path: '', redirectTo: '/login', pathMatch: 'full' },

  // Customer Routes
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'bills', component: BillsComponent, canActivate: [AuthGuard] },
  { path: 'complaints', component: ComplaintsComponent, canActivate: [AuthGuard] },

  // Admin Routes
  { path: 'admin/login', component: AdminLoginComponent },
  { path: 'admin/dashboard', component: AdminDashboardComponent, canActivate: [AdminAuthGuard] },
  { path: 'admin/bills', component: AdminBillsComponent, canActivate: [AdminAuthGuard] },
  { path: 'admin/customers', component: AdminCustomersComponent, canActivate: [AdminAuthGuard] },
  { path: 'admin/complaints', component: AdminComplaintsComponent, canActivate: [AdminAuthGuard] },

  // Development/Testing Routes
  { path: 'api-test', component: ApiTestComponent },
  { path: 'debug-test', component: DebugTestComponent },

  // Legacy redirects for customer routes
  { path: 'profile', redirectTo: '/dashboard' },
  { path: 'change-password', redirectTo: '/dashboard' },
  { path: 'download-bills', redirectTo: '/bills' },
  { path: 'bill-history', redirectTo: '/bills?tab=paid' },
  { path: 'pay-bills', redirectTo: '/bills?tab=pending' },
  { path: 'view-bills', redirectTo: '/bills?tab=pending' },

  // Admin redirects
  { path: 'admin', redirectTo: '/admin/login' },

  // Catch-all route
  { path: '**', redirectTo: '/login' }
];
